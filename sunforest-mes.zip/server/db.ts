import { eq, and, gte, lte, desc, asc, sql, like, or, SQL } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  workers, InsertWorker, Worker,
  productionLines, InsertProductionLine,
  customers, InsertCustomer,
  orders, InsertOrder,
  orderDetails, InsertOrderDetail,
  workOrders, InsertWorkOrder,
  materials, InsertMaterial,
  materialTransactions, InsertMaterialTransaction,
  sewingProcesses, InsertSewingProcess, SewingProcess,
  warehouseTransactions, InsertWarehouseTransaction, WarehouseTransaction,
  productionReports, InsertProductionReport,
  qcInspections, InsertQcInspection,
  defectRecords, InsertDefectRecord,
  attendance, InsertAttendance,
  shipments, InsertShipment,
  packingDetails, InsertPackingDetail,
  alertSettings, InsertAlertSetting, AlertSetting,
  alerts, InsertAlert, Alert,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============================================================
// Users
// ============================================================
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createLocalUser(data: { username: string; passwordHash: string; name: string; phone?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const openId = `local_${data.username}_${Date.now()}`;
  await db.insert(users).values({
    openId,
    username: data.username,
    passwordHash: data.passwordHash,
    name: data.name,
    phone: data.phone || null,
    loginMethod: "password",
    role: "user",
    approvalStatus: "pending",
    lastSignedIn: new Date(),
  });
  return getUserByUsername(data.username);
}

export async function listPendingUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).where(eq(users.approvalStatus, "pending")).orderBy(desc(users.createdAt));
}

export async function listAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: users.id,
    openId: users.openId,
    name: users.name,
    email: users.email,
    username: users.username,
    phone: users.phone,
    loginMethod: users.loginMethod,
    role: users.role,
    approvalStatus: users.approvalStatus,
    createdAt: users.createdAt,
    lastSignedIn: users.lastSignedIn,
  }).from(users).orderBy(desc(users.createdAt));
}

export async function updateUserApproval(id: number, status: "approved" | "rejected") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ approvalStatus: status }).where(eq(users.id, id));
}

export async function updateUserRole(id: number, role: "admin" | "user") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role }).where(eq(users.id, id));
}

export async function updateUserName(id: number, name: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ name }).where(eq(users.id, id));
}

// ============================================================
// Workers
// ============================================================
export async function listWorkers(filters?: { lineId?: number; status?: string; role?: string; search?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.lineId) conditions.push(eq(workers.lineId, filters.lineId));
  if (filters?.status) conditions.push(eq(workers.status, filters.status as any));
  if (filters?.role) conditions.push(eq(workers.workerRole, filters.role as any));
  if (filters?.search) conditions.push(or(like(workers.name, `%${filters.search}%`), like(workers.employeeCode, `%${filters.search}%`))!);
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(workers).where(where).orderBy(asc(workers.employeeCode));
}

export async function getWorkerById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(workers).where(eq(workers.id, id)).limit(1);
  return result[0];
}

export async function getWorkerByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(workers).where(eq(workers.employeeCode, code)).limit(1);
  return result[0];
}

export async function createWorker(data: InsertWorker) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(workers).values(data);
  return { id: result[0].insertId };
}

export async function updateWorker(id: number, data: Partial<InsertWorker>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(workers).set(data).where(eq(workers.id, id));
}

export async function deleteWorker(id: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(workers).set({ status: "inactive" }).where(eq(workers.id, id));
}

// ============================================================
// Production Lines
// ============================================================
export async function listProductionLines(filters?: { type?: string; status?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.type) conditions.push(eq(productionLines.type, filters.type as any));
  if (filters?.status) conditions.push(eq(productionLines.status, filters.status as any));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(productionLines).where(where).orderBy(asc(productionLines.name));
}

export async function createProductionLine(data: InsertProductionLine) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(productionLines).values(data);
  return { id: result[0].insertId };
}

export async function updateProductionLine(id: number, data: Partial<InsertProductionLine>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(productionLines).set(data).where(eq(productionLines.id, id));
}

// ============================================================
// Customers
// ============================================================
export async function listCustomers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(customers).orderBy(asc(customers.name));
}

export async function createCustomer(data: InsertCustomer) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(customers).values(data);
  return { id: result[0].insertId };
}

export async function updateCustomer(id: number, data: Partial<InsertCustomer>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(customers).set(data).where(eq(customers.id, id));
}

// ============================================================
// Orders
// ============================================================
export async function listOrders(filters?: { status?: string; customerId?: number; search?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.status) conditions.push(eq(orders.status, filters.status as any));
  if (filters?.customerId) conditions.push(eq(orders.customerId, filters.customerId));
  if (filters?.search) conditions.push(or(like(orders.orderNo, `%${filters.search}%`), like(orders.styleNo, `%${filters.search}%`))!);
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(orders).where(where).orderBy(desc(orders.createdAt));
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result[0];
}

export async function createOrder(data: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(orders).values(data);
  return { id: result[0].insertId };
}

export async function updateOrder(id: number, data: Partial<InsertOrder>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(orders).set(data).where(eq(orders.id, id));
}

// ============================================================
// Order Details
// ============================================================
export async function listOrderDetails(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orderDetails).where(eq(orderDetails.orderId, orderId));
}

export async function createOrderDetail(data: InsertOrderDetail) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(orderDetails).values(data);
  return { id: result[0].insertId };
}

export async function deleteOrderDetails(orderId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(orderDetails).where(eq(orderDetails.orderId, orderId));
}

// ============================================================
// Work Orders
// ============================================================
export async function listWorkOrders(filters?: { orderId?: number; lineId?: number; status?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.orderId) conditions.push(eq(workOrders.orderId, filters.orderId));
  if (filters?.lineId) conditions.push(eq(workOrders.lineId, filters.lineId));
  if (filters?.status) conditions.push(eq(workOrders.status, filters.status as any));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(workOrders).where(where).orderBy(desc(workOrders.createdAt));
}

export async function getWorkOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(workOrders).where(eq(workOrders.id, id)).limit(1);
  return result[0];
}

export async function createWorkOrder(data: InsertWorkOrder) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(workOrders).values(data);
  return { id: result[0].insertId };
}

export async function updateWorkOrder(id: number, data: Partial<InsertWorkOrder>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(workOrders).set(data).where(eq(workOrders.id, id));
}

// ============================================================
// Materials
// ============================================================
export async function listMaterials(filters?: { type?: string; search?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.type) conditions.push(eq(materials.type, filters.type as any));
  if (filters?.search) conditions.push(or(like(materials.name, `%${filters.search}%`), like(materials.code, `%${filters.search}%`))!);
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(materials).where(where).orderBy(asc(materials.code));
}

export async function getMaterialById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(materials).where(eq(materials.id, id)).limit(1);
  return result[0];
}

export async function createMaterial(data: InsertMaterial) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(materials).values(data);
  return { id: result[0].insertId };
}

export async function updateMaterial(id: number, data: Partial<InsertMaterial>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(materials).set(data).where(eq(materials.id, id));
}

export async function getLowStockMaterials() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(materials).where(
    sql`CAST(${materials.currentStock} AS DECIMAL(12,2)) <= CAST(${materials.safetyStock} AS DECIMAL(12,2)) AND CAST(${materials.safetyStock} AS DECIMAL(12,2)) > 0`
  );
}

// ============================================================
// Material Transactions
// ============================================================
export async function listMaterialTransactions(filters?: { materialId?: number; type?: string; startDate?: string; endDate?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.materialId) conditions.push(eq(materialTransactions.materialId, filters.materialId));
  if (filters?.type) conditions.push(eq(materialTransactions.type, filters.type as any));
  if (filters?.startDate) conditions.push(gte(materialTransactions.createdAt, new Date(filters.startDate)));
  if (filters?.endDate) conditions.push(lte(materialTransactions.createdAt, new Date(filters.endDate)));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(materialTransactions).where(where).orderBy(desc(materialTransactions.createdAt));
}

export async function createMaterialTransaction(data: InsertMaterialTransaction) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(materialTransactions).values(data);
  // Update stock
  const material = await getMaterialById(data.materialId);
  if (material) {
    const currentStock = parseFloat(material.currentStock || "0");
    const qty = parseFloat(String(data.qty));
    let newStock = currentStock;
    if (data.type === "in" || data.type === "return") newStock += qty;
    else if (data.type === "out") newStock -= qty;
    await updateMaterial(data.materialId, { currentStock: String(newStock) });
  }
  return { id: result[0].insertId };
}

// ============================================================
// Production Reports
// ============================================================
export async function listProductionReports(filters?: { workOrderId?: number; workerId?: number; lineId?: number; station?: string; startDate?: string; endDate?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.workOrderId) conditions.push(eq(productionReports.workOrderId, filters.workOrderId));
  if (filters?.workerId) conditions.push(eq(productionReports.workerId, filters.workerId));
  if (filters?.lineId) conditions.push(eq(productionReports.lineId, filters.lineId));
  if (filters?.station) conditions.push(eq(productionReports.station, filters.station as any));
  if (filters?.startDate) conditions.push(gte(productionReports.reportDate, new Date(filters.startDate)));
  if (filters?.endDate) conditions.push(lte(productionReports.reportDate, new Date(filters.endDate)));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(productionReports).where(where).orderBy(desc(productionReports.reportTime));
}

export async function createProductionReport(data: InsertProductionReport) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(productionReports).values(data);
  // Update work order completed qty
  if (data.workOrderId) {
    const reports = await listProductionReports({ workOrderId: data.workOrderId, station: "packing" });
    const totalCompleted = reports.reduce((sum, r) => sum + (r.qty || 0), 0);
    await updateWorkOrder(data.workOrderId, { completedQty: totalCompleted });
  }
  return { id: result[0].insertId };
}

// ============================================================
// QC Inspections
// ============================================================
export async function listQcInspections(filters?: { workOrderId?: number; startDate?: string; endDate?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.workOrderId) conditions.push(eq(qcInspections.workOrderId, filters.workOrderId));
  if (filters?.startDate) conditions.push(gte(qcInspections.inspectionDate, new Date(filters.startDate)));
  if (filters?.endDate) conditions.push(lte(qcInspections.inspectionDate, new Date(filters.endDate)));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(qcInspections).where(where).orderBy(desc(qcInspections.createdAt));
}

export async function createQcInspection(data: InsertQcInspection) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(qcInspections).values(data);
  return { id: result[0].insertId };
}

// ============================================================
// Defect Records
// ============================================================
export async function listDefectRecords(inspectionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(defectRecords).where(eq(defectRecords.inspectionId, inspectionId));
}

export async function createDefectRecord(data: InsertDefectRecord) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(defectRecords).values(data);
  return { id: result[0].insertId };
}

export async function updateDefectRecord(id: number, data: Partial<InsertDefectRecord>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(defectRecords).set(data).where(eq(defectRecords.id, id));
}

// ============================================================
// Attendance
// ============================================================
export async function listAttendance(filters?: { workerId?: number; startDate?: string; endDate?: string; status?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.workerId) conditions.push(eq(attendance.workerId, filters.workerId));
  if (filters?.status) conditions.push(eq(attendance.status, filters.status as any));
  if (filters?.startDate) conditions.push(gte(attendance.attendanceDate, new Date(filters.startDate)));
  if (filters?.endDate) conditions.push(lte(attendance.attendanceDate, new Date(filters.endDate)));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(attendance).where(where).orderBy(desc(attendance.attendanceDate));
}

export async function createAttendance(data: InsertAttendance) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(attendance).values(data);
  return { id: result[0].insertId };
}

export async function updateAttendance(id: number, data: Partial<InsertAttendance>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(attendance).set(data).where(eq(attendance.id, id));
}

export async function getAttendanceByWorkerAndDate(workerId: number, dateStr: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(attendance)
    .where(and(eq(attendance.workerId, workerId), eq(attendance.attendanceDate, new Date(dateStr))))
    .limit(1);
  return result[0];
}

// ============================================================
// Shipments
// ============================================================
export async function listShipments(filters?: { orderId?: number; status?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.orderId) conditions.push(eq(shipments.orderId, filters.orderId));
  if (filters?.status) conditions.push(eq(shipments.status, filters.status as any));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(shipments).where(where).orderBy(desc(shipments.createdAt));
}

export async function getShipmentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(shipments).where(eq(shipments.id, id)).limit(1);
  return result[0];
}

export async function createShipment(data: InsertShipment) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(shipments).values(data);
  return { id: result[0].insertId };
}

export async function updateShipment(id: number, data: Partial<InsertShipment>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(shipments).set(data).where(eq(shipments.id, id));
}

// ============================================================
// Packing Details
// ============================================================
export async function listPackingDetails(shipmentId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(packingDetails).where(eq(packingDetails.shipmentId, shipmentId));
}

export async function createPackingDetail(data: InsertPackingDetail) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(packingDetails).values(data);
  return { id: result[0].insertId };
}

export async function deletePackingDetails(shipmentId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(packingDetails).where(eq(packingDetails.shipmentId, shipmentId));
}

// ============================================================
// Dashboard Statistics
// ============================================================
export async function getDashboardStats() {
  const db = await getDb();
  if (!db) return null;

  const today = new Date().toISOString().split('T')[0];

  const [totalWorkers] = await db.select({ count: sql<number>`COUNT(*)` }).from(workers).where(eq(workers.status, "active"));
  const [totalOrders] = await db.select({ count: sql<number>`COUNT(*)` }).from(orders);
  const [activeOrders] = await db.select({ count: sql<number>`COUNT(*)` }).from(orders).where(eq(orders.status, "in_production"));
  const [todayAttendance] = await db.select({ count: sql<number>`COUNT(*)` }).from(attendance).where(and(eq(attendance.attendanceDate, new Date(today)), eq(attendance.status, "present")));
  const [todayProduction] = await db.select({ total: sql<number>`COALESCE(SUM(qty), 0)` }).from(productionReports).where(eq(productionReports.reportDate, new Date(today)));
  const [pendingShipments] = await db.select({ count: sql<number>`COUNT(*)` }).from(shipments).where(eq(shipments.status, "planned"));

  return {
    totalWorkers: totalWorkers?.count || 0,
    totalOrders: totalOrders?.count || 0,
    activeOrders: activeOrders?.count || 0,
    todayAttendance: todayAttendance?.count || 0,
    todayProduction: todayProduction?.total || 0,
    pendingShipments: pendingShipments?.count || 0,
  };
}

export async function getProductionEfficiency(startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    lineId: productionReports.lineId,
    station: productionReports.station,
    totalQty: sql<number>`SUM(${productionReports.qty})`,
    totalDefects: sql<number>`SUM(${productionReports.defectQty})`,
    reportCount: sql<number>`COUNT(*)`,
  }).from(productionReports)
    .where(and(
      gte(productionReports.reportDate, new Date(startDate)),
      lte(productionReports.reportDate, new Date(endDate))
    ))
    .groupBy(productionReports.lineId, productionReports.station);
}

export async function getDefectRateStats(startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    defectType: defectRecords.defectType,
    totalQty: sql<number>`SUM(${defectRecords.qty})`,
    count: sql<number>`COUNT(*)`,
  }).from(defectRecords)
    .where(and(
      gte(defectRecords.createdAt, new Date(startDate)),
      lte(defectRecords.createdAt, new Date(endDate))
    ))
    .groupBy(defectRecords.defectType);
}

export async function getWorkerProductivity(startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    workerId: productionReports.workerId,
    totalQty: sql<number>`SUM(${productionReports.qty})`,
    totalDefects: sql<number>`SUM(${productionReports.defectQty})`,
    days: sql<number>`COUNT(DISTINCT ${productionReports.reportDate})`,
  }).from(productionReports)
    .where(and(
      gte(productionReports.reportDate, new Date(startDate)),
      lte(productionReports.reportDate, new Date(endDate))
    ))
    .groupBy(productionReports.workerId);
}

export async function getDailyProduction(startDate: string, endDate: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    reportDate: productionReports.reportDate,
    station: productionReports.station,
    totalQty: sql<number>`SUM(${productionReports.qty})`,
  }).from(productionReports)
    .where(and(
      gte(productionReports.reportDate, new Date(startDate)),
      lte(productionReports.reportDate, new Date(endDate))
    ))
    .groupBy(productionReports.reportDate, productionReports.station)
    .orderBy(asc(productionReports.reportDate));
}

// ============================================================
// Sewing Processes
// ============================================================
export async function listSewingProcesses(filters?: { status?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.status) conditions.push(eq(sewingProcesses.status, filters.status as any));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(sewingProcesses).where(where).orderBy(asc(sewingProcesses.sortOrder), asc(sewingProcesses.id));
}

export async function getSewingProcessById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(sewingProcesses).where(eq(sewingProcesses.id, id)).limit(1);
  return result[0];
}

export async function createSewingProcess(data: InsertSewingProcess) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(sewingProcesses).values(data);
  return { id: result[0].insertId };
}

export async function updateSewingProcess(id: number, data: Partial<InsertSewingProcess>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(sewingProcesses).set(data).where(eq(sewingProcesses.id, id));
  return getSewingProcessById(id);
}

export async function deleteSewingProcess(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(sewingProcesses).where(eq(sewingProcesses.id, id));
  return { success: true };
}

// ============================================================
// Warehouse Transactions
// ============================================================
export async function listWarehouseTransactions(filters?: { materialId?: number; type?: string; startDate?: string; endDate?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: SQL[] = [];
  if (filters?.materialId) conditions.push(eq(warehouseTransactions.materialId, filters.materialId));
  if (filters?.type) conditions.push(eq(warehouseTransactions.type, filters.type as any));
  if (filters?.startDate) conditions.push(gte(warehouseTransactions.transactionDate, new Date(filters.startDate)));
  if (filters?.endDate) conditions.push(lte(warehouseTransactions.transactionDate, new Date(filters.endDate)));
  const where = conditions.length > 0 ? and(...conditions) : undefined;
  return db.select().from(warehouseTransactions).where(where).orderBy(desc(warehouseTransactions.createdAt));
}

export async function getWarehouseTransactionById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(warehouseTransactions).where(eq(warehouseTransactions.id, id)).limit(1);
  return result[0];
}

export async function createWarehouseTransaction(data: InsertWarehouseTransaction) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(warehouseTransactions).values(data);
  return { id: result[0].insertId };
}

export async function updateWarehouseTransaction(id: number, data: Partial<InsertWarehouseTransaction>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(warehouseTransactions).set(data).where(eq(warehouseTransactions.id, id));
  return getWarehouseTransactionById(id);
}

export async function getWarehouseInventory() {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    materialId: warehouseTransactions.materialId,
    totalReceived: sql<number>`SUM(CASE WHEN type = 'receive' THEN qty ELSE 0 END)`,
    totalIssued: sql<number>`SUM(CASE WHEN type = 'issue' THEN qty ELSE 0 END)`,
    totalTransferred: sql<number>`SUM(CASE WHEN type = 'transfer' THEN qty ELSE 0 END)`,
    netInventory: sql<number>`SUM(CASE WHEN type = 'receive' THEN qty WHEN type = 'issue' THEN -qty WHEN type = 'transfer' THEN -qty ELSE 0 END)`,
  }).from(warehouseTransactions)
    .groupBy(warehouseTransactions.materialId);
}


// ============================================================
// Salary Calculation
// ============================================================
export interface SalaryCalculation {
  workerId: number;
  workerCode: string;
  workerName: string;
  salaryType: "hourly" | "monthly" | "piece";
  totalQty: number;
  totalHours: number;
  hourlyRate: number;
  monthlySalary: number;
  pieceRate: number;
  grossSalary: number;
  workingDays: number;
}

export async function calculateWorkerSalary(
  workerId: number,
  startDate: Date,
  endDate: Date
): Promise<SalaryCalculation | null> {
  const db = await getDb();
  if (!db) return null;

  // Get worker info
  const worker = await db.select().from(workers).where(eq(workers.id, workerId)).limit(1);
  if (!worker.length) return null;

  const w = worker[0];

  // Calculate total quantity from production reports
  const prodReports = await db
    .select({
      totalQty: sql<number>`SUM(qty)`,
      totalDefectQty: sql<number>`SUM(defectQty)`,
    })
    .from(productionReports)
    .where(
      and(
        eq(productionReports.workerId, workerId),
        gte(productionReports.reportDate, startDate),
        lte(productionReports.reportDate, endDate)
      )
    );

  const totalQty = prodReports[0]?.totalQty || 0;

  // Calculate working days from attendance
  const attendanceRecords = await db
    .select({ count: sql<number>`COUNT(*)` })
    .from(attendance)
    .where(
      and(
        eq(attendance.workerId, workerId),
        eq(attendance.status, "present"),
        gte(attendance.attendanceDate, startDate),
        lte(attendance.attendanceDate, endDate)
      )
    );

  const workingDays = attendanceRecords[0]?.count || 0;

  // Calculate salary based on salary type
  let grossSalary = 0;
  const hourlyRate = parseFloat(w.hourlyRate || "0");
  const monthlySalary = parseFloat(w.monthlySalary || "0");
  const pieceRate = parseFloat(w.pieceRate || "0");

  if (w.salaryType === "hourly") {
    // 8 hours per day
    const totalHours = workingDays * 8;
    grossSalary = totalHours * hourlyRate;
  } else if (w.salaryType === "monthly") {
    // Fixed monthly salary
    grossSalary = monthlySalary;
  } else if (w.salaryType === "piece") {
    // Piece rate based on production quantity
    grossSalary = totalQty * pieceRate;
  }

  return {
    workerId,
    workerCode: w.employeeCode,
    workerName: w.name,
    salaryType: w.salaryType as "hourly" | "monthly" | "piece",
    totalQty,
    totalHours: workingDays * 8,
    hourlyRate,
    monthlySalary,
    pieceRate,
    grossSalary,
    workingDays,
  };
}

export async function calculateMonthSalaries(
  year: number,
  month: number
): Promise<SalaryCalculation[]> {
  const db = await getDb();
  if (!db) return [];

  // Get all workers
  const allWorkers = await db.select().from(workers);

  // Calculate start and end date for the month
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0);

  // Calculate salary for each worker
  const salaries: SalaryCalculation[] = [];
  for (const worker of allWorkers) {
    const salary = await calculateWorkerSalary(worker.id, startDate, endDate);
    if (salary) {
      salaries.push(salary);
    }
  }

  return salaries;
}

export async function getSalaryByMonth(
  year: number,
  month: number,
  workerId?: number
): Promise<SalaryCalculation[]> {
  const db = await getDb();
  if (!db) return [];

  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0);

  if (workerId) {
    const salary = await calculateWorkerSalary(workerId, startDate, endDate);
    return salary ? [salary] : [];
  }

  return calculateMonthSalaries(year, month);
}

// ============================================================
// Bulk Import Helpers
// ============================================================
export async function bulkCreateWorkers(rows: InsertWorker[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  if (rows.length === 0) return { inserted: 0 };
  let inserted = 0;
  const errors: { row: number; message: string }[] = [];
  for (let i = 0; i < rows.length; i++) {
    try {
      await db.insert(workers).values(rows[i]);
      inserted++;
    } catch (e: any) {
      errors.push({ row: i + 1, message: e.message || "Unknown error" });
    }
  }
  return { inserted, errors };
}

export async function bulkCreateCustomers(rows: InsertCustomer[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  if (rows.length === 0) return { inserted: 0 };
  let inserted = 0;
  const errors: { row: number; message: string }[] = [];
  for (let i = 0; i < rows.length; i++) {
    try {
      await db.insert(customers).values(rows[i]);
      inserted++;
    } catch (e: any) {
      errors.push({ row: i + 1, message: e.message || "Unknown error" });
    }
  }
  return { inserted, errors };
}

export async function bulkCreateMaterials(rows: InsertMaterial[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  if (rows.length === 0) return { inserted: 0 };
  let inserted = 0;
  const errors: { row: number; message: string }[] = [];
  for (let i = 0; i < rows.length; i++) {
    try {
      await db.insert(materials).values(rows[i]);
      inserted++;
    } catch (e: any) {
      errors.push({ row: i + 1, message: e.message || "Unknown error" });
    }
  }
  return { inserted, errors };
}

export async function bulkCreateOrders(rows: InsertOrder[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  if (rows.length === 0) return { inserted: 0 };
  let inserted = 0;
  const errors: { row: number; message: string }[] = [];
  for (let i = 0; i < rows.length; i++) {
    try {
      await db.insert(orders).values(rows[i]);
      inserted++;
    } catch (e: any) {
      errors.push({ row: i + 1, message: e.message || "Unknown error" });
    }
  }
  return { inserted, errors };
}


// ============================================================
// Alert Settings Helpers
// ============================================================
export async function getAlertSettings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(alertSettings).orderBy(alertSettings.id);
}

export async function updateAlertSetting(id: number, data: { enabled?: "yes" | "no"; thresholdValue?: string; thresholdValue2?: string | null; description?: string }) {
  const db = await getDb();
  if (!db) return;
  await db.update(alertSettings).set(data as any).where(eq(alertSettings.id, id));
}

// ============================================================
// Alerts Helpers
// ============================================================
export async function getAlerts(filters?: { isRead?: string; alertType?: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (filters?.isRead) conditions.push(eq(alerts.isRead, filters.isRead as any));
  if (filters?.alertType) conditions.push(eq(alerts.alertType, filters.alertType as any));
  
  const query = db.select().from(alerts).orderBy(desc(alerts.createdAt));
  if (conditions.length > 0) {
    return query.where(and(...conditions)).limit(filters?.limit || 100);
  }
  return query.limit(filters?.limit || 100);
}

export async function getUnreadAlertCount() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(alerts).where(eq(alerts.isRead, "no" as any));
  return result[0]?.count || 0;
}

export async function createAlert(data: InsertAlert) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(alerts).values(data);
  const insertId = result[0].insertId;
  const rows = await db.select().from(alerts).where(eq(alerts.id, insertId));
  return rows[0] || null;
}

export async function markAlertRead(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(alerts).set({ isRead: "yes" }).where(eq(alerts.id, id));
}

export async function markAllAlertsRead() {
  const db = await getDb();
  if (!db) return;
  await db.update(alerts).set({ isRead: "yes" }).where(eq(alerts.isRead, "no"));
}

export async function resolveAlert(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(alerts).set({ isResolved: "yes" }).where(eq(alerts.id, id));
}

// ============================================================
// Alert Check Logic - Low Stock
// ============================================================
export async function checkLowStockAlerts() {
  const db = await getDb();
  if (!db) return [];
  // Find materials where currentStock < safetyStock and safetyStock > 0
  const lowStockItems = await db.select().from(materials)
    .where(and(
      sql`CAST(${materials.currentStock} AS DECIMAL(12,2)) < CAST(${materials.safetyStock} AS DECIMAL(12,2))`,
      sql`CAST(${materials.safetyStock} AS DECIMAL(12,2)) > 0`
    ));
  return lowStockItems;
}

// ============================================================
// Alert Check Logic - Delivery Approaching / Overdue
// ============================================================
export async function checkDeliveryAlerts(warningDays: number, criticalDays: number) {
  const db = await getDb();
  if (!db) return { approaching: [], overdue: [] };
  
  const today = new Date().toISOString().split('T')[0];
  
  // Overdue: deliveryDate < today AND status not completed/shipped
  const overdue = await db.select().from(orders)
    .where(and(
      sql`${orders.deliveryDate} < ${today}`,
      sql`${orders.status} NOT IN ('completed', 'shipped')`
    ));
  
  // Approaching: deliveryDate between today and today + warningDays
  const warningDate = new Date();
  warningDate.setDate(warningDate.getDate() + warningDays);
  const warningDateStr = warningDate.toISOString().split('T')[0];
  
  const approaching = await db.select().from(orders)
    .where(and(
      sql`${orders.deliveryDate} >= ${today}`,
      sql`${orders.deliveryDate} <= ${warningDateStr}`,
      sql`${orders.status} NOT IN ('completed', 'shipped')`
    ));
  
  return { approaching, overdue };
}

// ============================================================
// Alert Check Logic - High Defect Rate
// ============================================================
export async function checkDefectRateAlerts(warningRate: number, criticalRate: number) {
  const db = await getDb();
  if (!db) return [];
  
  // Get recent QC inspections with defect rate > threshold
  const recentInspections = await db.select().from(qcInspections)
    .where(sql`${qcInspections.inspectedQty} > 0`);
  
  const highDefectInspections = recentInspections.filter(insp => {
    const defectRate = (insp.failQty / insp.inspectedQty) * 100;
    return defectRate >= warningRate;
  }).map(insp => ({
    ...insp,
    defectRate: (insp.failQty / insp.inspectedQty) * 100,
    severity: ((insp.failQty / insp.inspectedQty) * 100) >= criticalRate ? 'critical' : 'warning'
  }));
  
  return highDefectInspections;
}
