import { describe, it, expect } from "vitest";
import { z } from "zod";

const ALL_MODULES = [
  "production", "warehouse", "quality", "hr", "finance", "reports", "alerts", "sewing", "import",
] as const;

// Helper to parse permissions JSON
function parsePermissions(permissions: string | null | undefined): string[] {
  if (!permissions) return [];
  try {
    const parsed = JSON.parse(permissions);
    return Array.isArray(parsed) ? parsed.filter((m: string) => ALL_MODULES.includes(m as any)) : [];
  } catch {
    return [];
  }
}

// Helper to check if a worker has access to a module
function hasModuleAccess(worker: { workerRole: string; permissions?: string | null }, module: string): boolean {
  // Manager always has full access
  if (worker.workerRole === "manager") return true;
  const perms = parsePermissions(worker.permissions);
  return perms.includes(module);
}

describe("Permission System", () => {
  describe("parsePermissions", () => {
    it("should return empty array for null/undefined", () => {
      expect(parsePermissions(null)).toEqual([]);
      expect(parsePermissions(undefined)).toEqual([]);
      expect(parsePermissions("")).toEqual([]);
    });

    it("should parse valid JSON array of modules", () => {
      expect(parsePermissions('["production","warehouse"]')).toEqual(["production", "warehouse"]);
      expect(parsePermissions('["quality"]')).toEqual(["quality"]);
    });

    it("should filter out invalid module names", () => {
      expect(parsePermissions('["production","invalid_module"]')).toEqual(["production"]);
      expect(parsePermissions('["foo","bar"]')).toEqual([]);
    });

    it("should handle malformed JSON gracefully", () => {
      expect(parsePermissions("not json")).toEqual([]);
      expect(parsePermissions("{invalid}")).toEqual([]);
    });

    it("should handle non-array JSON", () => {
      expect(parsePermissions('{"key":"value"}')).toEqual([]);
      expect(parsePermissions('"string"')).toEqual([]);
    });

    it("should parse all valid modules", () => {
      const allModulesJson = JSON.stringify([...ALL_MODULES]);
      const result = parsePermissions(allModulesJson);
      expect(result).toEqual([...ALL_MODULES]);
      expect(result.length).toBe(9);
    });
  });

  describe("hasModuleAccess", () => {
    it("manager should have access to all modules", () => {
      const manager = { workerRole: "manager", permissions: null };
      for (const mod of ALL_MODULES) {
        expect(hasModuleAccess(manager, mod)).toBe(true);
      }
    });

    it("manager should have access even with empty permissions", () => {
      const manager = { workerRole: "manager", permissions: "[]" };
      expect(hasModuleAccess(manager, "production")).toBe(true);
      expect(hasModuleAccess(manager, "warehouse")).toBe(true);
    });

    it("worker with specific permissions should only access granted modules", () => {
      const worker = { workerRole: "worker", permissions: '["production","warehouse"]' };
      expect(hasModuleAccess(worker, "production")).toBe(true);
      expect(hasModuleAccess(worker, "warehouse")).toBe(true);
      expect(hasModuleAccess(worker, "quality")).toBe(false);
      expect(hasModuleAccess(worker, "hr")).toBe(false);
      expect(hasModuleAccess(worker, "finance")).toBe(false);
    });

    it("leader with specific permissions should only access granted modules", () => {
      const leader = { workerRole: "leader", permissions: '["production","quality","reports"]' };
      expect(hasModuleAccess(leader, "production")).toBe(true);
      expect(hasModuleAccess(leader, "quality")).toBe(true);
      expect(hasModuleAccess(leader, "reports")).toBe(true);
      expect(hasModuleAccess(leader, "warehouse")).toBe(false);
      expect(hasModuleAccess(leader, "finance")).toBe(false);
    });

    it("worker with no permissions should have no access", () => {
      const worker = { workerRole: "worker", permissions: null };
      for (const mod of ALL_MODULES) {
        expect(hasModuleAccess(worker, mod)).toBe(false);
      }
    });

    it("worker with all permissions should have full access", () => {
      const worker = { workerRole: "worker", permissions: JSON.stringify([...ALL_MODULES]) };
      for (const mod of ALL_MODULES) {
        expect(hasModuleAccess(worker, mod)).toBe(true);
      }
    });
  });

  describe("Worker API Input Validation", () => {
    it("should accept permissions field in worker create", () => {
      const schema = z.object({
        employeeCode: z.string().min(1),
        name: z.string().min(1),
        permissions: z.string().optional(),
      });

      const validInputs = [
        { employeeCode: "W001", name: "Test", permissions: '["production"]' },
        { employeeCode: "W002", name: "Test", permissions: '["production","warehouse","quality"]' },
        { employeeCode: "W003", name: "Test" }, // no permissions
      ];

      for (const input of validInputs) {
        expect(() => schema.parse(input)).not.toThrow();
      }
    });

    it("should accept permissions field in worker update", () => {
      const schema = z.object({
        id: z.number(),
        permissions: z.string().nullable().optional(),
      });

      const validInputs = [
        { id: 1, permissions: '["production","warehouse"]' },
        { id: 1, permissions: null },
        { id: 1, permissions: "[]" },
        { id: 1 }, // no permissions change
      ];

      for (const input of validInputs) {
        expect(() => schema.parse(input)).not.toThrow();
      }
    });
  });

  describe("Module Definitions", () => {
    it("should have exactly 9 modules defined", () => {
      expect(ALL_MODULES.length).toBe(9);
    });

    it("should contain all expected module IDs", () => {
      expect(ALL_MODULES).toContain("production");
      expect(ALL_MODULES).toContain("warehouse");
      expect(ALL_MODULES).toContain("quality");
      expect(ALL_MODULES).toContain("hr");
      expect(ALL_MODULES).toContain("finance");
      expect(ALL_MODULES).toContain("reports");
      expect(ALL_MODULES).toContain("alerts");
      expect(ALL_MODULES).toContain("sewing");
      expect(ALL_MODULES).toContain("import");
    });
  });
});
