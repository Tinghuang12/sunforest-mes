import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, adminProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";
import { sdk } from "./_core/sdk";
import bcrypt from "bcryptjs";

// ============================================================
// Worker Router
// ============================================================
const workerRouter = router({
  list: protectedProcedure
    .input(z.object({
      lineId: z.number().optional(),
      status: z.string().optional(),
      role: z.string().optional(),
      search: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listWorkers(input)),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getWorkerById(input.id)),

  getByCode: protectedProcedure
    .input(z.object({ code: z.string() }))
    .query(({ input }) => db.getWorkerByCode(input.code)),

  create: adminProcedure
    .input(z.object({
      employeeCode: z.string().min(1),
      name: z.string().min(1),
      nameVi: z.string().optional(),
      phone: z.string().optional(),
      workerRole: z.enum(["worker", "leader", "line_leader", "supervisor", "deputy_manager", "manager", "director", "general_manager"]).default("worker"),
      lineId: z.number().optional(),
      hourlyRate: z.string().optional(),
      pieceRate: z.string().optional(),
      joinDate: z.string().optional(),
      permissions: z.string().optional(),
    }))
    .mutation(({ input }) => db.createWorker({
      ...input,
      joinDate: input.joinDate ? new Date(input.joinDate) : undefined,
    } as any)),

  update: adminProcedure
    .input(z.object({
      id: z.number(),
      employeeCode: z.string().optional(),
      name: z.string().optional(),
      nameVi: z.string().optional(),
      phone: z.string().optional(),
      workerRole: z.enum(["worker", "leader", "line_leader", "supervisor", "deputy_manager", "manager", "director", "general_manager"]).optional(),
      lineId: z.number().nullable().optional(),
      status: z.enum(["active", "inactive"]).optional(),
      hourlyRate: z.string().optional(),
      pieceRate: z.string().optional(),
      joinDate: z.string().optional(),
      permissions: z.string().nullable().optional(),
    }))
    .mutation(({ input }) => {
      const { id, joinDate, ...rest } = input;
      return db.updateWorker(id, {
        ...rest,
        ...(joinDate ? { joinDate: new Date(joinDate) } : {}),
      } as any);
    }),

  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(({ input }) => db.deleteWorker(input.id)),
});

// ============================================================
// Production Line Router
// ============================================================
const lineRouter = router({
  list: protectedProcedure
    .input(z.object({
      type: z.string().optional(),
      status: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listProductionLines(input)),

  create: adminProcedure
    .input(z.object({
      name: z.string().min(1),
      nameVi: z.string().optional(),
      type: z.enum(["cutting", "sewing", "ironing", "qc", "packing", "shipping"]).default("sewing"),
      leaderId: z.number().optional(),
      capacity: z.number().optional(),
    }))
    .mutation(({ input }) => db.createProductionLine(input as any)),

  update: adminProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      nameVi: z.string().optional(),
      type: z.enum(["cutting", "sewing", "ironing", "qc", "packing", "shipping"]).optional(),
      leaderId: z.number().nullable().optional(),
      capacity: z.number().optional(),
      status: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...rest } = input;
      return db.updateProductionLine(id, rest as any);
    }),
});

// ============================================================
// Customer Router
// ============================================================
const customerRouter = router({
  list: protectedProcedure.query(() => db.listCustomers()),

  create: adminProcedure
    .input(z.object({
      name: z.string().min(1),
      contactPerson: z.string().optional(),
      phone: z.string().optional(),
      email: z.string().optional(),
      address: z.string().optional(),
    }))
    .mutation(({ input }) => db.createCustomer(input as any)),

  update: adminProcedure
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      contactPerson: z.string().optional(),
      phone: z.string().optional(),
      email: z.string().optional(),
      address: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...rest } = input;
      return db.updateCustomer(id, rest as any);
    }),
});

// ============================================================
// Order Router
// ============================================================
const orderRouter = router({
  list: protectedProcedure
    .input(z.object({
      status: z.string().optional(),
      customerId: z.number().optional(),
      search: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listOrders(input)),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getOrderById(input.id)),

  getDetails: protectedProcedure
    .input(z.object({ orderId: z.number() }))
    .query(({ input }) => db.listOrderDetails(input.orderId)),

  create: adminProcedure
    .input(z.object({
      orderNo: z.string().min(1),
      customerId: z.number(),
      styleNo: z.string().min(1),
      styleName: z.string().optional(),
      totalQty: z.number().default(0),
      deliveryDate: z.string().optional(),
      notes: z.string().optional(),
      details: z.array(z.object({
        size: z.string(),
        color: z.string(),
        qty: z.number(),
      })).optional(),
    }))
    .mutation(async ({ input }) => {
      const { details, deliveryDate, ...orderData } = input;
      const result = await db.createOrder({
        ...orderData,
        deliveryDate: deliveryDate ? new Date(deliveryDate) : undefined,
      } as any);
      if (details && details.length > 0) {
        for (const detail of details) {
          await db.createOrderDetail({ orderId: result.id, ...detail } as any);
        }
      }
      return result;
    }),

  update: adminProcedure
    .input(z.object({
      id: z.number(),
      orderNo: z.string().optional(),
      customerId: z.number().optional(),
      styleNo: z.string().optional(),
      styleName: z.string().optional(),
      totalQty: z.number().optional(),
      deliveryDate: z.string().optional(),
      status: z.enum(["pending", "scheduled", "in_production", "completed", "shipped"]).optional(),
      notes: z.string().optional(),
      details: z.array(z.object({
        size: z.string(),
        color: z.string(),
        qty: z.number(),
      })).optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, details, deliveryDate, ...rest } = input;
      await db.updateOrder(id, {
        ...rest,
        ...(deliveryDate ? { deliveryDate: new Date(deliveryDate) } : {}),
      } as any);
      if (details) {
        await db.deleteOrderDetails(id);
        for (const detail of details) {
          await db.createOrderDetail({ orderId: id, ...detail } as any);
        }
      }
    }),
});

// ============================================================
// Work Order Router
// ============================================================
const workOrderRouter = router({
  list: protectedProcedure
    .input(z.object({
      orderId: z.number().optional(),
      lineId: z.number().optional(),
      status: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listWorkOrders(input)),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getWorkOrderById(input.id)),

  create: adminProcedure
    .input(z.object({
      workOrderNo: z.string().min(1),
      orderId: z.number(),
      lineId: z.number().optional(),
      targetQty: z.number().default(0),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { startDate, endDate, ...rest } = input;
      return db.createWorkOrder({
        ...rest,
        ...(startDate ? { startDate: new Date(startDate) } : {}),
        ...(endDate ? { endDate: new Date(endDate) } : {}),
      } as any);
    }),

  update: adminProcedure
    .input(z.object({
      id: z.number(),
      lineId: z.number().nullable().optional(),
      targetQty: z.number().optional(),
      completedQty: z.number().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
      status: z.enum(["pending", "in_progress", "completed", "cancelled"]).optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, startDate, endDate, ...rest } = input;
      return db.updateWorkOrder(id, {
        ...rest,
        ...(startDate ? { startDate: new Date(startDate) } : {}),
        ...(endDate ? { endDate: new Date(endDate) } : {}),
      } as any);
    }),
});

// ============================================================
// Material Router
// ============================================================
const materialRouter = router({
  list: protectedProcedure
    .input(z.object({
      type: z.string().optional(),
      search: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listMaterials(input)),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getMaterialById(input.id)),

  lowStock: protectedProcedure.query(() => db.getLowStockMaterials()),

  create: adminProcedure
    .input(z.object({
      code: z.string().min(1),
      name: z.string().min(1),
      nameVi: z.string().optional(),
      type: z.enum(["fabric", "accessory"]).default("fabric"),
      unit: z.string().default("m"),
      color: z.string().optional(),
      batchNo: z.string().optional(),
      currentStock: z.string().optional(),
      safetyStock: z.string().optional(),
    }))
    .mutation(({ input }) => db.createMaterial(input as any)),

  update: adminProcedure
    .input(z.object({
      id: z.number(),
      code: z.string().optional(),
      name: z.string().optional(),
      nameVi: z.string().optional(),
      type: z.enum(["fabric", "accessory"]).optional(),
      unit: z.string().optional(),
      color: z.string().optional(),
      batchNo: z.string().optional(),
      currentStock: z.string().optional(),
      safetyStock: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...rest } = input;
      return db.updateMaterial(id, rest as any);
    }),

  transactions: protectedProcedure
    .input(z.object({
      materialId: z.number().optional(),
      type: z.string().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listMaterialTransactions(input)),

  createTransaction: protectedProcedure
    .input(z.object({
      materialId: z.number(),
      type: z.enum(["in", "out", "return"]),
      qty: z.string(),
      orderId: z.number().optional(),
      workOrderId: z.number().optional(),
      operatorId: z.number().optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => db.createMaterialTransaction(input as any)),
});

// ============================================================
// Production Report Router
// ============================================================
const productionRouter = router({
  list: protectedProcedure
    .input(z.object({
      workOrderId: z.number().optional(),
      workerId: z.number().optional(),
      lineId: z.number().optional(),
      station: z.string().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listProductionReports(input)),

  create: protectedProcedure
    .input(z.object({
      workOrderId: z.number(),
      workerId: z.number(),
      lineId: z.number().optional(),
      station: z.enum(["cutting", "sewing", "ironing", "packing"]),
      qty: z.number().min(0),
      defectQty: z.number().default(0),
      reportDate: z.string(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { reportDate, ...rest } = input;
      return db.createProductionReport({
        ...rest,
        reportDate: new Date(reportDate),
      } as any);
    }),
});

// ============================================================
// QC Router
// ============================================================
const qcRouter = router({
  list: protectedProcedure
    .input(z.object({
      workOrderId: z.number().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listQcInspections(input)),

  defects: protectedProcedure
    .input(z.object({ inspectionId: z.number() }))
    .query(({ input }) => db.listDefectRecords(input.inspectionId)),

  create: protectedProcedure
    .input(z.object({
      workOrderId: z.number(),
      inspectorId: z.number(),
      productName: z.string().optional(),
      productNo: z.string().optional(),
      inspectedQty: z.number(),
      passQty: z.number(),
      failQty: z.number(),
      inspectionDate: z.string(),
      notes: z.string().optional(),
      defects: z.array(z.object({
        defectType: z.enum(["hole", "skip_stitch", "color_diff", "size_deviation", "stain", "broken_thread", "misalignment", "other"]),
        qty: z.number().default(1),
        notes: z.string().optional(),
      })).optional(),
    }))
    .mutation(async ({ input }) => {
      const { defects, inspectionDate, ...rest } = input;
      const result = await db.createQcInspection({
        ...rest,
        inspectionDate: new Date(inspectionDate),
      } as any);
      if (defects && defects.length > 0) {
        for (const defect of defects) {
          await db.createDefectRecord({ inspectionId: result.id, ...defect } as any);
        }
      }
      return result;
    }),

  updateDefect: protectedProcedure
    .input(z.object({
      id: z.number(),
      repaired: z.enum(["pending", "repaired", "scrapped"]).optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...rest } = input;
      return db.updateDefectRecord(id, rest as any);
    }),
});

// ============================================================
// Attendance Router
// ============================================================
const attendanceRouter = router({
  list: protectedProcedure
    .input(z.object({
      workerId: z.number().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
      status: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listAttendance(input)),

  checkIn: protectedProcedure
    .input(z.object({
      workerId: z.number(),
      date: z.string(),
    }))
    .mutation(async ({ input }) => {
      const existing = await db.getAttendanceByWorkerAndDate(input.workerId, input.date);
      if (existing) {
        return { id: existing.id, message: "already_checked_in" };
      }
      return db.createAttendance({
        workerId: input.workerId,
        attendanceDate: new Date(input.date),
        checkIn: new Date(),
        status: "present",
      } as any);
    }),

  checkOut: protectedProcedure
    .input(z.object({
      workerId: z.number(),
      date: z.string(),
    }))
    .mutation(async ({ input }) => {
      const existing = await db.getAttendanceByWorkerAndDate(input.workerId, input.date);
      if (!existing) {
        return { message: "not_checked_in" };
      }
      await db.updateAttendance(existing.id, { checkOut: new Date() });
      return { id: existing.id, message: "checked_out" };
    }),

  update: adminProcedure
    .input(z.object({
      id: z.number(),
      status: z.enum(["present", "absent", "late", "half_day", "leave"]).optional(),
      overtimeHours: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...rest } = input;
      return db.updateAttendance(id, rest as any);
    }),
});

// ============================================================
// Shipment Router
// ============================================================
const shipmentRouter = router({
  list: protectedProcedure
    .input(z.object({
      orderId: z.number().optional(),
      status: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listShipments(input)),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getShipmentById(input.id)),

  packingDetails: protectedProcedure
    .input(z.object({ shipmentId: z.number() }))
    .query(({ input }) => db.listPackingDetails(input.shipmentId)),

  create: adminProcedure
    .input(z.object({
      shipmentNo: z.string().optional(),
      orderId: z.number().optional(),
      orderNo: z.string().optional(),
      customerName: z.string().optional(),
      productName: z.string().optional(),
      productNo: z.string().optional(),
      plannedDate: z.string().optional(),
      totalBoxes: z.number().optional(),
      totalQty: z.number().optional(),
      destination: z.string().optional(),
      notes: z.string().optional(),
      packingDetails: z.array(z.object({
        boxNo: z.string(),
        size: z.string().optional(),
        color: z.string().optional(),
        qty: z.number(),
        netWeight: z.string().optional(),
        grossWeight: z.string().optional(),
      })).optional(),
    }))
    .mutation(async ({ input }) => {
      const { packingDetails: details, plannedDate, ...rest } = input;
      const result = await db.createShipment({
        ...rest,
        ...(plannedDate ? { plannedDate: new Date(plannedDate) } : {}),
      } as any);
      if (details && details.length > 0) {
        for (const detail of details) {
          await db.createPackingDetail({ shipmentId: result.id, ...detail } as any);
        }
      }
      return result;
    }),

  update: adminProcedure
    .input(z.object({
      id: z.number(),
      plannedDate: z.string().optional(),
      actualDate: z.string().optional(),
      totalBoxes: z.number().optional(),
      totalQty: z.number().optional(),
      status: z.enum(["planned", "packing", "shipped", "delivered"]).optional(),
      destination: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, plannedDate, actualDate, ...rest } = input;
      return db.updateShipment(id, {
        ...rest,
        ...(plannedDate ? { plannedDate: new Date(plannedDate) } : {}),
        ...(actualDate ? { actualDate: new Date(actualDate) } : {}),
      } as any);
    }),
});

// ============================================================
// Dashboard Router
// ============================================================
const dashboardRouter = router({
  stats: protectedProcedure.query(() => db.getDashboardStats()),

  productionEfficiency: protectedProcedure
    .input(z.object({ startDate: z.string(), endDate: z.string() }))
    .query(({ input }) => db.getProductionEfficiency(input.startDate, input.endDate)),

  defectRate: protectedProcedure
    .input(z.object({ startDate: z.string(), endDate: z.string() }))
    .query(({ input }) => db.getDefectRateStats(input.startDate, input.endDate)),

  workerProductivity: protectedProcedure
    .input(z.object({ startDate: z.string(), endDate: z.string() }))
    .query(({ input }) => db.getWorkerProductivity(input.startDate, input.endDate)),

  dailyProduction: protectedProcedure
    .input(z.object({ startDate: z.string(), endDate: z.string() }))
    .query(({ input }) => db.getDailyProduction(input.startDate, input.endDate)),
});

// ============================================================
// Sewing Process Router
// ============================================================
const sewingProcessRouter = router({
  list: protectedProcedure
    .input(z.object({ status: z.string().optional() }).optional())
    .query(({ input }) => db.listSewingProcesses(input)),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getSewingProcessById(input.id)),

  create: adminProcedure
    .input(z.object({
      code: z.string().min(1),
      name: z.string().min(1),
      nameVi: z.string().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(({ input }) => db.createSewingProcess(input as any)),

  update: adminProcedure
    .input(z.object({
      id: z.number(),
      code: z.string().optional(),
      name: z.string().optional(),
      nameVi: z.string().optional(),
      sortOrder: z.number().optional(),
      status: z.enum(["active", "inactive"]).optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...rest } = input;
      return db.updateSewingProcess(id, rest as any);
    }),

  delete: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(({ input }) => db.deleteSewingProcess(input.id)),
});

// ============================================================
// Warehouse Transaction Router
// ============================================================
const warehouseRouter = router({
  transactions: protectedProcedure
    .input(z.object({
      materialId: z.number().optional(),
      type: z.string().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
    }).optional())
    .query(({ input }) => db.listWarehouseTransactions(input)),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(({ input }) => db.getWarehouseTransactionById(input.id)),

  inventory: protectedProcedure.query(() => db.getWarehouseInventory()),

  create: protectedProcedure
    .input(z.object({
      transactionNo: z.string().min(1),
      type: z.enum(["receive", "issue", "transfer", "adjust"]),
      materialId: z.number(),
      qty: z.string(),
      fromLocation: z.string().optional(),
      toLocation: z.string().optional(),
      orderId: z.number().optional(),
      workOrderId: z.number().optional(),
      operatorId: z.number().optional(),
      notes: z.string().optional(),
      transactionDate: z.string(),
    }))
    .mutation(({ input }) => {
      const { transactionDate, ...rest } = input;
      return db.createWarehouseTransaction({
        ...rest,
        transactionDate: new Date(transactionDate),
      } as any);
    }),

  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      fromLocation: z.string().optional(),
      toLocation: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...rest } = input;
      return db.updateWarehouseTransaction(id, rest as any);
    }),
});

// ============================================================
// Salary Router
// ============================================================
const salaryRouter = router({
  calculateMonthly: protectedProcedure
    .input(z.object({
      year: z.number(),
      month: z.number(),
      workerId: z.number().optional(),
    }))
    .query(({ input }) => db.getSalaryByMonth(input.year, input.month, input.workerId)),

  getByWorker: protectedProcedure
    .input(z.object({
      workerId: z.number(),
      startDate: z.string(),
      endDate: z.string(),
    }))
    .query(({ input }) => db.calculateWorkerSalary(
      input.workerId,
      new Date(input.startDate),
      new Date(input.endDate)
    )),
});

// ============================================================
// Import Router (Bulk Import)
// ============================================================
const importRouter = router({
  workers: adminProcedure
    .input(z.object({
      rows: z.array(z.object({
        employeeCode: z.string().min(1),
        name: z.string().optional(), // 中文姓名選填
        nameVi: z.string().optional(),
        phone: z.string().optional(),
        workerRole: z.string().optional(), // 自由輸入，不限語種
        lineId: z.number().optional(),
        salaryType: z.enum(["hourly", "monthly"]).optional(),
        monthlySalary: z.string().optional(),
        hourlyRate: z.string().optional(),
        pieceRate: z.string().optional(),
        joinDate: z.string().optional(),
      })),
    }))
    .mutation(async ({ input }) => {
      const mapped = input.rows.map(r => ({
        ...r,
        joinDate: r.joinDate || undefined,
      } as any));
      return db.bulkCreateWorkers(mapped);
    }),

  customers: adminProcedure
    .input(z.object({
      rows: z.array(z.object({
        name: z.string().min(1),
        contactPerson: z.string().optional(),
        phone: z.string().optional(),
        email: z.string().optional(),
        address: z.string().optional(),
      })),
    }))
    .mutation(({ input }) => db.bulkCreateCustomers(input.rows as any)),

  materials: adminProcedure
    .input(z.object({
      rows: z.array(z.object({
        code: z.string().min(1),
        name: z.string().optional(), // 中文名稱選填
        nameVi: z.string().optional(),
        type: z.string().optional(), // 自由輸入，不限定 enum
        unit: z.string().optional(),
        color: z.string().optional(),
        batchNo: z.string().optional(),
        currentStock: z.string().optional(),
        safetyStock: z.string().optional(),
        warehouseLocation: z.string().optional(),
      })),
    }))
    .mutation(({ input }) => db.bulkCreateMaterials(input.rows as any)),

  orders: adminProcedure
    .input(z.object({
      rows: z.array(z.object({
        orderNo: z.string().min(1),
        customerId: z.number(),
        styleNo: z.string().min(1),
        styleName: z.string().optional(),
        totalQty: z.number().optional(),
        deliveryDate: z.string().optional(),
        notes: z.string().optional(),
      })),
    }))
    .mutation(async ({ input }) => {
      const mapped = input.rows.map(r => ({
        ...r,
        deliveryDate: r.deliveryDate || undefined,
      } as any));
      return db.bulkCreateOrders(mapped);
    }),
});

// ============================================================
// Alert Router (notifications & alert management)
// ============================================================
const alertRouter = router({
  // Get alert settings
  getSettings: adminProcedure.query(() => db.getAlertSettings()),

  // Update alert setting
  updateSetting: adminProcedure
    .input(z.object({
      id: z.number(),
      enabled: z.enum(["yes", "no"]).optional(),
      thresholdValue: z.string().optional(),
      thresholdValue2: z.string().nullable().optional(),
      description: z.string().optional(),
    }))
    .mutation(({ input }) => {
      const { id, ...data } = input;
      return db.updateAlertSetting(id, data);
    }),

  // Get alerts list
  list: protectedProcedure
    .input(z.object({
      isRead: z.string().optional(),
      alertType: z.string().optional(),
      limit: z.number().optional(),
    }).optional())
    .query(({ input }) => db.getAlerts(input)),

  // Get unread count
  unreadCount: protectedProcedure.query(() => db.getUnreadAlertCount()),

  // Mark single alert as read
  markRead: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(({ input }) => db.markAlertRead(input.id)),

  // Mark all alerts as read
  markAllRead: protectedProcedure
    .mutation(() => db.markAllAlertsRead()),

  // Resolve alert
  resolve: adminProcedure
    .input(z.object({ id: z.number() }))
    .mutation(({ input }) => db.resolveAlert(input.id)),

  // Run alert checks manually
  runChecks: adminProcedure.mutation(async () => {
    const settings = await db.getAlertSettings();
    const results: { type: string; count: number }[] = [];

    for (const setting of settings) {
      if (setting.enabled !== "yes") continue;

      if (setting.alertType === "low_stock") {
        const lowStockItems = await db.checkLowStockAlerts();
        for (const item of lowStockItems) {
          const severity = Number(item.currentStock) <= 0 ? "critical" : "warning";
          await db.createAlert({
            alertType: "low_stock",
            severity: severity as any,
            title: `Low Stock: ${item.name} (${item.code})`,
            message: `Current stock: ${item.currentStock} ${item.unit}, Safety stock: ${item.safetyStock} ${item.unit}`,
            referenceId: item.id,
            referenceType: "material",
          });
        }
        results.push({ type: "low_stock", count: lowStockItems.length });
      }

      if (setting.alertType === "delivery_approaching" || setting.alertType === "delivery_overdue") {
        const warningDays = Number(setting.thresholdValue) || 7;
        const criticalDays = Number(setting.thresholdValue2) || 3;
        const { approaching, overdue } = await db.checkDeliveryAlerts(warningDays, criticalDays);

        if (setting.alertType === "delivery_overdue") {
          for (const order of overdue) {
            await db.createAlert({
              alertType: "delivery_overdue",
              severity: "critical",
              title: `Delivery Overdue: ${order.orderNo}`,
              message: `Order ${order.orderNo} (${order.styleNo}) delivery date ${order.deliveryDate} has passed. Status: ${order.status}`,
              referenceId: order.id,
              referenceType: "order",
            });
          }
          results.push({ type: "delivery_overdue", count: overdue.length });
        }

        if (setting.alertType === "delivery_approaching") {
          for (const order of approaching) {
            const daysLeft = Math.ceil((new Date(order.deliveryDate!).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
            const severity = daysLeft <= criticalDays ? "critical" : "warning";
            await db.createAlert({
              alertType: "delivery_approaching",
              severity: severity as any,
              title: `Delivery Approaching: ${order.orderNo}`,
              message: `Order ${order.orderNo} (${order.styleNo}) due in ${daysLeft} day(s). Delivery date: ${order.deliveryDate}`,
              referenceId: order.id,
              referenceType: "order",
            });
          }
          results.push({ type: "delivery_approaching", count: approaching.length });
        }
      }

      if (setting.alertType === "high_defect_rate") {
        const warningRate = Number(setting.thresholdValue) || 5;
        const criticalRate = Number(setting.thresholdValue2) || 10;
        const highDefects = await db.checkDefectRateAlerts(warningRate, criticalRate);
        for (const insp of highDefects) {
          await db.createAlert({
            alertType: "high_defect_rate",
            severity: (insp.severity === "critical" ? "critical" : "warning") as any,
            title: `High Defect Rate: ${insp.defectRate.toFixed(1)}%`,
            message: `QC Inspection #${insp.id}: ${insp.failQty}/${insp.inspectedQty} failed (${insp.defectRate.toFixed(1)}%)`,
            referenceId: insp.id,
            referenceType: "qc_inspection",
          });
        }
        results.push({ type: "high_defect_rate", count: highDefects.length });
      }
    }

    return { success: true, results };
  }),
});

// ============================================================
// Account Router (Registration, Login, Approval)
// ============================================================
const accountRouter = router({
  register: publicProcedure
    .input(z.object({
      username: z.string().min(3).max(50).regex(/^[a-zA-Z0-9_]+$/, "Username can only contain letters, numbers and underscores"),
      password: z.string().min(6).max(100),
      name: z.string().min(1).max(100),
      phone: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const existing = await db.getUserByUsername(input.username);
      if (existing) throw new TRPCError({ code: "CONFLICT", message: "Username already exists" });
      const passwordHash = await bcrypt.hash(input.password, 10);
      const user = await db.createLocalUser({
        username: input.username,
        passwordHash,
        name: input.name,
        phone: input.phone,
      });
      return { success: true, message: "Registration submitted, waiting for admin approval" };
    }),

  login: publicProcedure
    .input(z.object({
      username: z.string().min(1),
      password: z.string().min(1),
    }))
    .mutation(async ({ input, ctx }) => {
      const user = await db.getUserByUsername(input.username);
      if (!user || !user.passwordHash) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid username or password" });
      const valid = await bcrypt.compare(input.password, user.passwordHash);
      if (!valid) throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid username or password" });
      if (user.approvalStatus === "pending") {
        return { success: false, status: "pending" as const, message: "Account pending approval" };
      }
      if (user.approvalStatus === "rejected") {
        return { success: false, status: "rejected" as const, message: "Account has been rejected" };
      }
      // Create session token
      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || user.username || "",
        expiresInMs: ONE_YEAR_MS,
      });
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      // Update last signed in
      await db.upsertUser({ openId: user.openId, lastSignedIn: new Date() });
      return { success: true, status: "approved" as const, message: "Login successful" };
    }),

  // Admin: list all users
  listUsers: adminProcedure.query(() => db.listAllUsers()),

  // Admin: list pending users
  listPending: adminProcedure.query(() => db.listPendingUsers()),

  // Admin: approve user
  approve: adminProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      await db.updateUserApproval(input.userId, "approved");
      return { success: true };
    }),

  // Admin: reject user
  reject: adminProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      await db.updateUserApproval(input.userId, "rejected");
      return { success: true };
    }),

  // Admin: update user role
  updateRole: adminProcedure
    .input(z.object({
      userId: z.number(),
      role: z.enum(["admin", "user"]),
    }))
    .mutation(async ({ input }) => {
      await db.updateUserRole(input.userId, input.role);
      return { success: true };
    }),

  // Admin: update user name (for linking to worker record)
  updateName: adminProcedure
    .input(z.object({
      userId: z.number(),
      name: z.string().min(1).max(100),
    }))
    .mutation(async ({ input }) => {
      await db.updateUserName(input.userId, input.name);
      return { success: true };
    }),

  // Admin: reset user password
  resetPassword: adminProcedure
    .input(z.object({
      userId: z.number(),
      newPassword: z.string().min(6).max(100),
    }))
    .mutation(async ({ input }) => {
      const passwordHash = await bcrypt.hash(input.newPassword, 10);
      const dbConn = await (await import("./db")).getDb();
      if (!dbConn) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const { users } = await import("../drizzle/schema");
      const { eq } = await import("drizzle-orm");
      await dbConn.update(users).set({ passwordHash }).where(eq(users.id, input.userId));
      return { success: true };
    }),

  // Get pending count for badge
  pendingCount: protectedProcedure.query(async () => {
    const pending = await db.listPendingUsers();
    return pending.length;
  }),
});

// ============================================================
// App Router
// ============================================================
export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  account: accountRouter,
  worker: workerRouter,
  line: lineRouter,
  customer: customerRouter,
  order: orderRouter,
  workOrder: workOrderRouter,
  material: materialRouter,
  production: productionRouter,
  qc: qcRouter,
  attendance: attendanceRouter,
  shipment: shipmentRouter,
  dashboard: dashboardRouter,
  sewingProcess: sewingProcessRouter,
  warehouse: warehouseRouter,
  salary: salaryRouter,
  import: importRouter,
  alert: alertRouter,
});

export type AppRouter = typeof appRouter;
