import { describe, expect, it, vi, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@factory.com",
    name: "Factory Admin",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

function createWorkerContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "worker-user",
    email: "worker@factory.com",
    name: "Worker User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

function createUnauthContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

describe("MES Router Structure", () => {
  it("should have all required routers defined", () => {
    const caller = appRouter.createCaller(createAdminContext());
    // Verify all routers exist by checking they are callable
    expect(caller.auth).toBeDefined();
    expect(caller.worker).toBeDefined();
    expect(caller.line).toBeDefined();
    expect(caller.customer).toBeDefined();
    expect(caller.order).toBeDefined();
    expect(caller.workOrder).toBeDefined();
    expect(caller.material).toBeDefined();
    expect(caller.production).toBeDefined();
    expect(caller.qc).toBeDefined();
    expect(caller.attendance).toBeDefined();
    expect(caller.shipment).toBeDefined();
    expect(caller.dashboard).toBeDefined();
  });
});

describe("Auth & Role-based Access", () => {
  it("should return user info for authenticated user", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    const me = await caller.auth.me();
    expect(me).toBeDefined();
    expect(me?.role).toBe("admin");
    expect(me?.name).toBe("Factory Admin");
  });

  it("should return null for unauthenticated user", async () => {
    const ctx = createUnauthContext();
    const caller = appRouter.createCaller(ctx);
    const me = await caller.auth.me();
    expect(me).toBeNull();
  });

  it("should reject unauthenticated access to protected procedures", async () => {
    const ctx = createUnauthContext();
    const caller = appRouter.createCaller(ctx);
    await expect(caller.worker.list()).rejects.toThrow();
  });

  it("should reject non-admin access to admin procedures", async () => {
    const ctx = createWorkerContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.worker.create({
        employeeCode: "W001",
        name: "Test Worker",
      })
    ).rejects.toThrow();
  });
});

describe("Worker Router Input Validation", () => {
  it("should reject worker creation with empty name", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.worker.create({
        employeeCode: "W001",
        name: "",
      })
    ).rejects.toThrow();
  });

  it("should reject worker creation with empty employee code", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.worker.create({
        employeeCode: "",
        name: "Test",
      })
    ).rejects.toThrow();
  });
});

describe("Order Router Input Validation", () => {
  it("should reject order creation with empty orderNo", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.order.create({
        orderNo: "",
        customerId: 1,
        styleNo: "S001",
      })
    ).rejects.toThrow();
  });

  it("should reject order creation with empty styleNo", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.order.create({
        orderNo: "ORD001",
        customerId: 1,
        styleNo: "",
      })
    ).rejects.toThrow();
  });
});

describe("Work Order Router Input Validation", () => {
  it("should reject work order creation with empty workOrderNo", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.workOrder.create({
        workOrderNo: "",
        orderId: 1,
      })
    ).rejects.toThrow();
  });
});

describe("Material Router Input Validation", () => {
  it("should reject material creation with empty code", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.material.create({
        code: "",
        name: "Test Fabric",
      })
    ).rejects.toThrow();
  });

  it("should reject material creation with empty name", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.material.create({
        code: "MAT001",
        name: "",
      })
    ).rejects.toThrow();
  });
});

describe("Production Report Input Validation", () => {
  it("should reject production report with negative qty", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.production.create({
        workOrderId: 1,
        workerId: 1,
        station: "sewing",
        qty: -5,
        reportDate: "2026-03-22",
      })
    ).rejects.toThrow();
  });

  it("should reject production report with invalid station", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.production.create({
        workOrderId: 1,
        workerId: 1,
        station: "invalid_station" as any,
        qty: 10,
        reportDate: "2026-03-22",
      })
    ).rejects.toThrow();
  });
});

describe("QC Router Input Validation", () => {
  it("should reject QC inspection with invalid defect type", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.qc.create({
        workOrderId: 1,
        inspectorId: 1,
        inspectedQty: 100,
        passQty: 95,
        failQty: 5,
        inspectionDate: "2026-03-22",
        defects: [{ defectType: "invalid_type" as any, qty: 5 }],
      })
    ).rejects.toThrow();
  });
});

describe("Shipment Router Input Validation", () => {
  it("should accept shipment creation with optional fields", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    // shipmentNo and orderId are now optional, this should pass input validation
    // (may fail on DB insert but input schema should accept it)
    try {
      await caller.shipment.create({
        orderNo: "ORD-001",
        customerName: "Test Customer",
        productName: "Test Product",
        productNo: "TP-001",
      });
    } catch (e: any) {
      // DB errors are acceptable, but input validation errors are not
      expect(e.code).not.toBe("BAD_REQUEST");
    }
  });
});

describe("Line Router Input Validation", () => {
  it("should reject line creation with empty name", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.line.create({
        name: "",
      })
    ).rejects.toThrow();
  });

  it("should accept valid line type enum values", async () => {
    // This should not throw on input validation (may fail on DB)
    const caller = appRouter.createCaller(createAdminContext());
    const validTypes = ["cutting", "sewing", "ironing", "qc", "packing", "shipping"] as const;
    for (const type of validTypes) {
      // Just validate the input parsing works - DB errors are expected
      try {
        await caller.line.create({ name: `Line ${type}`, type });
      } catch (e: any) {
        // DB errors are OK, input validation errors are not
        expect(e.code).not.toBe("BAD_REQUEST");
      }
    }
  });
});

describe("Attendance Router Input Validation", () => {
  it("should accept valid attendance status values", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    const validStatuses = ["present", "absent", "late", "half_day", "leave"] as const;
    for (const status of validStatuses) {
      try {
        await caller.attendance.update({ id: 999, status });
      } catch (e: any) {
        // DB errors are OK, validation errors are not
        expect(e.code).not.toBe("BAD_REQUEST");
      }
    }
  });
});

describe("Customer Router Input Validation", () => {
  it("should reject customer creation with empty name", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(
      caller.customer.create({
        name: "",
      })
    ).rejects.toThrow();
  });
});


// ============================================================
// Salary Calculation Tests
// ============================================================
describe("Salary Calculation", () => {
  it("should calculate monthly salary correctly", () => {
    const mockWorker = {
      salaryType: "monthly" as const,
      monthlySalary: 1000,
      hourlyRate: 0,
      pieceRate: 0,
    };

    expect(mockWorker.monthlySalary).toBe(1000);
    expect(mockWorker.salaryType).toBe("monthly");
  });

  it("should calculate hourly salary correctly", () => {
    const mockWorker = {
      salaryType: "hourly" as const,
      monthlySalary: 0,
      hourlyRate: 10,
      pieceRate: 0,
    };

    const workingDays = 20;
    const hoursPerDay = 8;
    const totalHours = workingDays * hoursPerDay;
    const expectedSalary = totalHours * mockWorker.hourlyRate;

    expect(expectedSalary).toBe(1600);
  });

  it("should calculate piece rate salary correctly", () => {
    const mockWorker = {
      salaryType: "monthly" as const,
      monthlySalary: 0,
      hourlyRate: 0,
      pieceRate: 5,
    };

    const totalQty = 200;
    const expectedSalary = totalQty * mockWorker.pieceRate;

    expect(expectedSalary).toBe(1000);
  });

  it("should have salary router defined", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    expect(caller.salary).toBeDefined();
  });
});

// ============================================================
// Bulk Import Tests
// ============================================================
describe("import.workers", () => {
  it("rejects non-admin users", async () => {
    const ctx = createWorkerContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.import.workers({
        rows: [{ employeeCode: "NV999", name: "Test Worker" }],
      })
    ).rejects.toThrow();
  });

  it("accepts valid worker import data", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    // This will fail at DB level in test env, but validates input schema
    try {
      await caller.import.workers({
        rows: [
          { employeeCode: "NV001", name: "Worker 1", salaryType: "monthly", monthlySalary: "7000000" },
          { employeeCode: "NV002", name: "Worker 2", salaryType: "hourly", hourlyRate: "35000" },
        ],
      });
    } catch (e: any) {
      // DB error is expected in test env, but input validation should pass
      expect(e.message).not.toContain("invalid_type");
    }
  });

  it("validates required fields", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.import.workers({
        rows: [{ employeeCode: "", name: "Test" }],
      })
    ).rejects.toThrow();
  });
});

describe("import.customers", () => {
  it("rejects non-admin users", async () => {
    const ctx = createWorkerContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.import.customers({
        rows: [{ name: "Test Customer" }],
      })
    ).rejects.toThrow();
  });

  it("accepts valid customer import data", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.import.customers({
        rows: [
          { name: "Customer A", contactPerson: "John", email: "john@test.com" },
          { name: "Customer B", phone: "+84-123-456" },
        ],
      });
    } catch (e: any) {
      expect(e.message).not.toContain("invalid_type");
    }
  });
});

describe("import.materials", () => {
  it("rejects non-admin users", async () => {
    const ctx = createWorkerContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.import.materials({
        rows: [{ code: "FB-001", name: "Cotton" }],
      })
    ).rejects.toThrow();
  });

  it("accepts valid material import data", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.import.materials({
        rows: [
          { code: "FB-001", name: "Cotton", type: "fabric", unit: "m", currentStock: "1000" },
          { code: "AC-001", name: "Zipper", type: "accessory", unit: "pcs" },
        ],
      });
    } catch (e: any) {
      expect(e.message).not.toContain("invalid_type");
    }
  });
});

describe("import.orders", () => {
  it("rejects non-admin users", async () => {
    const ctx = createWorkerContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.import.orders({
        rows: [{ orderNo: "PO-001", customerId: 1, styleNo: "ST-001" }],
      })
    ).rejects.toThrow();
  });

  it("accepts valid order import data", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);
    try {
      await caller.import.orders({
        rows: [
          { orderNo: "PO-001", customerId: 1, styleNo: "ST-001", totalQty: 5000, deliveryDate: "2024-06-30" },
        ],
      });
    } catch (e: any) {
      expect(e.message).not.toContain("invalid_type");
    }
  });
});
