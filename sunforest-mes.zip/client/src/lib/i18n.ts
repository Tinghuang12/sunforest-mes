import { createContext, useContext } from "react";

export type Locale = "vi" | "zh";

export const translations: Record<string, Record<Locale, string>> = {
  // ============================================================
  // Common
  // ============================================================
  "common.add": { vi: "Thêm", zh: "新增" },
  "common.create": { vi: "Tạo mới", zh: "建立" },
  "common.edit": { vi: "Sửa", zh: "編輯" },
  "common.delete": { vi: "Xóa", zh: "刪除" },
  "common.save": { vi: "Lưu", zh: "保存" },
  "common.cancel": { vi: "Hủy", zh: "取消" },
  "common.search": { vi: "Tìm kiếm", zh: "搜尋" },
  "common.filter": { vi: "Lọc", zh: "篩選" },
  "common.export": { vi: "Xuất", zh: "匯出" },
  "common.import": { vi: "Nhập", zh: "匯入" },
  "common.loading": { vi: "Đang tải...", zh: "載入中..." },
  "common.noData": { vi: "Không có dữ liệu", zh: "沒有資料" },
  "common.error": { vi: "Lỗi", zh: "錯誤" },
  "common.success": { vi: "Thành công", zh: "成功" },
  "common.confirm": { vi: "Bạn có chắc chắn?", zh: "您確定嗎？" },
  "common.actions": { vi: "Hành động", zh: "操作" },
  "common.status": { vi: "Trạng thái", zh: "狀態" },
  "common.active": { vi: "Hoạt động", zh: "啟用" },
  "common.inactive": { vi: "Không hoạt động", zh: "停用" },
  "common.qty": { vi: "Số lượng", zh: "數量" },
  "common.total": { vi: "Tổng cộng", zh: "合計" },
  "common.notes": { vi: "Ghi chú", zh: "備註" },
  "common.all": { vi: "Tất cả", zh: "全部" },
  "common.date": { vi: "Ngày", zh: "日期" },
  "common.today": { vi: "Hôm nay", zh: "今天" },
  "common.signOut": { vi: "Đăng xuất", zh: "登出" },

  // ============================================================
  // Navigation
  // ============================================================
  "nav.dashboard": { vi: "Bảng điều khiển", zh: "儀表板" },
  "nav.orders": { vi: "Đơn hàng", zh: "訂單" },
  "nav.workOrders": { vi: "Lệnh sản xuất", zh: "工單" },
  "nav.schedule": { vi: "Lịch sản xuất", zh: "排程" },
  "nav.production": { vi: "Báo cáo sản xuất", zh: "生產報工" },
  "nav.materials": { vi: "Vật liệu", zh: "物料" },
  "nav.qc": { vi: "Kiểm chất lượng", zh: "品質檢驗" },
  "nav.shipments": { vi: "Xuất hàng", zh: "出貨" },
  "nav.workers": { vi: "Nhân viên", zh: "員工" },
  "nav.attendance": { vi: "Chấm công", zh: "出勤" },
  "nav.lines": { vi: "Dây chuyền", zh: "產線" },
  "nav.customers": { vi: "Khách hàng", zh: "客戶" },
  "nav.reports": { vi: "Báo cáo", zh: "報表" },

  // ============================================================
  // Dashboard
  // ============================================================
  "dashboard.title": { vi: "Bảng điều khiển", zh: "儀表板" },
  "dashboard.totalWorkers": { vi: "Tổng nhân viên", zh: "員工總數" },
  "dashboard.totalOrders": { vi: "Tổng đơn hàng", zh: "訂單總數" },
  "dashboard.activeOrders": { vi: "Đơn hàng đang xử lý", zh: "進行中訂單" },
  "dashboard.pendingOrders": { vi: "Đơn hàng chờ xử lý", zh: "待處理訂單" },
  "dashboard.inProgressOrders": { vi: "Đơn hàng đang xử lý", zh: "進行中訂單" },
  "dashboard.completedOrders": { vi: "Đơn hàng hoàn thành", zh: "已完成訂單" },
  "dashboard.todayProduction": { vi: "Sản xuất hôm nay", zh: "今日產量" },
  "dashboard.todayAttendance": { vi: "Chấm công hôm nay", zh: "今日出勤" },
  "dashboard.defectRate": { vi: "Tỷ lệ lỗi", zh: "不良率" },
  "dashboard.productionTrend": { vi: "Xu hướng sản xuất", zh: "生產趨勢" },
  "dashboard.pendingShipments": { vi: "Lô hàng chờ xuất", zh: "待出貨" },

  // ============================================================
  // Orders
  // ============================================================
  "order.title": { vi: "Quản lý đơn hàng", zh: "訂單管理" },
  "order.code": { vi: "Mã đơn hàng", zh: "訂單編號" },
  "order.orderNo": { vi: "Số đơn hàng", zh: "訂單號" },
  "order.customer": { vi: "Khách hàng", zh: "客戶" },
  "order.qty": { vi: "Số lượng", zh: "數量" },
  "order.totalQty": { vi: "Tổng số lượng", zh: "總數量" },
  "order.dueDate": { vi: "Ngày hạn chót", zh: "交期" },
  "order.deliveryDate": { vi: "Ngày giao hàng", zh: "交貨日期" },
  "order.status": { vi: "Trạng thái", zh: "狀態" },
  "order.pending": { vi: "Chờ xử lý", zh: "待處理" },
  "order.scheduled": { vi: "Đã lên lịch", zh: "已排程" },
  "order.in_production": { vi: "Đang sản xuất", zh: "生產中" },
  "order.inProgress": { vi: "Đang xử lý", zh: "進行中" },
  "order.completed": { vi: "Hoàn thành", zh: "已完成" },
  "order.shipped": { vi: "Đã gửi", zh: "已出貨" },
  "order.styleNo": { vi: "Mã kiểu", zh: "款號" },
  "order.styleName": { vi: "Tên kiểu", zh: "款名" },
  "order.sizeColor": { vi: "Kích thước & Màu sắc", zh: "尺碼色號" },
  "order.newOrder": { vi: "Đơn hàng mới", zh: "新增訂單" },

  // ============================================================
  // Work Orders
  // ============================================================
  "wo.title": { vi: "Quản lý lệnh sản xuất", zh: "工單管理" },
  "wo.workOrderNo": { vi: "Số lệnh sản xuất", zh: "工單號" },
  "wo.line": { vi: "Dây chuyền", zh: "產線" },
  "wo.targetQty": { vi: "Số lượng mục tiêu", zh: "目標數量" },
  "wo.completedQty": { vi: "Số lượng hoàn thành", zh: "已完成數量" },
  "wo.progress": { vi: "Tiến độ", zh: "進度" },
  "wo.startDate": { vi: "Ngày bắt đầu", zh: "開始日期" },
  "wo.endDate": { vi: "Ngày kết thúc", zh: "結束日期" },
  "wo.pending": { vi: "Chờ xử lý", zh: "待處理" },
  "wo.in_progress": { vi: "Đang xử lý", zh: "進行中" },
  "wo.completed": { vi: "Hoàn thành", zh: "已完成" },
  "wo.cancelled": { vi: "Đã hủy", zh: "已取消" },
  "wo.newWorkOrder": { vi: "Lệnh sản xuất mới", zh: "新增工單" },
  "workOrder.title": { vi: "Quản lý lệnh sản xuất", zh: "工單管理" },
  "workOrder.code": { vi: "Mã lệnh", zh: "工單編號" },
  "workOrder.order": { vi: "Đơn hàng", zh: "訂單" },
  "workOrder.line": { vi: "Dây chuyền", zh: "產線" },
  "workOrder.status": { vi: "Trạng thái", zh: "狀態" },
  "workOrder.qty": { vi: "Số lượng", zh: "數量" },

  // ============================================================
  // Production
  // ============================================================
  "prod.title": { vi: "Báo cáo sản xuất", zh: "生產報工" },
  "prod.workOrder": { vi: "Lệnh sản xuất", zh: "工單" },
  "prod.worker": { vi: "Nhân viên", zh: "員工" },
  "prod.station": { vi: "Công đoạn", zh: "工段" },
  "prod.qty": { vi: "Số lượng", zh: "數量" },
  "prod.reportQty": { vi: "Số lượng báo cáo", zh: "報工數量" },
  "prod.defectQty": { vi: "Số lượng lỗi", zh: "不良數" },
  "prod.reportDate": { vi: "Ngày báo cáo", zh: "報工日期" },
  "prod.submitReport": { vi: "Gửi báo cáo", zh: "提交報工" },
  "prod.cutting": { vi: "Cắt", zh: "裁剪" },
  "prod.sewing": { vi: "May", zh: "縫製" },
  "prod.ironing": { vi: "Là", zh: "整燙" },
  "prod.packing": { vi: "Đóng gói", zh: "包裝" },

  // ============================================================
  // Materials
  // ============================================================
  "mat.title": { vi: "Quản lý vật liệu", zh: "物料管理" },
  "mat.code": { vi: "Mã vật liệu", zh: "物料代碼" },
  "mat.name": { vi: "Tên vật liệu", zh: "物料名稱" },
  "mat.type": { vi: "Loại", zh: "類型" },
  "mat.fabric": { vi: "Vải", zh: "布料" },
  "mat.accessory": { vi: "Phụ kiện", zh: "輔料" },
  "mat.unit": { vi: "Đơn vị", zh: "單位" },
  "mat.color": { vi: "Màu sắc", zh: "顏色" },
  "mat.batchNo": { vi: "Số lô", zh: "批號" },
  "mat.currentStock": { vi: "Tồn kho hiện tại", zh: "目前庫存" },
  "mat.safetyStock": { vi: "Tồn kho an toàn", zh: "安全庫存" },
  "mat.lowStock": { vi: "Tồn kho thấp", zh: "庫存不足" },
  "mat.stockIn": { vi: "Nhập kho", zh: "入庫" },
  "mat.stockOut": { vi: "Xuất kho", zh: "出庫" },
  "mat.stockReturn": { vi: "Trả kho", zh: "退料" },
  "mat.newMaterial": { vi: "Vật liệu mới", zh: "新增物料" },
  "material.title": { vi: "Quản lý vật liệu", zh: "物料管理" },
  "material.code": { vi: "Mã vật liệu", zh: "物料代碼" },
  "material.name": { vi: "Tên vật liệu", zh: "物料名稱" },
  "material.qty": { vi: "Số lượng", zh: "數量" },
  "material.unit": { vi: "Đơn vị", zh: "單位" },

  // ============================================================
  // Warehouse
  // ============================================================
  "warehouse.title": { vi: "Quản lý kho", zh: "倉庫管理" },
  "warehouse.inventory": { vi: "Tồn kho", zh: "庫存" },
  "warehouse.transactions": { vi: "Giao dịch kho", zh: "倉庫交易" },
  "warehouse.transactionNo": { vi: "Số giao dịch", zh: "交易編號" },
  "warehouse.transactionDate": { vi: "Ngày giao dịch", zh: "交易日期" },
  "warehouse.receive": { vi: "Nhập kho", zh: "入庫" },
  "warehouse.issue": { vi: "Xuất kho", zh: "出庫" },
  "warehouse.transfer": { vi: "Chuyển kho", zh: "調撥" },
  "warehouse.adjust": { vi: "Điều chỉnh", zh: "調整" },
  "warehouse.fromLocation": { vi: "Vị trí từ", zh: "來源位置" },
  "warehouse.toLocation": { vi: "Vị trí đến", zh: "目標位置" },
  "warehouse.materialName": { vi: "Tên vật liệu", zh: "物料名稱" },
  "warehouse.customType": { vi: "Loại giao dịch", zh: "交易類型" },

  // ============================================================
  // QC
  // ============================================================
  "qc.title": { vi: "Kiểm chất lượng", zh: "品質檢驗" },
  "qc.inspectionNo": { vi: "Số kiểm tra", zh: "檢驗編號" },
  "qc.workOrder": { vi: "Lệnh sản xuất", zh: "工單" },
  "qc.inspectedQty": { vi: "Số lượng kiểm tra", zh: "檢驗數量" },
  "qc.passQty": { vi: "Số lượng đạt", zh: "良品數" },
  "qc.failQty": { vi: "Số lượng không đạt", zh: "不良數" },
  "qc.goodQty": { vi: "Số lượng tốt", zh: "良品數" },
  "qc.defectQty": { vi: "Số lượng lỗi", zh: "不良數" },
  "qc.defectRate": { vi: "Tỷ lệ lỗi", zh: "不良率" },
  "qc.defectType": { vi: "Loại lỗi", zh: "不良分類" },
  "qc.inspector": { vi: "Người kiểm tra", zh: "檢驗員" },
  "qc.newInspection": { vi: "Kiểm tra mới", zh: "新增檢驗" },
  "qc.productName": { vi: "Tên sản phẩm", zh: "品名" },
  "qc.productNo": { vi: "Mã sản phẩm", zh: "品號" },
  "qc.hole": { vi: "Lỗ", zh: "破洞" },
  "qc.skip": { vi: "Bỏ qua", zh: "跳針" },
  "qc.colorDiff": { vi: "Khác màu", zh: "色差" },
  "qc.sizeDiff": { vi: "Khác kích thước", zh: "尺寸偏差" },

  // ============================================================
  // Workers
  // ============================================================
  "worker.title": { vi: "Quản lý nhân viên", zh: "員工管理" },
  "worker.code": { vi: "Mã nhân viên", zh: "員工編號" },
  "worker.name": { vi: "Tên", zh: "姓名" },
  "worker.nameVi": { vi: "Tên tiếng Việt", zh: "越南語名稱" },
  "worker.phone": { vi: "Điện thoại", zh: "電話" },
  "worker.role": { vi: "Vai trò", zh: "角色" },
  "worker.worker": { vi: "Công nhân", zh: "員工" },
  "worker.leader": { vi: "Trưởng nhóm", zh: "組長" },
  "worker.line_leader": { vi: "Trưởng chuyền", zh: "線長" },
  "worker.supervisor": { vi: "Giám sát", zh: "主管" },
  "worker.deputy_manager": { vi: "Phó giám đốc nhà máy", zh: "副廠長" },
  "worker.manager": { vi: "Giám đốc nhà máy", zh: "廠長" },
  "worker.director": { vi: "Tổng giám đốc điều hành", zh: "總監" },
  "worker.general_manager": { vi: "Tổng giám đốc", zh: "總經理" },
  "worker.line": { vi: "Dây chuyền", zh: "產線" },
  "worker.joinDate": { vi: "Ngày vào làm", zh: "入職日期" },
  "worker.newWorker": { vi: "Nhân viên mới", zh: "新增員工" },
  "worker.salaryType": { vi: "Loại lương", zh: "薪資制度" },
  "worker.hourly": { vi: "Theo giờ", zh: "時薪制" },
  "worker.monthly": { vi: "Theo tháng", zh: "月薪制" },
  "worker.monthlySalary": { vi: "Lương tháng", zh: "月薪" },
  "worker.hourlyRate": { vi: "Lương giờ", zh: "時薪" },
  "worker.pieceRate": { vi: "Lương công việc", zh: "計件薪" },
  "worker.salaryNote": { vi: "Lương tháng được tính dựa trên 26 ngày làm việc", zh: "月薪以 26 個工作日計算" },

  // ============================================================
  // Attendance
  // ============================================================
  "att.title": { vi: "Chấm công", zh: "出勤管理" },
  "att.checkIn": { vi: "Vào ca", zh: "上班打卡" },
  "att.checkOut": { vi: "Ra ca", zh: "下班打卡" },
  "att.present": { vi: "Có mặt", zh: "出席" },
  "att.absent": { vi: "Vắng mặt", zh: "缺席" },
  "att.late": { vi: "Đi muộn", zh: "遲到" },
  "att.leave": { vi: "Nghỉ phép", zh: "請假" },
  "att.overtimeHours": { vi: "Giờ tăng ca", zh: "加班時數" },
  "attendance.title": { vi: "Chấm công", zh: "出勤管理" },
  "attendance.date": { vi: "Ngày", zh: "日期" },
  "attendance.present": { vi: "Có mặt", zh: "出席" },
  "attendance.absent": { vi: "Vắng mặt", zh: "缺席" },
  "attendance.late": { vi: "Đi muộn", zh: "遲到" },

  // ============================================================
  // Shipments
  // ============================================================
  "ship.title": { vi: "Quản lý xuất hàng", zh: "出貨管理" },
  "ship.shipmentNo": { vi: "Số lô hàng", zh: "出貨編號" },
  "ship.plannedDate": { vi: "Ngày dự kiến", zh: "計畫日期" },
  "ship.actualDate": { vi: "Ngày thực tế", zh: "實際日期" },
  "ship.destination": { vi: "Điểm đến", zh: "目的地" },
  "ship.totalQty": { vi: "Tổng số lượng", zh: "總數量" },
  "ship.totalBoxes": { vi: "Tổng số thùng", zh: "總箱數" },
  "ship.grossWeight": { vi: "Trọng lượng tổng", zh: "毛重" },
  "ship.netWeight": { vi: "Trọng lượng tịnh", zh: "淨重" },
  "ship.planned": { vi: "Đã lên kế hoạch", zh: "已計畫" },
  "ship.shipped": { vi: "Đã xuất", zh: "已出貨" },
  "ship.delivered": { vi: "Đã giao", zh: "已送達" },
  "ship.packing": { vi: "Đóng gói", zh: "裝箱明細" },
  "ship.boxNo": { vi: "Số thùng", zh: "箱號" },
  "ship.newShipment": { vi: "Lô hàng mới", zh: "新增出貨" },
  "ship.orderNo": { vi: "Số đơn hàng", zh: "訂單編號" },
  "ship.customerName": { vi: "Tên khách hàng", zh: "客戶名" },
  "ship.productName": { vi: "Tên sản phẩm", zh: "品名" },
  "ship.productNo": { vi: "Mã sản phẩm", zh: "產品編號" },
  "shipment.title": { vi: "Quản lý xuất hàng", zh: "出貨管理" },
  "shipment.shipmentNo": { vi: "Số lô hàng", zh: "出貨編號" },
  "shipment.order": { vi: "Đơn hàng", zh: "訂單" },
  "shipment.qty": { vi: "Số lượng", zh: "數量" },
  "shipment.date": { vi: "Ngày xuất", zh: "出貨日期" },

  // ============================================================
  // Customers
  // ============================================================
  "cust.title": { vi: "Quản lý khách hàng", zh: "客戶管理" },
  "cust.name": { vi: "Tên khách hàng", zh: "客戶名稱" },
  "cust.contact": { vi: "Liên hệ", zh: "聯絡人" },
  "cust.phone": { vi: "Điện thoại", zh: "電話" },
  "cust.email": { vi: "Email", zh: "電子郵件" },
  "cust.address": { vi: "Địa chỉ", zh: "地址" },
  "cust.newCustomer": { vi: "Khách hàng mới", zh: "新增客戶" },
  "customer.title": { vi: "Quản lý khách hàng", zh: "客戶管理" },
  "customer.code": { vi: "Mã khách hàng", zh: "客戶代碼" },
  "customer.name": { vi: "Tên khách hàng", zh: "客戶名稱" },
  "customer.contact": { vi: "Liên hệ", zh: "聯絡人" },
  "customer.phone": { vi: "Điện thoại", zh: "電話" },
  "customer.email": { vi: "Email", zh: "電子郵件" },

  // ============================================================
  // Production Lines
  // ============================================================
  "line.title": { vi: "Quản lý dây chuyền", zh: "產線管理" },
  "line.code": { vi: "Mã dây chuyền", zh: "產線代碼" },
  "line.name": { vi: "Tên dây chuyền", zh: "產線名稱" },
  "line.nameVi": { vi: "Tên tiếng Việt", zh: "越南語名稱" },
  "line.type": { vi: "Loại", zh: "類型" },
  "line.capacity": { vi: "Công suất", zh: "產能" },
  "line.leader": { vi: "Trưởng nhóm", zh: "組長" },
  "line.newLine": { vi: "Dây chuyền mới", zh: "新增產線" },

  // ============================================================
  // Reports
  // ============================================================
  "report.title": { vi: "Báo cáo", zh: "報表" },
  "report.attendance": { vi: "Báo cáo chấm công", zh: "出勤報表" },
  "report.production": { vi: "Báo cáo sản xuất", zh: "生產報表" },
  "report.efficiency": { vi: "Báo cáo hiệu suất", zh: "效率報表" },
  "report.defect": { vi: "Báo cáo lỗi", zh: "不良率報表" },
  "report.attendanceReport": { vi: "Báo cáo chấm công", zh: "出勤報表" },
  "report.productionReport": { vi: "Báo cáo sản xuất", zh: "生產效率報表" },
  "report.capacityReport": { vi: "Báo cáo năng suất", zh: "產能報表" },
  "report.defectReport": { vi: "Báo cáo tỷ lệ lỗi", zh: "不良率報表" },
  "report.workerRanking": { vi: "Xếp hạng nhân viên", zh: "員工排名" },

  // ============================================================
  // Sewing Processes
  // ============================================================
  "sewing.title": { vi: "Quản lý công đoạn may", zh: "縫製工序管理" },
  "sewing.processes": { vi: "Công đoạn may", zh: "縫製工序" },
  "sewing.code": { vi: "Mã công đoạn", zh: "工序代碼" },
  "sewing.name": { vi: "Tên công đoạn", zh: "工序名稱" },
  "sewing.sortOrder": { vi: "Thứ tự", zh: "排序" },
  "sewing.newProcess": { vi: "Công đoạn mới", zh: "新增工序" },

  // ============================================================
  // Production Stations
  // ============================================================
  "station.warehouse": { vi: "Kho", zh: "倉庫" },
  "station.cutting": { vi: "Cắt", zh: "裁剪" },
  "station.semi_inspection": { vi: "Kiểm tra bán thành phẩm", zh: "半成品檢驗" },
  "station.sewing": { vi: "May", zh: "縫製" },
  "station.final_inspection": { vi: "Kiểm tra cuối cùng", zh: "最終檢驗" },
  "station.ironing": { vi: "Là", zh: "整燙" },
  "station.packing": { vi: "Đóng gói", zh: "包裝" },

  // ============================================================
  // Salary
  // ============================================================
  "salary.title": { vi: "Quản lý lương", zh: "薪資管理" },
  "salary.monthly": { vi: "Lương tháng", zh: "月薪" },
  "salary.calculate": { vi: "Tính lương", zh: "計算薪資" },
  "salary.export": { vi: "Xuất Excel", zh: "匯出 Excel" },

  // ============================================================
  // Auth
  // ============================================================
  "auth.signInBtn": { vi: "Đăng nhập", zh: "登入" },
  "auth.signInDesc": { vi: "Đăng nhập để tiếp tục", zh: "登入以繼續" },
  "auth.logout": { vi: "Đăng xuất", zh: "登出" },
  // Login page
  "auth.loginDesc": { vi: "Đăng nhập bằng tài khoản hoặc Manus", zh: "使用帳號密碼或 Manus 登入" },
  "auth.username": { vi: "Tên đăng nhập", zh: "帳號" },
  "auth.usernamePlaceholder": { vi: "Nhập tên đăng nhập", zh: "請輸入帳號" },
  "auth.password": { vi: "Mật khẩu", zh: "密碼" },
  "auth.passwordPlaceholder": { vi: "Nhập mật khẩu", zh: "請輸入密碼" },
  "auth.loginSuccess": { vi: "Đăng nhập thành công", zh: "登入成功" },
  "auth.loginFailed": { vi: "Đăng nhập thất bại", zh: "登入失敗" },
  "auth.or": { vi: "Hoặc", zh: "或" },
  "auth.signInWithManus": { vi: "Đăng nhập bằng Manus", zh: "使用 Manus 登入" },
  "auth.noAccount": { vi: "Chưa có tài khoản?", zh: "還沒有帳號？" },
  "auth.registerLink": { vi: "Đăng ký ngay", zh: "立即註冊" },
  "auth.hasAccount": { vi: "Đã có tài khoản?", zh: "已有帳號？" },
  "auth.loginLink": { vi: "Đăng nhập", zh: "前往登入" },
  // Register page
  "auth.registerTitle": { vi: "Đăng ký tài khoản", zh: "註冊帳號" },
  "auth.registerDesc": { vi: "Tạo tài khoản mới, chờ quản trị viên phê duyệt", zh: "建立新帳號，等待管理員審核" },
  "auth.fullName": { vi: "Họ tên", zh: "姓名" },
  "auth.fullNamePlaceholder": { vi: "Nhập họ tên đầy đủ", zh: "請輸入完整姓名" },
  "auth.phone": { vi: "Số điện thoại", zh: "電話" },
  "auth.phonePlaceholder": { vi: "Nhập số điện thoại", zh: "請輸入電話號碼" },
  "auth.usernameHint": { vi: "Chỉ chứa chữ cái, số và dấu gạch dưới, tối thiểu 3 ký tự", zh: "僅允許英文字母、數字和底線，至少 3 個字元" },
  "auth.passwordHint": { vi: "Tối thiểu 6 ký tự", zh: "至少 6 個字元" },
  "auth.confirmPassword": { vi: "Xác nhận mật khẩu", zh: "確認密碼" },
  "auth.confirmPasswordPlaceholder": { vi: "Nhập lại mật khẩu", zh: "請再次輸入密碼" },
  "auth.passwordMismatch": { vi: "Mật khẩu không khớp", zh: "兩次密碼不一致" },
  "auth.registerBtn": { vi: "Đăng ký", zh: "註冊" },
  "auth.registerSuccess": { vi: "Đăng ký thành công", zh: "註冊成功" },
  "auth.registerFailed": { vi: "Đăng ký thất bại", zh: "註冊失敗" },
  "auth.registerSuccessTitle": { vi: "Đăng ký thành công!", zh: "註冊成功！" },
  "auth.registerSuccessDesc": { vi: "Tài khoản của bạn đã được gửi đi, vui lòng chờ quản trị viên phê duyệt. Sau khi được phê duyệt, bạn có thể đăng nhập.", zh: "您的帳號已提交，請等待管理員審核。審核通過後即可登入。" },
  // Pending / Rejected states
  "auth.pendingTitle": { vi: "Đang chờ phê duyệt", zh: "等待審核中" },
  "auth.pendingDesc": { vi: "Tài khoản của bạn đang chờ quản trị viên phê duyệt. Vui lòng liên hệ quản lý để được phê duyệt sớm hơn.", zh: "您的帳號正在等待管理員審核。請聯繫管理人員以加快審核。" },
  "auth.rejectedTitle": { vi: "Tài khoản bị từ chối", zh: "帳號已被拒絕" },
  "auth.rejectedDesc": { vi: "Tài khoản của bạn đã bị từ chối. Vui lòng liên hệ quản trị viên để biết thêm chi tiết.", zh: "您的帳號已被拒絕。請聯繫管理員了解詳情。" },
  "auth.backToLogin": { vi: "Quay lại đăng nhập", zh: "返回登入" },
  // User Approval page
  "auth.userApprovalTitle": { vi: "Quản lý tài khoản", zh: "帳號管理" },
  "auth.userApprovalDesc": { vi: "Phê duyệt hoặc từ chối đăng ký tài khoản nhân viên", zh: "審核或拒絕員工註冊申請" },
  "auth.statusPending": { vi: "Chờ duyệt", zh: "待審核" },
  "auth.statusApproved": { vi: "Đã duyệt", zh: "已通過" },
  "auth.statusRejected": { vi: "Đã từ chối", zh: "已拒絕" },
  "auth.approveBtn": { vi: "Phê duyệt", zh: "批准" },
  "auth.rejectBtn": { vi: "Từ chối", zh: "拒絕" },
  "auth.revokeBtn": { vi: "Thu hồi", zh: "撤銷" },
  "auth.approveSuccess": { vi: "Đã phê duyệt tài khoản", zh: "已批准帳號" },
  "auth.rejectSuccess": { vi: "Đã từ chối tài khoản", zh: "已拒絕帳號" },
  "auth.colName": { vi: "Họ tên", zh: "姓名" },
  "auth.colUsername": { vi: "Tên đăng nhập", zh: "帳號" },
  "auth.colPhone": { vi: "Điện thoại", zh: "電話" },
  "auth.colLoginMethod": { vi: "Phương thức", zh: "登入方式" },
  "auth.colRole": { vi: "Vai trò", zh: "角色" },
  "auth.colStatus": { vi: "Trạng thái", zh: "狀態" },
  "auth.colRegisteredAt": { vi: "Ngày đăng ký", zh: "註冊日期" },
  "auth.methodPassword": { vi: "Mật khẩu", zh: "密碼" },
  "auth.roleAdmin": { vi: "Quản trị viên", zh: "管理員" },
  "auth.roleUser": { vi: "Người dùng", zh: "使用者" },
  "nav.userApproval": { vi: "Quản lý tài khoản", zh: "帳號管理" },

  // ============================================================
  // Import
  // ============================================================
  "import.title": { vi: "Nhập dữ liệu hàng loạt", zh: "批量匯入" },
  "import.subtitle": { vi: "Nhập nhanh dữ liệu ban đầu từ tệp Excel/CSV", zh: "從 Excel/CSV 檔案快速匯入初始資料" },
  "import.step1": { vi: "Chọn loại dữ liệu & Tải mẫu", zh: "選擇資料類型並下載範本" },
  "import.step1Desc": { vi: "Chọn loại dữ liệu cần nhập và tải xuống tệp mẫu để điền thông tin", zh: "選擇要匯入的資料類型，下載範本檔案填寫資料" },
  "import.step2": { vi: "Tải lên tệp", zh: "上傳檔案" },
  "import.step2Desc": { vi: "Tải lên tệp Excel hoặc CSV đã điền đầy đủ thông tin", zh: "上傳已填寫完成的 Excel 或 CSV 檔案" },
  "import.step3": { vi: "Xem trước & Nhập", zh: "預覽並匯入" },
  "import.dataType": { vi: "Loại dữ liệu", zh: "資料類型" },
  "import.downloadTemplate": { vi: "Tải mẫu", zh: "下載範本" },
  "import.templateDownloaded": { vi: "Đã tải xuống tệp mẫu", zh: "範本檔案已下載" },
  "import.fieldName": { vi: "Tên trường", zh: "欄位名稱" },
  "import.required": { vi: "Bắt buộc", zh: "必填" },
  "import.requiredYes": { vi: "Bắt buộc", zh: "必填" },
  "import.requiredNo": { vi: "Tùy chọn", zh: "選填" },
  "import.example": { vi: "Ví dụ", zh: "範例" },
  "import.clear": { vi: "Xóa", zh: "清除" },
  "import.startImport": { vi: "Bắt đầu nhập", zh: "開始匯入" },
  "import.result": { vi: "Kết quả nhập", zh: "匯入結果" },

  // ============================================================
  // System
  // ============================================================
  "app.title": { vi: "Hệ thống MES Nhà máy May", zh: "成衣廠 MES 系統" },
  "app.subtitle": { vi: "Hệ thống quản lý sản xuất", zh: "製造執行管理系統" },

  // ============================================================
  // Alerts & Notifications
  // ============================================================
  "nav.alerts": { vi: "Cảnh báo", zh: "預警通知" },
  "nav.alertSettings": { vi: "Cài đặt cảnh báo", zh: "預警設定" },
  "alert.title": { vi: "Trung tâm cảnh báo", zh: "預警中心" },
  "alert.settings": { vi: "Cài đặt cảnh báo", zh: "預警設定" },
  "alert.noAlerts": { vi: "Không có cảnh báo", zh: "沒有預警" },
  "alert.markAllRead": { vi: "Đánh dấu tất cả đã đọc", zh: "全部標為已讀" },
  "alert.markRead": { vi: "Đánh dấu đã đọc", zh: "標為已讀" },
  "alert.resolve": { vi: "Đã xử lý", zh: "標為已處理" },
  "alert.runChecks": { vi: "Chạy kiểm tra", zh: "執行預警檢查" },
  "alert.running": { vi: "Đang kiểm tra...", zh: "檢查中..." },
  "alert.checkComplete": { vi: "Kiểm tra hoàn tất", zh: "檢查完成" },
  "alert.unread": { vi: "Chưa đọc", zh: "未讀" },
  "alert.read": { vi: "Đã đọc", zh: "已讀" },
  "alert.all": { vi: "Tất cả", zh: "全部" },
  "alert.resolved": { vi: "Đã xử lý", zh: "已處理" },
  "alert.unresolved": { vi: "Chưa xử lý", zh: "未處理" },
  "alert.type.low_stock": { vi: "Tồn kho thấp", zh: "庫存不足" },
  "alert.type.delivery_approaching": { vi: "Giao hàng sắp đến hạn", zh: "交期逼近" },
  "alert.type.delivery_overdue": { vi: "Giao hàng quá hạn", zh: "交期逾期" },
  "alert.type.high_defect_rate": { vi: "Tỷ lệ lỗi cao", zh: "不良率超標" },
  "alert.severity.info": { vi: "Thông tin", zh: "資訊" },
  "alert.severity.warning": { vi: "Cảnh báo", zh: "警告" },
  "alert.severity.critical": { vi: "Nghiêm trọng", zh: "嚴重" },
  "alert.setting.enabled": { vi: "Bật", zh: "啟用" },
  "alert.setting.disabled": { vi: "Tắt", zh: "停用" },
  "alert.setting.threshold": { vi: "Ngưỡng", zh: "閾值" },
  "alert.setting.threshold2": { vi: "Ngưỡng nghiêm trọng", zh: "嚴重閾值" },
  "alert.setting.lowStock.desc": { vi: "Cảnh báo khi tồn kho dưới mức an toàn", zh: "當庫存低於安全水位時觸發預警" },
  "alert.setting.delivery.desc": { vi: "Cảnh báo khi ngày giao hàng sắp đến (ngày)", zh: "當交期逼近時觸發預警（天數）" },
  "alert.setting.deliveryOverdue.desc": { vi: "Cảnh báo khi đơn hàng quá hạn giao", zh: "當訂單交期逾期時觸發預警" },
  "alert.setting.defectRate.desc": { vi: "Cảnh báo khi tỷ lệ lỗi vượt ngưỡng (%)", zh: "當不良率超過閾值時觸發預警（%）" },
  "alert.setting.days": { vi: "ngày", zh: "天" },
  "alert.setting.percent": { vi: "%", zh: "%" },
  "alert.summary": { vi: "Tóm tắt cảnh báo", zh: "預警摘要" },
  "alert.newAlerts": { vi: "cảnh báo mới", zh: "條新預警" },

  // Permissions
  "perm.title": { vi: "Quyền truy cập", zh: "存取權限" },
  "perm.editTitle": { vi: "Cài đặt quyền truy cập", zh: "設定存取權限" },
  "perm.allAccess": { vi: "Toàn quyền", zh: "全部權限" },
  "perm.noAccess": { vi: "Chưa cấp quyền", zh: "未授權" },
  "perm.modules": { vi: "mô-đun", zh: "個模組" },
  "perm.selectAll": { vi: "Chọn tất cả", zh: "全選" },
  "perm.clearAll": { vi: "Bỏ chọn tất cả", zh: "全部取消" },
  "perm.managerNote": { vi: "Chức vụ này có toàn quyền truy cập", zh: "此職位自動擁有全部權限" },
  "perm.managerDesc": { vi: "Tổng giám đốc, Tổng giám đốc điều hành, Giám đốc nhà máy và Phó giám đốc tự động được cấp quyền truy cập vào tất cả các mô-đun.", zh: "總經理、總監、廠長、副廠長等職位自動取得所有模組的存取權限，無需單獨設定。" },
  "perm.autoFullAccess": { vi: "Chức vụ này tự động có toàn quyền truy cập", zh: "此職位自動擁有全部模組權限" },
  "perm.mod.production": { vi: "Quản lý sản xuất", zh: "生產管理" },
  "perm.mod.warehouse": { vi: "Quản lý kho", zh: "倉庫管理" },
  "perm.mod.quality": { vi: "Quản lý chất lượng", zh: "品質管理" },
  "perm.mod.hr": { vi: "Quản lý nhân sự", zh: "人事管理" },
  "perm.mod.finance": { vi: "Tài chính & Lương", zh: "財務薪資" },
  "perm.mod.reports": { vi: "Báo cáo thống kê", zh: "報表統計" },
  "perm.mod.alerts": { vi: "Cảnh báo", zh: "預警通知" },
  "perm.mod.sewing": { vi: "Công đoạn may", zh: "縫製工序" },
  "perm.mod.import": { vi: "Nhập dữ liệu", zh: "資料匯入" },
  "perm.modDesc.production": { vi: "Đơn hàng, lệnh sản xuất, lịch sản xuất, dây chuyền, khách hàng", zh: "訂單、工單、生產排程、產線、客戶" },
  "perm.modDesc.warehouse": { vi: "Vật liệu, nhập/xuất kho, tồn kho", zh: "物料、入庫/出庫、庫存" },
  "perm.modDesc.quality": { vi: "Kiểm tra chất lượng, xuất hàng", zh: "品質檢驗、出貨" },
  "perm.modDesc.hr": { vi: "Nhân viên, chấm công", zh: "員工、出勤" },
  "perm.modDesc.finance": { vi: "Bảng lương, tính lương", zh: "薪資單、薪資計算" },
  "perm.modDesc.reports": { vi: "Báo cáo sản xuất, chấm công, hiệu suất", zh: "生產報表、出勤、效率" },
  "perm.modDesc.alerts": { vi: "Cảnh báo tồn kho, giao hàng, chất lượng", zh: "庫存、交期、品質預警" },
  "perm.modDesc.sewing": { vi: "Quản lý công đoạn may", zh: "縫製工序管理" },
  "perm.modDesc.import": { vi: "Nhập dữ liệu hàng loạt từ Excel/CSV", zh: "Excel/CSV 批量匯入" },
  "perm.noPermission": { vi: "Bạn không có quyền truy cập trang này", zh: "您沒有權限存取此頁面" },

  // Account management - role & password
  "auth.promoteToAdmin": { vi: "Nâng lên quản trị viên", zh: "升級為管理員" },
  "auth.demoteToUser": { vi: "Hạ xuống người dùng", zh: "降級為普通用戶" },
  "auth.editName": { vi: "Sửa tên", zh: "編輯姓名" },
  "auth.resetPassword": { vi: "Đặt lại mật khẩu", zh: "重設密碼" },
  "auth.changeRoleTitle": { vi: "Thay đổi vai trò", zh: "變更角色" },
  "auth.promoteConfirm": { vi: "Xác nhận nâng lên quản trị viên:", zh: "確認升級為管理員：" },
  "auth.demoteConfirm": { vi: "Xác nhận hạ xuống người dùng:", zh: "確認降級為普通用戶：" },
  "auth.roleUpdateSuccess": { vi: "Cập nhật vai trò thành công", zh: "角色更新成功" },
  "auth.editNameTitle": { vi: "Sửa tên người dùng", zh: "編輯用戶姓名" },
  "auth.editNameDesc": { vi: "Thay đổi tên hiển thị của người dùng. Tên này cũng dùng để liên kết với hồ sơ nhân viên.", zh: "修改用戶顯示名稱。此名稱也用於關聯員工記錄。" },
  "auth.enterName": { vi: "Nhập tên", zh: "輸入姓名" },
  "auth.nameUpdateSuccess": { vi: "Cập nhật tên thành công", zh: "姓名更新成功" },
  "auth.resetPasswordTitle": { vi: "Đặt lại mật khẩu", zh: "重設密碼" },
  "auth.resetPasswordDesc": { vi: "Đặt mật khẩu mới cho:", zh: "為以下用戶設定新密碼：" },
  "auth.newPassword": { vi: "Mật khẩu mới", zh: "新密碼" },
  "auth.enterNewPassword": { vi: "Nhập mật khẩu mới", zh: "輸入新密碼" },
  "auth.passwordMinLength": { vi: "Tối thiểu 6 ký tự", zh: "至少 6 個字元" },
  "auth.resetPasswordBtn": { vi: "Đặt lại mật khẩu", zh: "重設密碼" },
  "auth.passwordResetSuccess": { vi: "Đặt lại mật khẩu thành công", zh: "密碼重設成功" },
};

export function t(key: string, locale: Locale): string {
  return translations[key]?.[locale] || key;
}

export type I18nContextType = {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string) => string;
};

export const I18nContext = createContext<I18nContextType>({
  locale: "vi",
  setLocale: () => {},
  t: (key: string) => key,
});

export function useI18n() {
  return useContext(I18nContext);
}
