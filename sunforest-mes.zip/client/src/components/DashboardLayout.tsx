import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { getLoginUrl } from "@/const";
import { useIsMobile } from "@/hooks/useMobile";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import {
  LayoutDashboard, ClipboardList, FileText, Calendar,
  Factory, Package, ShieldCheck, Users, Clock,
  Truck, BarChart3, Building2, GitBranch,
  LogOut, PanelLeft, Languages, ChevronDown,
  Warehouse, Scissors, DollarSign, Upload, Bell, Settings2, UserCheck,
} from "lucide-react";
import { CSSProperties, useEffect, useRef, useState, useMemo, createContext, useContext } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";

type MenuItem = {
  icon: any;
  labelKey: string;
  path: string;
  roles?: string[];
  section?: string;
  // Which permission module this menu item belongs to
  permModule?: string;
};

const menuItems: MenuItem[] = [
  { icon: LayoutDashboard, labelKey: "nav.dashboard", path: "/", section: "main" },
  { icon: ClipboardList, labelKey: "nav.orders", path: "/orders", section: "production", roles: ["admin"], permModule: "production" },
  { icon: FileText, labelKey: "nav.workOrders", path: "/work-orders", section: "production", roles: ["admin"], permModule: "production" },
  { icon: Calendar, labelKey: "nav.schedule", path: "/schedule", section: "production", roles: ["admin"], permModule: "production" },
  { icon: Factory, labelKey: "nav.production", path: "/production", section: "production", permModule: "production" },
  { icon: Package, labelKey: "nav.materials", path: "/materials", section: "production", roles: ["admin"], permModule: "warehouse" },
  { icon: Warehouse, labelKey: "warehouse.title", path: "/warehouse", section: "production", roles: ["admin"], permModule: "warehouse" },
  { icon: Scissors, labelKey: "sewing.title", path: "/sewing-processes", section: "production", roles: ["admin"], permModule: "sewing" },
  { icon: ShieldCheck, labelKey: "nav.qc", path: "/qc", section: "quality", roles: ["admin"], permModule: "quality" },
  { icon: Truck, labelKey: "nav.shipments", path: "/shipments", section: "quality", roles: ["admin"], permModule: "quality" },
  { icon: Users, labelKey: "nav.workers", path: "/workers", section: "hr", roles: ["admin"], permModule: "hr" },
  { icon: Clock, labelKey: "nav.attendance", path: "/attendance", section: "hr", roles: ["admin"], permModule: "hr" },
  { icon: GitBranch, labelKey: "nav.lines", path: "/lines", section: "production", roles: ["admin"], permModule: "production" },
  { icon: Building2, labelKey: "nav.customers", path: "/customers", section: "production", roles: ["admin"], permModule: "production" },
  { icon: BarChart3, labelKey: "nav.reports", path: "/reports", section: "reports", roles: ["admin"], permModule: "reports" },
  { icon: DollarSign, labelKey: "salary.title", path: "/salary", section: "hr", roles: ["admin"], permModule: "finance" },
  { icon: Upload, labelKey: "import.title", path: "/import", section: "hr", roles: ["admin"], permModule: "import" },
  { icon: Bell, labelKey: "nav.alerts", path: "/alerts", section: "reports", roles: ["admin"], permModule: "alerts" },
  { icon: Settings2, labelKey: "nav.alertSettings", path: "/alert-settings", section: "reports", roles: ["admin"], permModule: "alerts" },
  { icon: UserCheck, labelKey: "nav.userApproval", path: "/user-approval", section: "hr", roles: ["admin"], permModule: "hr" },
];

const sectionLabels: Record<string, Record<string, string>> = {
  main: { vi: "", zh: "" },
  production: { vi: "Sản xuất & Kho", zh: "生產與倉庫" },
  quality: { vi: "Chất lượng & Xuất hàng", zh: "品質與出貨" },
  hr: { vi: "Nhân sự & Thiết lập", zh: "人事與設定" },
  reports: { vi: "Báo cáo", zh: "報表" },
};

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 260;
const MIN_WIDTH = 200;
const MAX_WIDTH = 400;

// Permission context to share worker permissions across components
type PermContextType = {
  workerPermissions: string[];
  workerRole: string;
  hasPermission: (module: string) => boolean;
};

const PermContext = createContext<PermContextType>({
  workerPermissions: [],
  workerRole: "",
  hasPermission: () => false,
});

export function useWorkerPermissions() {
  return useContext(PermContext);
}

// Parse permissions JSON string
function parsePermissions(permissions: string | null | undefined): string[] {
  if (!permissions) return [];
  try {
    const parsed = JSON.parse(permissions);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();
  const { t } = useI18n();

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  if (loading) return <DashboardLayoutSkeleton />;

  if (!user) {
    // Redirect to login page
    window.location.href = "/login";
    return <DashboardLayoutSkeleton />;
  }

  return (
    <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}>
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent>
    </SidebarProvider>
  );
}

function DashboardLayoutContent({ children, setSidebarWidth }: { children: React.ReactNode; setSidebarWidth: (w: number) => void }) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const { t, locale, setLocale } = useI18n();
  const { data: unreadCount } = trpc.alert.unreadCount.useQuery();
  const { data: pendingCount } = trpc.account.pendingCount.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  // Fetch worker data linked to current user (by matching name or a specific field)
  // For admin users, we query all workers to find one that might be linked
  const { data: allWorkers = [] } = trpc.worker.list.useQuery({});

  // Find the current user's worker record (match by name for now)
  // Admin users (system role) get full access; worker permissions are for factory staff
  const currentWorker = useMemo(() => {
    if (!user) return null;
    // Try to find a worker record linked to this user
    return allWorkers.find((w: any) => w.name === user.name) || null;
  }, [allWorkers, user]);

  // Check if current user is the project owner
  const isOwner = user?.openId === import.meta.env.VITE_OWNER_OPEN_ID;

  // Determine permissions
  const permContext = useMemo<PermContextType>(() => {
    // System admin or project owner always has full access
    if (user?.role === "admin" || isOwner) {
      return {
        workerPermissions: [],
        workerRole: "admin",
        hasPermission: () => true,
      };
    }

    // If no worker record found, show minimal access
    if (!currentWorker) {
      return {
        workerPermissions: [],
        workerRole: "",
        hasPermission: () => false,
      };
    }

    // Senior roles (general_manager, director, manager, deputy_manager) get all permissions
    const fullAccessRoles = ["general_manager", "director", "manager", "deputy_manager"];
    if (fullAccessRoles.includes(currentWorker.workerRole)) {
      return {
        workerPermissions: [],
        workerRole: currentWorker.workerRole,
        hasPermission: () => true,
      };
    }

    // Parse worker's specific permissions
    const perms = parsePermissions(currentWorker.permissions);
    return {
      workerPermissions: perms,
      workerRole: currentWorker.workerRole,
      hasPermission: (module: string) => perms.includes(module),
    };
  }, [user, currentWorker, isOwner]);

  const activeMenuItem = menuItems.find(item => {
    if (item.path === "/") return location === "/";
    return location.startsWith(item.path);
  });

  useEffect(() => {
    if (isCollapsed) setIsResizing(false);
  }, [isCollapsed]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;
      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) setSidebarWidth(newWidth);
    };
    const handleMouseUp = () => setIsResizing(false);
    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }
    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  // Filter menu items by user role AND worker module permissions
  const visibleItems = useMemo(() => {
    return menuItems.filter(item => {
      // Dashboard is always visible
      if (!item.permModule) return true;

      // System admin or manager: show all
      if (permContext.hasPermission(item.permModule)) return true;

      // For non-admin users, also check the roles array
      if (item.roles && !item.roles.includes(user?.role || "user")) return false;

      return false;
    });
  }, [user, permContext]);

  // Group by section
  const sections = useMemo(() => {
    const map = new Map<string, MenuItem[]>();
    visibleItems.forEach(item => {
      const sec = item.section || "main";
      if (!map.has(sec)) map.set(sec, []);
      map.get(sec)!.push(item);
    });
    return map;
  }, [visibleItems]);

  return (
    <PermContext.Provider value={permContext}>
      <div className="relative" ref={sidebarRef}>
        <Sidebar collapsible="icon" className="border-r-0" disableTransition={isResizing}>
          <SidebarHeader className="h-14 justify-center border-b border-sidebar-border">
            <div className="flex items-center gap-2 px-2 w-full">
              <button
                onClick={toggleSidebar}
                className="h-8 w-8 flex items-center justify-center hover:bg-accent rounded-lg transition-colors shrink-0"
              >
                <PanelLeft className="h-4 w-4 text-muted-foreground" />
              </button>
              {!isCollapsed && (
                <span className="font-bold text-sm tracking-tight truncate text-primary">
                  {t("app.title")}
                </span>
              )}
            </div>
          </SidebarHeader>

          <SidebarContent className="gap-0 px-2 py-2">
            {Array.from(sections.entries()).map(([section, items]) => (
              <div key={section}>
                {section !== "main" && !isCollapsed && (
                  <div className="px-3 py-2 mt-2">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                      {sectionLabels[section]?.[locale] || section}
                    </span>
                  </div>
                )}
                <SidebarMenu>
                  {items.map(item => {
                    const isActive = item.path === "/" ? location === "/" : location.startsWith(item.path);
                    return (
                      <SidebarMenuItem key={item.path}>
                        <SidebarMenuButton
                          isActive={isActive}
                          onClick={() => setLocation(item.path)}
                          tooltip={t(item.labelKey)}
                          className="h-9 transition-all font-normal text-[13px]"
                        >
                          <item.icon className={`h-4 w-4 ${isActive ? "text-primary" : ""}`} />
                          <span className="flex-1">{t(item.labelKey)}</span>
                          {item.path === "/user-approval" && pendingCount !== undefined && pendingCount > 0 && (
                            <span className="ml-auto h-5 min-w-5 px-1 bg-amber-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                              {pendingCount > 9 ? "9+" : pendingCount}
                            </span>
                          )}
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </div>
            ))}
          </SidebarContent>

          <SidebarFooter className="p-2 border-t border-sidebar-border">
            {/* Language toggle */}
            <button
              onClick={() => setLocale(locale === "vi" ? "zh" : "vi")}
              className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-accent/50 transition-colors w-full text-left text-xs text-muted-foreground group-data-[collapsible=icon]:justify-center"
            >
              <Languages className="h-4 w-4 shrink-0" />
              <span className="group-data-[collapsible=icon]:hidden">
                {locale === "vi" ? "Tiếng Việt → 中文" : "中文 → Tiếng Việt"}
              </span>
            </button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-lg px-1 py-1.5 hover:bg-accent/50 transition-colors w-full text-left group-data-[collapsible=icon]:justify-center">
                  <Avatar className="h-8 w-8 border shrink-0">
                    <AvatarFallback className="text-xs font-medium bg-primary/10 text-primary">
                      {user?.name?.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
                    <p className="text-sm font-medium truncate leading-none">{user?.name || "-"}</p>
                    <p className="text-[11px] text-muted-foreground truncate mt-1">
                      {user?.role === "admin" ? (locale === "vi" ? "Quản trị viên" : "管理員") : (locale === "vi" ? "Người dùng" : "使用者")}
                    </p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive focus:text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>{t("common.signOut")}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>
        <div
          className={`absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/20 transition-colors ${isCollapsed ? "hidden" : ""}`}
          onMouseDown={() => { if (!isCollapsed) setIsResizing(true); }}
          style={{ zIndex: 50 }}
        />
      </div>

      <SidebarInset>
        {isMobile && (
          <div className="flex border-b h-12 items-center justify-between bg-background/95 px-3 backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <SidebarTrigger className="h-9 w-9 rounded-lg" />
              <span className="text-sm font-medium text-foreground">
                {activeMenuItem ? t(activeMenuItem.labelKey) : t("app.title")}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setLocation("/alerts")}
                className="relative h-8 w-8 rounded-md text-muted-foreground hover:bg-accent transition-colors flex items-center justify-center"
                title={t("nav.alerts")}
              >
                <Bell className="h-4 w-4" />
                {unreadCount !== undefined && unreadCount > 0 && (
                  <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => setLocale(locale === "vi" ? "zh" : "vi")}
                className="h-8 px-2 rounded-md text-xs text-muted-foreground hover:bg-accent transition-colors"
              >
                {locale === "vi" ? "中文" : "VN"}
              </button>
            </div>
          </div>
        )}
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </SidebarInset>
    </PermContext.Provider>
  );
}
