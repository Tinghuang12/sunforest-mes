import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { I18nProvider } from "./contexts/I18nProvider";
import DashboardLayout from "./components/DashboardLayout";

// Pages
import Dashboard from "./pages/Dashboard";
import OrdersPage from "./pages/Orders";
import WorkOrdersPage from "./pages/WorkOrders";
import SchedulePage from "./pages/Schedule";
import ProductionPage from "./pages/Production";
import MaterialsPage from "./pages/Materials";
import QCPage from "./pages/QC";
import WorkersPage from "./pages/Workers";
import AttendancePage from "./pages/Attendance";
import ShipmentsPage from "./pages/Shipments";
import ReportsPage from "./pages/Reports";
import CustomersPage from "./pages/Customers";
import LinesPage from "./pages/Lines";
import WarehousePage from "./pages/Warehouse";
import SewingProcessesPage from "./pages/SewingProcesses";
import SalaryPage from "./pages/Salary";
import ImportPage from "./pages/Import";
import AlertsPage from "./pages/Alerts";
import AlertSettingsPage from "./pages/AlertSettings";
import LoginPage from "./pages/Login";
import RegisterPage from "./pages/Register";
import UserApprovalPage from "./pages/UserApproval";

function Router() {
  return (
    <Switch>
      {/* Public routes - no DashboardLayout */}
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />

      {/* Protected routes - wrapped in DashboardLayout */}
      <Route>
        <DashboardLayout>
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/orders" component={OrdersPage} />
            <Route path="/work-orders" component={WorkOrdersPage} />
            <Route path="/schedule" component={SchedulePage} />
            <Route path="/production" component={ProductionPage} />
            <Route path="/materials" component={MaterialsPage} />
            <Route path="/qc" component={QCPage} />
            <Route path="/workers" component={WorkersPage} />
            <Route path="/attendance" component={AttendancePage} />
            <Route path="/shipments" component={ShipmentsPage} />
            <Route path="/reports" component={ReportsPage} />
            <Route path="/customers" component={CustomersPage} />
            <Route path="/lines" component={LinesPage} />
            <Route path="/warehouse" component={WarehousePage} />
            <Route path="/sewing-processes" component={SewingProcessesPage} />
            <Route path="/salary" component={SalaryPage} />
            <Route path="/import" component={ImportPage} />
            <Route path="/alerts" component={AlertsPage} />
            <Route path="/alert-settings" component={AlertSettingsPage} />
            <Route path="/user-approval" component={UserApprovalPage} />
            <Route component={NotFound} />
          </Switch>
        </DashboardLayout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <I18nProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </I18nProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
