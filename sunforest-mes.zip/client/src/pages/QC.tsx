import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const defectTypes = ["hole", "skip_stitch", "color_diff", "size_deviation", "stain", "broken_thread", "misalignment", "other"] as const;

export default function QCPage() {
  const { t } = useI18n();
  const [showCreate, setShowCreate] = useState(false);
  const utils = trpc.useUtils();

  const { data: inspections = [], isLoading } = trpc.qc.list.useQuery();
  const { data: workOrders = [] } = trpc.workOrder.list.useQuery();
  const { data: workers = [] } = trpc.worker.list.useQuery({ status: "active" });

  const woMap = new Map(workOrders.map((wo: any) => [wo.id, wo.workOrderNo]));
  const workerMap = new Map(workers.map((w: any) => [w.id, w.name]));

  const createMutation = trpc.qc.create.useMutation({
    onSuccess: () => { utils.qc.list.invalidate(); setShowCreate(false); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const [form, setForm] = useState({
    workOrderId: 0,
    inspectorId: 0,
    productName: "",
    productNo: "",
    inspectedQty: 0,
    passQty: 0,
    failQty: 0,
    inspectionDate: new Date().toISOString().split("T")[0],
    notes: "",
    defects: [] as { defectType: typeof defectTypes[number]; qty: number; notes: string }[],
  });

  const addDefect = () => setForm(f => ({ ...f, defects: [...f.defects, { defectType: "other", qty: 1, notes: "" }] }));
  const removeDefect = (i: number) => setForm(f => ({ ...f, defects: f.defects.filter((_, idx) => idx !== i) }));

  const handleCreate = () => {
    if (!form.workOrderId || !form.inspectorId || form.inspectedQty <= 0) {
      toast.error(t("common.error"));
      return;
    }
    createMutation.mutate({
      ...form,
      productName: form.productName || undefined,
      productNo: form.productNo || undefined,
      defects: form.defects.filter(d => d.qty > 0),
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{t("qc.title")}</h1>
        <Button onClick={() => {
          setForm({ workOrderId: 0, inspectorId: 0, productName: "", productNo: "", inspectedQty: 0, passQty: 0, failQty: 0, inspectionDate: new Date().toISOString().split("T")[0], notes: "", defects: [] });
          setShowCreate(true);
        }} className="touch-target">
          <Plus className="h-4 w-4 mr-1" /> {t("qc.newInspection")}
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium">{t("common.date")}</th>
                  <th className="text-left p-3 font-medium">{t("wo.workOrderNo")}</th>
                  <th className="text-left p-3 font-medium">{t("qc.productName")}</th>
                  <th className="text-left p-3 font-medium">{t("qc.productNo")}</th>
                  <th className="text-left p-3 font-medium">{t("qc.inspector")}</th>
                  <th className="text-right p-3 font-medium">{t("qc.inspectedQty")}</th>
                  <th className="text-right p-3 font-medium">{t("qc.passQty")}</th>
                  <th className="text-right p-3 font-medium">{t("qc.failQty")}</th>
                  <th className="text-right p-3 font-medium">{t("qc.defectRate")}</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan={9} className="p-8 text-center text-muted-foreground">{t("common.loading")}</td></tr>
                ) : inspections.length === 0 ? (
                  <tr><td colSpan={9} className="p-8 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                ) : inspections.map((insp: any) => {
                  const rate = insp.inspectedQty > 0 ? ((insp.failQty / insp.inspectedQty) * 100).toFixed(1) : "0.0";
                  return (
                    <tr key={insp.id} className="border-b hover:bg-muted/30">
                      <td className="p-3 text-xs">{insp.inspectionDate ? new Date(insp.inspectionDate).toLocaleDateString() : "-"}</td>
                      <td className="p-3 font-mono text-xs">{woMap.get(insp.workOrderId) || insp.workOrderId}</td>
                      <td className="p-3">{insp.productName || "-"}</td>
                      <td className="p-3 font-mono text-xs">{insp.productNo || "-"}</td>
                      <td className="p-3">{workerMap.get(insp.inspectorId) || insp.inspectorId}</td>
                      <td className="p-3 text-right">{insp.inspectedQty}</td>
                      <td className="p-3 text-right text-green-600">{insp.passQty}</td>
                      <td className="p-3 text-right text-destructive">{insp.failQty}</td>
                      <td className="p-3 text-right">
                        <Badge variant={parseFloat(rate) > 5 ? "destructive" : "secondary"} className={parseFloat(rate) > 5 ? "" : "bg-green-100 text-green-700"}>
                          {rate}%
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{t("qc.newInspection")}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>{t("wo.workOrderNo")} *</Label>
              <Select value={String(form.workOrderId || "")} onValueChange={v => setForm(f => ({ ...f, workOrderId: Number(v) }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{workOrders.map((wo: any) => <SelectItem key={wo.id} value={String(wo.id)}>{wo.workOrderNo}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t("qc.inspector")} *</Label>
              <Select value={String(form.inspectorId || "")} onValueChange={v => setForm(f => ({ ...f, inspectorId: Number(v) }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{workers.map((w: any) => <SelectItem key={w.id} value={String(w.id)}>{w.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t("qc.productName")}</Label>
              <Input value={form.productName} onChange={e => setForm(f => ({ ...f, productName: e.target.value }))} placeholder={t("qc.productName")} />
            </div>
            <div>
              <Label>{t("qc.productNo")}</Label>
              <Input value={form.productNo} onChange={e => setForm(f => ({ ...f, productNo: e.target.value }))} placeholder={t("qc.productNo")} />
            </div>
            <div><Label>{t("qc.inspectedQty")} *</Label><Input type="number" value={form.inspectedQty || ""} onChange={e => { const v = Number(e.target.value); setForm(f => ({ ...f, inspectedQty: v, passQty: v - f.failQty })); }} /></div>
            <div><Label>{t("qc.failQty")}</Label><Input type="number" value={form.failQty || ""} onChange={e => { const v = Number(e.target.value); setForm(f => ({ ...f, failQty: v, passQty: f.inspectedQty - v })); }} /></div>
            <div><Label>{t("qc.passQty")}</Label><Input type="number" value={form.passQty} disabled /></div>
            <div><Label>{t("common.date")}</Label><Input type="date" value={form.inspectionDate} onChange={e => setForm(f => ({ ...f, inspectionDate: e.target.value }))} /></div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>{t("qc.defectType")}</Label>
              <Button variant="outline" size="sm" onClick={addDefect}><Plus className="h-3 w-3 mr-1" />{t("common.add")}</Button>
            </div>
            {form.defects.map((d, i) => (
              <div key={i} className="flex gap-2 items-center">
                <Select value={d.defectType} onValueChange={v => setForm(f => ({ ...f, defects: f.defects.map((dd, idx) => idx === i ? { ...dd, defectType: v as any } : dd) }))}>
                  <SelectTrigger className="flex-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{defectTypes.map(dt => <SelectItem key={dt} value={dt}>{t(`qc.${dt}`)}</SelectItem>)}</SelectContent>
                </Select>
                <Input type="number" value={d.qty} onChange={e => setForm(f => ({ ...f, defects: f.defects.map((dd, idx) => idx === i ? { ...dd, qty: Number(e.target.value) } : dd) }))} className="w-20" />
                <Button variant="ghost" size="icon" onClick={() => removeDefect(i)}><Trash2 className="h-4 w-4" /></Button>
              </div>
            ))}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>{t("common.cancel")}</Button>
            <Button onClick={handleCreate} disabled={createMutation.isPending}>{t("common.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
