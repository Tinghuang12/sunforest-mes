import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useI18n } from "@/lib/i18n";
import { Factory, Loader2, Eye, EyeOff, AlertCircle, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

export default function RegisterPage() {
  const { t } = useI18n();
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [registered, setRegistered] = useState(false);

  const registerMutation = trpc.account.register.useMutation({
    onSuccess: () => {
      setRegistered(true);
      toast.success(t("auth.registerSuccess"));
    },
    onError: (error) => {
      toast.error(error.message || t("auth.registerFailed"));
    },
  });

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast.error(t("auth.passwordMismatch"));
      return;
    }
    registerMutation.mutate({
      username: username.trim(),
      password,
      name: name.trim(),
      phone: phone.trim() || undefined,
    });
  };

  // Success state
  if (registered) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Card className="w-full max-w-md mx-4">
          <CardHeader className="text-center">
            <div className="mx-auto h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
              <CheckCircle2 className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle className="text-xl">{t("auth.registerSuccessTitle")}</CardTitle>
            <CardDescription className="mt-2">{t("auth.registerSuccessDesc")}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => setLocation("/login")} className="w-full">
              {t("auth.backToLogin")}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isValid = username.trim().length >= 3 && password.length >= 6 && password === confirmPassword && name.trim().length > 0;

  return (
    <div className="flex items-center justify-center min-h-screen bg-background py-8">
      <Card className="w-full max-w-md mx-4">
        <CardHeader className="text-center">
          <div className="mx-auto h-16 w-16 rounded-xl bg-primary/10 flex items-center justify-center mb-2">
            <Factory className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-2xl">{t("auth.registerTitle")}</CardTitle>
          <CardDescription>{t("auth.registerDesc")}</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleRegister} className="flex flex-col gap-4">
            <div className="space-y-2">
              <Label htmlFor="reg-name">{t("auth.fullName")} <span className="text-destructive">*</span></Label>
              <Input
                id="reg-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t("auth.fullNamePlaceholder")}
                disabled={registerMutation.isPending}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="reg-username">{t("auth.username")} <span className="text-destructive">*</span></Label>
              <Input
                id="reg-username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t("auth.usernamePlaceholder")}
                autoComplete="username"
                disabled={registerMutation.isPending}
              />
              <p className="text-xs text-muted-foreground">{t("auth.usernameHint")}</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reg-phone">{t("auth.phone")}</Label>
              <Input
                id="reg-phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder={t("auth.phonePlaceholder")}
                disabled={registerMutation.isPending}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="reg-password">{t("auth.password")} <span className="text-destructive">*</span></Label>
              <div className="relative">
                <Input
                  id="reg-password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t("auth.passwordPlaceholder")}
                  autoComplete="new-password"
                  disabled={registerMutation.isPending}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <p className="text-xs text-muted-foreground">{t("auth.passwordHint")}</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reg-confirm">{t("auth.confirmPassword")} <span className="text-destructive">*</span></Label>
              <Input
                id="reg-confirm"
                type={showPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder={t("auth.confirmPasswordPlaceholder")}
                autoComplete="new-password"
                disabled={registerMutation.isPending}
              />
              {confirmPassword && password !== confirmPassword && (
                <p className="text-xs text-destructive">{t("auth.passwordMismatch")}</p>
              )}
            </div>

            {registerMutation.isError && (
              <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 p-3 rounded-md">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{registerMutation.error?.message || t("auth.registerFailed")}</span>
              </div>
            )}

            <Button type="submit" className="w-full" disabled={registerMutation.isPending || !isValid}>
              {registerMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              {t("auth.registerBtn")}
            </Button>
          </form>

          <div className="text-center text-sm text-muted-foreground mt-4">
            {t("auth.hasAccount")}{" "}
            <button
              onClick={() => setLocation("/login")}
              className="text-primary hover:underline font-medium"
            >
              {t("auth.loginLink")}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
