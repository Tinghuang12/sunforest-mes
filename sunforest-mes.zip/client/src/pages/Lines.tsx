import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Pencil } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function LinesPage() {
  const { t, locale } = useI18n();
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data: lines = [], isLoading } = trpc.line.list.useQuery();

  const createMutation = trpc.line.create.useMutation({
    onSuccess: () => { utils.line.list.invalidate(); setShowForm(false); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const updateMutation = trpc.line.update.useMutation({
    onSuccess: () => { utils.line.list.invalidate(); setShowForm(false); setEditId(null); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const [form, setForm] = useState({ name: "", nameVi: "", type: "sewing" as "cutting" | "sewing" | "ironing" | "qc" | "packing" | "shipping", capacity: 0, leaderId: undefined as number | undefined });

  const { data: workers = [] } = trpc.worker.list.useQuery({ role: "leader" });

  const openEdit = (l: any) => {
    setEditId(l.id);
    setForm({ name: l.name, nameVi: l.nameVi || "", type: l.type || "sewing", capacity: l.capacity || 0, leaderId: l.leaderId || undefined });
    setShowForm(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("line.title")}</h1>
        <Button onClick={() => { setEditId(null); setForm({ name: "", nameVi: "", type: "sewing", capacity: 0, leaderId: undefined }); setShowForm(true); }} className="touch-target">
          <Plus className="h-4 w-4 mr-1" /> {t("line.newLine")}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          <div className="col-span-full p-8 text-center text-muted-foreground">{t("common.loading")}</div>
        ) : lines.length === 0 ? (
          <div className="col-span-full p-8 text-center text-muted-foreground">{t("common.noData")}</div>
        ) : lines.map((l: any) => {
          const leader = workers.find((w: any) => w.id === l.leaderId);
          return (
            <Card key={l.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold text-lg">{locale === 'vi' ? (l.nameVi || l.name) : l.name}</h3>
                    {locale === 'vi' ? (l.name && <p className="text-sm text-muted-foreground">{l.name}</p>) : (l.nameVi && <p className="text-sm text-muted-foreground">{l.nameVi}</p>)}
                  </div>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(l)}>
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <div className="mt-3 space-y-1.5 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("line.type")}:</span>
                    <Badge variant="secondary">{t(`prod.${l.type}`) || l.type}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("line.capacity")}:</span>
                    <span className="font-medium">{l.capacity || 0} pcs/day</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("line.leader")}:</span>
                    <span>{leader?.name || "-"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t("common.status")}:</span>
                    <Badge variant={l.status === "active" ? "default" : "secondary"}>{t(`common.${l.status}`)}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editId ? t("common.edit") : t("line.newLine")}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>{t("line.name")} *</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
            <div><Label>{t("line.nameVi")}</Label><Input value={form.nameVi} onChange={e => setForm(f => ({ ...f, nameVi: e.target.value }))} /></div>
            <div><Label>{t("line.capacity")}</Label><Input type="number" value={form.capacity || ""} onChange={e => setForm(f => ({ ...f, capacity: Number(e.target.value) }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowForm(false)}>{t("common.cancel")}</Button>
            <Button onClick={() => {
              if (!form.name) return;
              if (editId) updateMutation.mutate({ id: editId, ...form });
              else createMutation.mutate(form);
            }} disabled={createMutation.isPending || updateMutation.isPending}>{t("common.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
