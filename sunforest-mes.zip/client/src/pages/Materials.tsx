import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, AlertTriangle, ArrowDownToLine, ArrowUpFromLine, RotateCcw } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function MaterialsPage() {
  const { t } = useI18n();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [showCreate, setShowCreate] = useState(false);
  const [showTransaction, setShowTransaction] = useState<{ materialId: number; type: "in" | "out" | "return" } | null>(null);
  const [txQty, setTxQty] = useState("");
  const [txNotes, setTxNotes] = useState("");
  const utils = trpc.useUtils();

  const { data: materials = [], isLoading } = trpc.material.list.useQuery({
    search: search || undefined,
    type: typeFilter !== "all" ? typeFilter : undefined,
  });
  const { data: lowStock = [] } = trpc.material.lowStock.useQuery();

  const createMutation = trpc.material.create.useMutation({
    onSuccess: () => { utils.material.list.invalidate(); setShowCreate(false); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const txMutation = trpc.material.createTransaction.useMutation({
    onSuccess: () => {
      utils.material.list.invalidate();
      utils.material.lowStock.invalidate();
      setShowTransaction(null);
      setTxQty("");
      setTxNotes("");
      toast.success(t("common.success"));
    },
    onError: () => toast.error(t("common.error")),
  });

  const [form, setForm] = useState({ code: "", name: "", nameVi: "", type: "fabric" as const, unit: "m", color: "", batchNo: "", currentStock: "0", safetyStock: "0" });

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{t("mat.title")}</h1>
        <Button onClick={() => { setForm({ code: "", name: "", nameVi: "", type: "fabric", unit: "m", color: "", batchNo: "", currentStock: "0", safetyStock: "0" }); setShowCreate(true); }} className="touch-target">
          <Plus className="h-4 w-4 mr-1" /> {t("mat.newMaterial")}
        </Button>
      </div>

      {lowStock.length > 0 && (
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="p-3 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
            <span className="text-sm text-amber-800">
              {t("mat.lowStock")}: {lowStock.map((m: any) => m.name).join(", ")}
            </span>
          </CardContent>
        </Card>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder={t("common.search")} value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("common.all")}</SelectItem>
            <SelectItem value="fabric">{t("mat.fabric")}</SelectItem>
            <SelectItem value="accessory">{t("mat.accessory")}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium">{t("mat.code")}</th>
                  <th className="text-left p-3 font-medium">{t("mat.name")}</th>
                  <th className="text-left p-3 font-medium">{t("mat.type")}</th>
                  <th className="text-left p-3 font-medium">{t("mat.color")}</th>
                  <th className="text-left p-3 font-medium">{t("mat.batchNo")}</th>
                  <th className="text-right p-3 font-medium">{t("mat.currentStock")}</th>
                  <th className="text-right p-3 font-medium">{t("mat.safetyStock")}</th>
                  <th className="text-left p-3 font-medium">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">{t("common.loading")}</td></tr>
                ) : materials.length === 0 ? (
                  <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                ) : materials.map((m: any) => {
                  const isLow = parseFloat(m.safetyStock || "0") > 0 && parseFloat(m.currentStock || "0") <= parseFloat(m.safetyStock || "0");
                  return (
                    <tr key={m.id} className={`border-b hover:bg-muted/30 ${isLow ? "bg-amber-50" : ""}`}>
                      <td className="p-3 font-mono text-xs">{m.code}</td>
                      <td className="p-3">{m.name}</td>
                      <td className="p-3"><Badge variant="secondary">{t(`mat.${m.type}`)}</Badge></td>
                      <td className="p-3">{m.color || "-"}</td>
                      <td className="p-3 text-xs">{m.batchNo || "-"}</td>
                      <td className={`p-3 text-right font-medium ${isLow ? "text-amber-600" : ""}`}>
                        {parseFloat(m.currentStock || "0").toLocaleString()} {m.unit}
                      </td>
                      <td className="p-3 text-right text-muted-foreground">{parseFloat(m.safetyStock || "0").toLocaleString()} {m.unit}</td>
                      <td className="p-3">
                        <div className="flex gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" title={t("mat.stockIn")} onClick={() => setShowTransaction({ materialId: m.id, type: "in" })}>
                            <ArrowDownToLine className="h-3.5 w-3.5 text-green-600" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7" title={t("mat.stockOut")} onClick={() => setShowTransaction({ materialId: m.id, type: "out" })}>
                            <ArrowUpFromLine className="h-3.5 w-3.5 text-blue-600" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-7 w-7" title={t("mat.stockReturn")} onClick={() => setShowTransaction({ materialId: m.id, type: "return" })}>
                            <RotateCcw className="h-3.5 w-3.5 text-amber-600" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Create Material Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{t("mat.newMaterial")}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>{t("mat.code")} *</Label><Input value={form.code} onChange={e => setForm(f => ({ ...f, code: e.target.value }))} /></div>
            <div><Label>{t("mat.name")} *</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
            <div>
              <Label>{t("mat.type")}</Label>
              <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v as any }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="fabric">{t("mat.fabric")}</SelectItem>
                  <SelectItem value="accessory">{t("mat.accessory")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>{t("mat.unit")}</Label><Input value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))} /></div>
            <div><Label>{t("mat.color")}</Label><Input value={form.color} onChange={e => setForm(f => ({ ...f, color: e.target.value }))} /></div>
            <div><Label>{t("mat.batchNo")}</Label><Input value={form.batchNo} onChange={e => setForm(f => ({ ...f, batchNo: e.target.value }))} /></div>
            <div><Label>{t("mat.currentStock")}</Label><Input value={form.currentStock} onChange={e => setForm(f => ({ ...f, currentStock: e.target.value }))} /></div>
            <div><Label>{t("mat.safetyStock")}</Label><Input value={form.safetyStock} onChange={e => setForm(f => ({ ...f, safetyStock: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>{t("common.cancel")}</Button>
            <Button onClick={() => { if (!form.code || !form.name) return; createMutation.mutate(form); }} disabled={createMutation.isPending}>{t("common.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Transaction Dialog */}
      <Dialog open={!!showTransaction} onOpenChange={() => setShowTransaction(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {showTransaction?.type === "in" ? t("mat.stockIn") : showTransaction?.type === "out" ? t("mat.stockOut") : t("mat.stockReturn")}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div><Label>{t("common.qty")} *</Label><Input type="number" value={txQty} onChange={e => setTxQty(e.target.value)} className="h-12 text-lg" /></div>
            <div><Label>{t("common.notes")}</Label><Input value={txNotes} onChange={e => setTxNotes(e.target.value)} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTransaction(null)}>{t("common.cancel")}</Button>
            <Button onClick={() => {
              if (!showTransaction || !txQty) return;
              txMutation.mutate({ materialId: showTransaction.materialId, type: showTransaction.type, qty: txQty, notes: txNotes || undefined });
            }} disabled={txMutation.isPending}>{t("common.confirm")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
