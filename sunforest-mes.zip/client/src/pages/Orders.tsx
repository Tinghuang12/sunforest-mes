import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Search, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const statusColors: Record<string, string> = {
  pending: "bg-gray-100 text-gray-700",
  scheduled: "bg-blue-100 text-blue-700",
  in_production: "bg-amber-100 text-amber-700",
  completed: "bg-green-100 text-green-700",
  shipped: "bg-purple-100 text-purple-700",
};

export default function OrdersPage() {
  const { t } = useI18n();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [showCreate, setShowCreate] = useState(false);
  const utils = trpc.useUtils();

  const { data: orders = [], isLoading } = trpc.order.list.useQuery({
    search: search || undefined,
    status: statusFilter !== "all" ? statusFilter : undefined,
  });
  const { data: customers = [] } = trpc.customer.list.useQuery();

  const createMutation = trpc.order.create.useMutation({
    onSuccess: () => { utils.order.list.invalidate(); setShowCreate(false); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const updateMutation = trpc.order.update.useMutation({
    onSuccess: () => { utils.order.list.invalidate(); toast.success(t("common.success")); },
  });

  const [form, setForm] = useState({ orderNo: "", customerId: 0, styleNo: "", styleName: "", totalQty: 0, deliveryDate: "", notes: "", details: [{ size: "", color: "", qty: 0 }] });

  const handleCreate = () => {
    if (!form.orderNo || !form.customerId || !form.styleNo) return toast.error("Please fill required fields");
    createMutation.mutate({
      ...form,
      details: form.details.filter(d => d.size && d.color && d.qty > 0),
    });
  };

  const addDetail = () => setForm(f => ({ ...f, details: [...f.details, { size: "", color: "", qty: 0 }] }));
  const removeDetail = (i: number) => setForm(f => ({ ...f, details: f.details.filter((_, idx) => idx !== i) }));
  const updateDetail = (i: number, field: string, value: any) => {
    setForm(f => ({ ...f, details: f.details.map((d, idx) => idx === i ? { ...d, [field]: value } : d) }));
  };

  const customerMap = new Map(customers.map(c => [c.id, c.name]));

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{t("order.title")}</h1>
        <Button onClick={() => { setForm({ orderNo: "", customerId: 0, styleNo: "", styleName: "", totalQty: 0, deliveryDate: "", notes: "", details: [{ size: "", color: "", qty: 0 }] }); setShowCreate(true); }} className="touch-target">
          <Plus className="h-4 w-4 mr-1" /> {t("order.newOrder")}
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder={t("common.search")} value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("common.all")}</SelectItem>
            <SelectItem value="pending">{t("order.pending")}</SelectItem>
            <SelectItem value="scheduled">{t("order.scheduled")}</SelectItem>
            <SelectItem value="in_production">{t("order.in_production")}</SelectItem>
            <SelectItem value="completed">{t("order.completed")}</SelectItem>
            <SelectItem value="shipped">{t("order.shipped")}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium">{t("order.orderNo")}</th>
                  <th className="text-left p-3 font-medium">{t("order.customer")}</th>
                  <th className="text-left p-3 font-medium">{t("order.styleNo")}</th>
                  <th className="text-left p-3 font-medium">{t("order.styleName")}</th>
                  <th className="text-right p-3 font-medium">{t("order.totalQty")}</th>
                  <th className="text-left p-3 font-medium">{t("order.deliveryDate")}</th>
                  <th className="text-left p-3 font-medium">{t("common.status")}</th>
                  <th className="text-left p-3 font-medium">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">{t("common.loading")}</td></tr>
                ) : orders.length === 0 ? (
                  <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                ) : orders.map((order: any) => (
                  <tr key={order.id} className="border-b hover:bg-muted/30 transition-colors">
                    <td className="p-3 font-mono text-xs">{order.orderNo}</td>
                    <td className="p-3">{customerMap.get(order.customerId) || "-"}</td>
                    <td className="p-3 font-mono text-xs">{order.styleNo}</td>
                    <td className="p-3">{order.styleName || "-"}</td>
                    <td className="p-3 text-right font-medium">{order.totalQty?.toLocaleString()}</td>
                    <td className="p-3 text-xs">{order.deliveryDate ? new Date(order.deliveryDate).toLocaleDateString() : "-"}</td>
                    <td className="p-3">
                      <Badge variant="secondary" className={statusColors[order.status] || ""}>
                        {t(`order.${order.status}`)}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <Select value={order.status} onValueChange={(v) => updateMutation.mutate({ id: order.id, status: v as any })}>
                        <SelectTrigger className="h-7 text-xs w-[100px]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">{t("order.pending")}</SelectItem>
                          <SelectItem value="scheduled">{t("order.scheduled")}</SelectItem>
                          <SelectItem value="in_production">{t("order.in_production")}</SelectItem>
                          <SelectItem value="completed">{t("order.completed")}</SelectItem>
                          <SelectItem value="shipped">{t("order.shipped")}</SelectItem>
                        </SelectContent>
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{t("order.newOrder")}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>{t("order.orderNo")} *</Label><Input value={form.orderNo} onChange={e => setForm(f => ({ ...f, orderNo: e.target.value }))} /></div>
            <div>
              <Label>{t("order.customer")} *</Label>
              <Select value={String(form.customerId || "")} onValueChange={v => setForm(f => ({ ...f, customerId: Number(v) }))}>
                <SelectTrigger><SelectValue placeholder={t("common.search")} /></SelectTrigger>
                <SelectContent>{customers.map((c: any) => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>{t("order.styleNo")} *</Label><Input value={form.styleNo} onChange={e => setForm(f => ({ ...f, styleNo: e.target.value }))} /></div>
            <div><Label>{t("order.styleName")}</Label><Input value={form.styleName} onChange={e => setForm(f => ({ ...f, styleName: e.target.value }))} /></div>
            <div><Label>{t("order.totalQty")}</Label><Input type="number" value={form.totalQty} onChange={e => setForm(f => ({ ...f, totalQty: Number(e.target.value) }))} /></div>
            <div><Label>{t("order.deliveryDate")}</Label><Input type="date" value={form.deliveryDate} onChange={e => setForm(f => ({ ...f, deliveryDate: e.target.value }))} /></div>
          </div>
          <div><Label>{t("common.notes")}</Label><Textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>{t("order.sizeColor")}</Label>
              <Button variant="outline" size="sm" onClick={addDetail}><Plus className="h-3 w-3 mr-1" />{t("common.add")}</Button>
            </div>
            {form.details.map((d, i) => (
              <div key={i} className="flex gap-2 items-center">
                <Input placeholder="Size" value={d.size} onChange={e => updateDetail(i, "size", e.target.value)} className="flex-1" />
                <Input placeholder="Color" value={d.color} onChange={e => updateDetail(i, "color", e.target.value)} className="flex-1" />
                <Input type="number" placeholder="Qty" value={d.qty || ""} onChange={e => updateDetail(i, "qty", Number(e.target.value))} className="w-24" />
                <Button variant="ghost" size="icon" onClick={() => removeDetail(i)}><Trash2 className="h-4 w-4" /></Button>
              </div>
            ))}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>{t("common.cancel")}</Button>
            <Button onClick={handleCreate} disabled={createMutation.isPending}>{t("common.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
