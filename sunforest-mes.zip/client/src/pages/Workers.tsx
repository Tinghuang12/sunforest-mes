import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Search, Pencil, Shield } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

// All worker roles ordered by hierarchy (highest first)
const WORKER_ROLES = [
  "general_manager",
  "director",
  "manager",
  "deputy_manager",
  "supervisor",
  "line_leader",
  "leader",
  "worker",
] as const;

type WorkerRole = typeof WORKER_ROLES[number];

// Roles that automatically get full access (no need to set permissions)
const FULL_ACCESS_ROLES: WorkerRole[] = ["general_manager", "director", "manager", "deputy_manager"];

const roleColors: Record<string, string> = {
  general_manager: "bg-red-100 text-red-800",
  director: "bg-orange-100 text-orange-800",
  manager: "bg-purple-100 text-purple-700",
  deputy_manager: "bg-violet-100 text-violet-700",
  supervisor: "bg-indigo-100 text-indigo-700",
  line_leader: "bg-cyan-100 text-cyan-700",
  leader: "bg-blue-100 text-blue-700",
  worker: "bg-gray-100 text-gray-700",
};

// All available permission modules
const ALL_MODULES = [
  "production", "warehouse", "quality", "hr", "finance", "reports", "alerts", "sewing", "import",
] as const;

type PermissionModule = typeof ALL_MODULES[number];

// Parse permissions JSON string to array
function parsePermissions(permissions: string | null | undefined): PermissionModule[] {
  if (!permissions) return [];
  try {
    const parsed = JSON.parse(permissions);
    return Array.isArray(parsed) ? parsed.filter((m: string) => ALL_MODULES.includes(m as any)) : [];
  } catch {
    return [];
  }
}

export default function WorkersPage() {
  const { t, locale } = useI18n();
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [showPermDialog, setShowPermDialog] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [permEditWorker, setPermEditWorker] = useState<any>(null);
  const [permChecked, setPermChecked] = useState<PermissionModule[]>([]);
  const utils = trpc.useUtils();

  const { data: workers = [], isLoading } = trpc.worker.list.useQuery({
    search: search || undefined,
    role: roleFilter !== "all" ? roleFilter : undefined,
  });
  const { data: lines = [] } = trpc.line.list.useQuery();
  const lineMap = useMemo(() => new Map(lines.map((l: any) => [l.id, locale === 'vi' ? (l.nameVi || l.name) : l.name])), [lines, locale]);

  const createMutation = trpc.worker.create.useMutation({
    onSuccess: () => { utils.worker.list.invalidate(); setShowForm(false); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const updateMutation = trpc.worker.update.useMutation({
    onSuccess: () => { utils.worker.list.invalidate(); setShowForm(false); setEditId(null); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const permMutation = trpc.worker.update.useMutation({
    onSuccess: () => { utils.worker.list.invalidate(); setShowPermDialog(false); setPermEditWorker(null); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const [form, setForm] = useState({ employeeCode: "", name: "", nameVi: "", phone: "", workerRole: "worker" as WorkerRole, lineId: undefined as number | undefined, salaryType: "monthly" as "monthly" | "hourly", monthlySalary: "", hourlyRate: "", pieceRate: "", joinDate: "" });

  const openEdit = (w: any) => {
    setEditId(w.id);
    setForm({
      employeeCode: w.employeeCode,
      name: w.name,
      nameVi: w.nameVi || "",
      phone: w.phone || "",
      workerRole: w.workerRole,
      lineId: w.lineId || undefined,
      salaryType: w.salaryType || "monthly",
      monthlySalary: w.monthlySalary || "",
      hourlyRate: w.hourlyRate || "",
      pieceRate: w.pieceRate || "",
      joinDate: w.joinDate ? new Date(w.joinDate).toISOString().split("T")[0] : "",
    });
    setShowForm(true);
  };

  const openPermissions = (w: any) => {
    setPermEditWorker(w);
    setPermChecked(parsePermissions(w.permissions));
    setShowPermDialog(true);
  };

  const togglePerm = (mod: PermissionModule) => {
    setPermChecked(prev =>
      prev.includes(mod) ? prev.filter(m => m !== mod) : [...prev, mod]
    );
  };

  const selectAllPerms = () => {
    setPermChecked([...ALL_MODULES]);
  };

  const clearAllPerms = () => {
    setPermChecked([]);
  };

  const savePermissions = () => {
    if (!permEditWorker) return;
    permMutation.mutate({
      id: permEditWorker.id,
      permissions: JSON.stringify(permChecked),
    });
  };

  const handleSave = () => {
    if (!form.employeeCode || !form.name) return toast.error("Required fields missing");
    if (editId) {
      updateMutation.mutate({ id: editId, ...form });
    } else {
      createMutation.mutate(form);
    }
  };

  // Check if a role has full access
  const hasFullAccess = (role: string) => FULL_ACCESS_ROLES.includes(role as WorkerRole);

  // Count permissions for display
  const getPermCount = (w: any) => {
    if (hasFullAccess(w.workerRole)) return t("perm.allAccess");
    const perms = parsePermissions(w.permissions);
    if (perms.length === 0) return t("perm.noAccess");
    return `${perms.length} ${t("perm.modules")}`;
  };

  const getPermBadgeVariant = (w: any) => {
    if (hasFullAccess(w.workerRole)) return "default";
    const perms = parsePermissions(w.permissions);
    return perms.length > 0 ? "secondary" : "outline";
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{t("worker.title")}</h1>
        <Button onClick={() => { setEditId(null); setForm({ employeeCode: "", name: "", nameVi: "", phone: "", workerRole: "worker", lineId: undefined, salaryType: "monthly", monthlySalary: "", hourlyRate: "", pieceRate: "", joinDate: "" }); setShowForm(true); }} className="touch-target">
          <Plus className="h-4 w-4 mr-1" /> {t("worker.newWorker")}
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder={t("common.search")} value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("common.all")}</SelectItem>
            {WORKER_ROLES.map(role => (
              <SelectItem key={role} value={role}>{t(`worker.${role}`)}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium">{t("worker.code")}</th>
                  <th className="text-left p-3 font-medium">{t("worker.name")}</th>
                  <th className="text-left p-3 font-medium">{t("worker.nameVi")}</th>
                  <th className="text-left p-3 font-medium">{t("worker.role")}</th>
                  <th className="text-left p-3 font-medium">{t("perm.title")}</th>
                  <th className="text-left p-3 font-medium">{t("worker.line")}</th>
                  <th className="text-left p-3 font-medium">{t("common.status")}</th>
                  <th className="text-left p-3 font-medium">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">{t("common.loading")}</td></tr>
                ) : workers.length === 0 ? (
                  <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                ) : workers.map((w: any) => (
                  <tr key={w.id} className="border-b hover:bg-muted/30">
                    <td className="p-3 font-mono text-xs">{w.employeeCode}</td>
                    <td className="p-3 font-medium">{w.name}</td>
                    <td className="p-3">{w.nameVi || "-"}</td>
                    <td className="p-3"><Badge variant="secondary" className={roleColors[w.workerRole] || ""}>{t(`worker.${w.workerRole}`)}</Badge></td>
                    <td className="p-3">
                      <Badge variant={getPermBadgeVariant(w) as any} className="cursor-pointer" onClick={() => openPermissions(w)}>
                        <Shield className="h-3 w-3 mr-1" />
                        {getPermCount(w)}
                      </Badge>
                    </td>
                    <td className="p-3">{lineMap.get(w.lineId!) || "-"}</td>
                    <td className="p-3"><Badge variant={w.status === "active" ? "default" : "secondary"}>{t(`common.${w.status}`)}</Badge></td>
                    <td className="p-3 flex gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(w)} title={t("common.edit")}>
                        <Pencil className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openPermissions(w)} title={t("perm.title")}>
                        <Shield className="h-3.5 w-3.5" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Worker Edit Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editId ? t("common.edit") : t("worker.newWorker")}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>{t("worker.code")} *</Label><Input value={form.employeeCode} onChange={e => setForm(f => ({ ...f, employeeCode: e.target.value }))} /></div>
            <div><Label>{t("worker.name")} *</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
            <div><Label>{t("worker.nameVi")}</Label><Input value={form.nameVi} onChange={e => setForm(f => ({ ...f, nameVi: e.target.value }))} /></div>
            <div><Label>{t("worker.phone")}</Label><Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} /></div>
            <div>
              <Label>{t("worker.role")}</Label>
              <Select value={form.workerRole} onValueChange={v => setForm(f => ({ ...f, workerRole: v as WorkerRole }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {WORKER_ROLES.map(role => (
                    <SelectItem key={role} value={role}>{t(`worker.${role}`)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {hasFullAccess(form.workerRole) && (
                <p className="text-xs text-green-600 mt-1">{t("perm.autoFullAccess")}</p>
              )}
            </div>
            <div>
              <Label>{t("worker.line")}</Label>
              <Select value={String(form.lineId || "")} onValueChange={v => setForm(f => ({ ...f, lineId: v ? Number(v) : undefined }))}>
                <SelectTrigger><SelectValue placeholder="-" /></SelectTrigger>
                <SelectContent>{lines.map((l: any) => <SelectItem key={l.id} value={String(l.id)}>{locale === 'vi' ? (l.nameVi || l.name) : l.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t("worker.salaryType")}</Label>
              <Select value={form.salaryType} onValueChange={v => setForm(f => ({ ...f, salaryType: v as any }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="hourly">{t("worker.hourly")}</SelectItem>
                  <SelectItem value="monthly">{t("worker.monthly")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {form.salaryType === "monthly" && (
              <div><Label>{t("worker.monthlySalary")}</Label><Input value={form.monthlySalary} onChange={e => setForm(f => ({ ...f, monthlySalary: e.target.value }))} type="number" placeholder="0" /></div>
            )}
            {(form.salaryType as string) === "hourly" && (
              <div><Label>{t("worker.hourlyRate")}</Label><Input value={form.hourlyRate} onChange={e => setForm(f => ({ ...f, hourlyRate: e.target.value }))} type="number" placeholder="0" /></div>
            )}
            <div><Label>{t("worker.pieceRate")}</Label><Input value={form.pieceRate} onChange={e => setForm(f => ({ ...f, pieceRate: e.target.value }))} type="number" placeholder="0" /></div>
            <div className="col-span-2"><Label>{t("worker.joinDate")}</Label><Input type="date" value={form.joinDate} onChange={e => setForm(f => ({ ...f, joinDate: e.target.value }))} /></div>
            {form.salaryType === "monthly" && <div className="col-span-2 text-xs text-muted-foreground">{t("worker.salaryNote")}</div>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowForm(false)}>{t("common.cancel")}</Button>
            <Button onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>{t("common.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Permission Edit Dialog */}
      <Dialog open={showPermDialog} onOpenChange={setShowPermDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              {t("perm.editTitle")}
            </DialogTitle>
          </DialogHeader>

          {permEditWorker && (
            <div className="space-y-4">
              {/* Worker info */}
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                <div>
                  <div className="font-medium">{permEditWorker.name}</div>
                  <div className="text-xs text-muted-foreground">{permEditWorker.employeeCode} · {t(`worker.${permEditWorker.workerRole}`)}</div>
                </div>
              </div>

              {/* Full-access role notice */}
              {hasFullAccess(permEditWorker.workerRole) ? (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-sm text-green-800">
                  <div className="font-medium mb-1">{t("perm.managerNote")}</div>
                  <div className="text-xs text-green-600">{t("perm.managerDesc")}</div>
                </div>
              ) : (
                <>
                  {/* Quick actions */}
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={selectAllPerms}>{t("perm.selectAll")}</Button>
                    <Button variant="outline" size="sm" onClick={clearAllPerms}>{t("perm.clearAll")}</Button>
                  </div>

                  {/* Module checkboxes */}
                  <div className="grid grid-cols-1 gap-2">
                    {ALL_MODULES.map(mod => (
                      <label
                        key={mod}
                        className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/30 cursor-pointer transition-colors"
                      >
                        <Checkbox
                          checked={permChecked.includes(mod)}
                          onCheckedChange={() => togglePerm(mod)}
                        />
                        <div className="flex-1">
                          <div className="font-medium text-sm">{t(`perm.mod.${mod}`)}</div>
                          <div className="text-xs text-muted-foreground">{t(`perm.modDesc.${mod}`)}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPermDialog(false)}>{t("common.cancel")}</Button>
            {permEditWorker && !hasFullAccess(permEditWorker.workerRole) && (
              <Button onClick={savePermissions} disabled={permMutation.isPending}>{t("common.save")}</Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
