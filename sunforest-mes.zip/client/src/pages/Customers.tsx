import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus, Pencil } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function CustomersPage() {
  const { t } = useI18n();
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data: customers = [], isLoading } = trpc.customer.list.useQuery();

  const createMutation = trpc.customer.create.useMutation({
    onSuccess: () => { utils.customer.list.invalidate(); setShowForm(false); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const updateMutation = trpc.customer.update.useMutation({
    onSuccess: () => { utils.customer.list.invalidate(); setShowForm(false); setEditId(null); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const [form, setForm] = useState({ name: "", contactPerson: "", phone: "", email: "", address: "" });

  const openEdit = (c: any) => {
    setEditId(c.id);
    setForm({ name: c.name, contactPerson: c.contactPerson || "", phone: c.phone || "", email: c.email || "", address: c.address || "" });
    setShowForm(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("cust.title")}</h1>
        <Button onClick={() => { setEditId(null); setForm({ name: "", contactPerson: "", phone: "", email: "", address: "" }); setShowForm(true); }} className="touch-target">
          <Plus className="h-4 w-4 mr-1" /> {t("cust.newCustomer")}
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium">{t("cust.name")}</th>
                  <th className="text-left p-3 font-medium">{t("cust.contact")}</th>
                  <th className="text-left p-3 font-medium">{t("cust.phone")}</th>
                  <th className="text-left p-3 font-medium">{t("cust.email")}</th>
                  <th className="text-left p-3 font-medium">{t("cust.address")}</th>
                  <th className="text-left p-3 font-medium">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">{t("common.loading")}</td></tr>
                ) : customers.length === 0 ? (
                  <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                ) : customers.map((c: any) => (
                  <tr key={c.id} className="border-b hover:bg-muted/30">
                    <td className="p-3 font-medium">{c.name}</td>
                    <td className="p-3">{c.contactPerson || "-"}</td>
                    <td className="p-3 text-xs">{c.phone || "-"}</td>
                    <td className="p-3 text-xs">{c.email || "-"}</td>
                    <td className="p-3 text-xs">{c.address || "-"}</td>
                    <td className="p-3">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(c)}><Pencil className="h-3.5 w-3.5" /></Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editId ? t("common.edit") : t("cust.newCustomer")}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>{t("cust.name")} *</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
            <div><Label>{t("cust.contact")}</Label><Input value={form.contactPerson} onChange={e => setForm(f => ({ ...f, contactPerson: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>{t("cust.phone")}</Label><Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} /></div>
              <div><Label>{t("cust.email")}</Label><Input value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} /></div>
            </div>
            <div><Label>{t("cust.address")}</Label><Input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowForm(false)}>{t("common.cancel")}</Button>
            <Button onClick={() => {
              if (!form.name) return;
              if (editId) updateMutation.mutate({ id: editId, ...form });
              else createMutation.mutate(form);
            }} disabled={createMutation.isPending || updateMutation.isPending}>{t("common.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
