import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useState, useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

const COLORS = ["#0d9488", "#0891b2", "#6366f1", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#10b981"];

export default function ReportsPage() {
  const { t, locale } = useI18n();
  const [startDate, setStartDate] = useState(() => {
    const d = new Date(); d.setDate(d.getDate() - 30); return d.toISOString().split("T")[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split("T")[0]);

  const { data: efficiency = [] } = trpc.dashboard.productionEfficiency.useQuery({ startDate, endDate });
  const { data: defectRate = [] } = trpc.dashboard.defectRate.useQuery({ startDate, endDate });
  const { data: workerProd = [] } = trpc.dashboard.workerProductivity.useQuery({ startDate, endDate });
  const { data: dailyProd = [] } = trpc.dashboard.dailyProduction.useQuery({ startDate, endDate });
  const { data: workers = [] } = trpc.worker.list.useQuery({ status: "active" });
  const { data: lines = [] } = trpc.line.list.useQuery();
  const { data: attendance = [] } = trpc.attendance.list.useQuery({ startDate, endDate });

  const workerMap = new Map(workers.map((w: any) => [w.id, w]));
  const lineMap = new Map(lines.map((l: any) => [l.id, locale === 'vi' ? (l.nameVi || l.name) : l.name]));

  const stationMap: Record<string, string> = {
    cutting: t("prod.cutting"), sewing: t("prod.sewing"), ironing: t("prod.ironing"), packing: t("prod.packing"),
  };

  // Production efficiency by line
  const lineEfficiency = useMemo(() => {
    const map = new Map<number, { qty: number; defects: number }>();
    efficiency.forEach((e: any) => {
      const existing = map.get(e.lineId) || { qty: 0, defects: 0 };
      existing.qty += Number(e.totalQty) || 0;
      existing.defects += Number(e.totalDefects) || 0;
      map.set(e.lineId, existing);
    });
    return Array.from(map.entries()).map(([lineId, data]) => ({
      name: lineMap.get(lineId) || `#${lineId}`,
      qty: data.qty,
      defects: data.defects,
      rate: data.qty > 0 ? ((data.defects / data.qty) * 100).toFixed(1) : "0",
    }));
  }, [efficiency, lineMap]);

  // Worker ranking
  const workerRanking = useMemo(() => {
    return workerProd.map((wp: any) => {
      const worker = workerMap.get(wp.workerId);
      return {
        name: worker?.name || `#${wp.workerId}`,
        code: worker?.employeeCode || "",
        totalQty: Number(wp.totalQty) || 0,
        totalDefects: Number(wp.totalDefects) || 0,
        days: Number(wp.days) || 1,
        avgDaily: Math.round((Number(wp.totalQty) || 0) / (Number(wp.days) || 1)),
      };
    }).sort((a: any, b: any) => b.totalQty - a.totalQty);
  }, [workerProd, workerMap]);

  // Defect pie chart
  const defectPieData = useMemo(() => {
    return defectRate.map((d: any) => ({
      name: t(`qc.${d.defectType}`) || d.defectType,
      value: Number(d.totalQty) || 0,
    }));
  }, [defectRate, t]);

  // Attendance summary
  const attendanceSummary = useMemo(() => {
    const map = new Map<string, Record<string, number>>();
    attendance.forEach((a: any) => {
      const dateStr = a.attendanceDate instanceof Date ? a.attendanceDate.toISOString().split("T")[0] : String(a.attendanceDate);
      if (!map.has(dateStr)) map.set(dateStr, { present: 0, absent: 0, late: 0, leave: 0 });
      const entry = map.get(dateStr)!;
      entry[a.status] = (entry[a.status] || 0) + 1;
    });
    return Array.from(map.entries()).map(([date, counts]) => ({ date: date.slice(5), ...counts })).sort((a, b) => a.date.localeCompare(b.date));
  }, [attendance]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{t("report.title")}</h1>
        <div className="flex items-center gap-2">
          <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-[150px]" />
          <span className="text-muted-foreground">~</span>
          <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-[150px]" />
        </div>
      </div>

      <Tabs defaultValue="attendance">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="attendance">{t("report.attendanceReport")}</TabsTrigger>
          <TabsTrigger value="production">{t("report.productionReport")}</TabsTrigger>
          <TabsTrigger value="capacity">{t("report.capacityReport")}</TabsTrigger>
          <TabsTrigger value="defect">{t("report.defectReport")}</TabsTrigger>
        </TabsList>

        <TabsContent value="attendance" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>{t("report.attendanceReport")}</CardTitle></CardHeader>
            <CardContent>
              {attendanceSummary.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={attendanceSummary}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="date" fontSize={11} />
                    <YAxis fontSize={11} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="present" name={t("att.present")} fill={COLORS[0]} radius={[2, 2, 0, 0]} />
                    <Bar dataKey="late" name={t("att.late")} fill={COLORS[3]} radius={[2, 2, 0, 0]} />
                    <Bar dataKey="absent" name={t("att.absent")} fill={COLORS[4]} radius={[2, 2, 0, 0]} />
                    <Bar dataKey="leave" name={t("att.leave")} fill={COLORS[5]} radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">{t("common.noData")}</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="production" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>{t("report.productionReport")}</CardTitle></CardHeader>
            <CardContent>
              {lineEfficiency.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={lineEfficiency}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="name" fontSize={11} />
                    <YAxis fontSize={11} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="qty" name={t("common.qty")} fill={COLORS[0]} radius={[2, 2, 0, 0]} />
                    <Bar dataKey="defects" name={t("prod.defectQty")} fill={COLORS[4]} radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">{t("common.noData")}</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="capacity" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>{t("report.workerRanking")}</CardTitle></CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="text-left p-3 font-medium">#</th>
                      <th className="text-left p-3 font-medium">{t("worker.code")}</th>
                      <th className="text-left p-3 font-medium">{t("worker.name")}</th>
                      <th className="text-right p-3 font-medium">{t("common.total")}</th>
                      <th className="text-right p-3 font-medium">{t("prod.defectQty")}</th>
                      <th className="text-right p-3 font-medium">{t("common.date")}s</th>
                      <th className="text-right p-3 font-medium">Avg/Day</th>
                    </tr>
                  </thead>
                  <tbody>
                    {workerRanking.length === 0 ? (
                      <tr><td colSpan={7} className="p-6 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                    ) : workerRanking.map((w: any, i: number) => (
                      <tr key={i} className="border-b hover:bg-muted/30">
                        <td className="p-3 font-bold">{i + 1}</td>
                        <td className="p-3 font-mono text-xs">{w.code}</td>
                        <td className="p-3">{w.name}</td>
                        <td className="p-3 text-right font-medium">{w.totalQty.toLocaleString()}</td>
                        <td className="p-3 text-right text-destructive">{w.totalDefects}</td>
                        <td className="p-3 text-right">{w.days}</td>
                        <td className="p-3 text-right font-medium">{w.avgDaily.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="defect" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>{t("report.defectReport")}</CardTitle></CardHeader>
            <CardContent>
              {defectPieData.length > 0 ? (
                <div className="flex flex-col md:flex-row items-center gap-8">
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie data={defectPieData} cx="50%" cy="50%" outerRadius={120} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} fontSize={11}>
                        {defectPieData.map((_: any, i: number) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-[300px] flex items-center justify-center text-muted-foreground">{t("common.noData")}</div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
