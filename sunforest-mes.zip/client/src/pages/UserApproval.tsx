import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useI18n } from "@/lib/i18n";
import {
  Loader2, CheckCircle2, XCircle, Clock, UserCheck, Users, Shield,
  MoreHorizontal, KeyRound, Pencil, ShieldCheck, ShieldOff
} from "lucide-react";
import { toast } from "sonner";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function UserApprovalPage() {
  const { t } = useI18n();
  const [filter, setFilter] = useState<string>("all");
  const utils = trpc.useUtils();

  // Dialog states
  const [roleDialog, setRoleDialog] = useState<{ open: boolean; user: any }>({ open: false, user: null });
  const [nameDialog, setNameDialog] = useState<{ open: boolean; user: any; name: string }>({ open: false, user: null, name: "" });
  const [passwordDialog, setPasswordDialog] = useState<{ open: boolean; user: any; password: string }>({ open: false, user: null, password: "" });

  const { data: allUsers = [], isLoading } = trpc.account.listUsers.useQuery();

  const invalidateAll = () => {
    utils.account.listUsers.invalidate();
    utils.account.listPending.invalidate();
    utils.account.pendingCount.invalidate();
  };

  const approveMutation = trpc.account.approve.useMutation({
    onSuccess: () => { toast.success(t("auth.approveSuccess")); invalidateAll(); },
    onError: (error) => { toast.error(error.message); },
  });

  const rejectMutation = trpc.account.reject.useMutation({
    onSuccess: () => { toast.success(t("auth.rejectSuccess")); invalidateAll(); },
    onError: (error) => { toast.error(error.message); },
  });

  const updateRoleMutation = trpc.account.updateRole.useMutation({
    onSuccess: () => {
      toast.success(t("auth.roleUpdateSuccess"));
      invalidateAll();
      setRoleDialog({ open: false, user: null });
    },
    onError: (error) => { toast.error(error.message); },
  });

  const updateNameMutation = trpc.account.updateName.useMutation({
    onSuccess: () => {
      toast.success(t("auth.nameUpdateSuccess"));
      invalidateAll();
      setNameDialog({ open: false, user: null, name: "" });
    },
    onError: (error) => { toast.error(error.message); },
  });

  const resetPasswordMutation = trpc.account.resetPassword.useMutation({
    onSuccess: () => {
      toast.success(t("auth.passwordResetSuccess"));
      setPasswordDialog({ open: false, user: null, password: "" });
    },
    onError: (error) => { toast.error(error.message); },
  });

  const filteredUsers = allUsers.filter((u: any) => {
    if (filter === "all") return true;
    return u.approvalStatus === filter;
  });

  const pendingCount = allUsers.filter((u: any) => u.approvalStatus === "pending").length;
  const approvedCount = allUsers.filter((u: any) => u.approvalStatus === "approved").length;
  const rejectedCount = allUsers.filter((u: any) => u.approvalStatus === "rejected").length;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200"><Clock className="h-3 w-3 mr-1" />{t("auth.statusPending")}</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><CheckCircle2 className="h-3 w-3 mr-1" />{t("auth.statusApproved")}</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200"><XCircle className="h-3 w-3 mr-1" />{t("auth.statusRejected")}</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getLoginMethodBadge = (method: string | null) => {
    if (method === "password") return <Badge variant="secondary">{t("auth.methodPassword")}</Badge>;
    if (method === "google") return <Badge variant="secondary">Google</Badge>;
    return <Badge variant="secondary">{method || "OAuth"}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{t("auth.userApprovalTitle")}</h1>
        <p className="text-muted-foreground mt-1">{t("auth.userApprovalDesc")}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setFilter("pending")}>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="h-10 w-10 rounded-lg bg-amber-100 flex items-center justify-center">
              <Clock className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{pendingCount}</p>
              <p className="text-sm text-muted-foreground">{t("auth.statusPending")}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setFilter("approved")}>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="h-10 w-10 rounded-lg bg-green-100 flex items-center justify-center">
              <UserCheck className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{approvedCount}</p>
              <p className="text-sm text-muted-foreground">{t("auth.statusApproved")}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setFilter("rejected")}>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="h-10 w-10 rounded-lg bg-red-100 flex items-center justify-center">
              <XCircle className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{rejectedCount}</p>
              <p className="text-sm text-muted-foreground">{t("auth.statusRejected")}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-4">
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("common.all")} ({allUsers.length})</SelectItem>
            <SelectItem value="pending">{t("auth.statusPending")} ({pendingCount})</SelectItem>
            <SelectItem value="approved">{t("auth.statusApproved")} ({approvedCount})</SelectItem>
            <SelectItem value="rejected">{t("auth.statusRejected")} ({rejectedCount})</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Users Table */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredUsers.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Users className="h-8 w-8 mb-2" />
              <p>{t("common.noData")}</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("auth.colName")}</TableHead>
                  <TableHead>{t("auth.colUsername")}</TableHead>
                  <TableHead>{t("auth.colPhone")}</TableHead>
                  <TableHead>{t("auth.colLoginMethod")}</TableHead>
                  <TableHead>{t("auth.colRole")}</TableHead>
                  <TableHead>{t("auth.colStatus")}</TableHead>
                  <TableHead>{t("auth.colRegisteredAt")}</TableHead>
                  <TableHead className="text-right">{t("common.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user: any) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name || "-"}</TableCell>
                    <TableCell>{user.username || user.email || "-"}</TableCell>
                    <TableCell>{user.phone || "-"}</TableCell>
                    <TableCell>{getLoginMethodBadge(user.loginMethod)}</TableCell>
                    <TableCell>
                      {user.role === "admin" ? (
                        <Badge className="bg-purple-100 text-purple-700 border-purple-200"><Shield className="h-3 w-3 mr-1" />{t("auth.roleAdmin")}</Badge>
                      ) : (
                        <Badge variant="secondary">{t("auth.roleUser")}</Badge>
                      )}
                    </TableCell>
                    <TableCell>{getStatusBadge(user.approvalStatus)}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "-"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {/* Approve / Reject buttons for pending */}
                        {user.approvalStatus === "pending" && (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-green-600 hover:text-green-700 hover:bg-green-50"
                              onClick={() => approveMutation.mutate({ userId: user.id })}
                              disabled={approveMutation.isPending}
                            >
                              {approveMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <CheckCircle2 className="h-3 w-3 mr-1" />}
                              {t("auth.approveBtn")}
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              onClick={() => rejectMutation.mutate({ userId: user.id })}
                              disabled={rejectMutation.isPending}
                            >
                              {rejectMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <XCircle className="h-3 w-3 mr-1" />}
                              {t("auth.rejectBtn")}
                            </Button>
                          </>
                        )}
                        {/* Re-approve for rejected */}
                        {user.approvalStatus === "rejected" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-green-600 hover:text-green-700 hover:bg-green-50"
                            onClick={() => approveMutation.mutate({ userId: user.id })}
                            disabled={approveMutation.isPending}
                          >
                            {approveMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : <CheckCircle2 className="h-3 w-3 mr-1" />}
                            {t("auth.approveBtn")}
                          </Button>
                        )}

                        {/* More actions dropdown for all users */}
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {/* Toggle role */}
                            {user.role === "admin" ? (
                              <DropdownMenuItem
                                onClick={() => setRoleDialog({ open: true, user: { ...user, newRole: "user" } })}
                              >
                                <ShieldOff className="h-4 w-4 mr-2" />
                                {t("auth.demoteToUser")}
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem
                                onClick={() => setRoleDialog({ open: true, user: { ...user, newRole: "admin" } })}
                              >
                                <ShieldCheck className="h-4 w-4 mr-2" />
                                {t("auth.promoteToAdmin")}
                              </DropdownMenuItem>
                            )}

                            {/* Edit name */}
                            <DropdownMenuItem
                              onClick={() => setNameDialog({ open: true, user, name: user.name || "" })}
                            >
                              <Pencil className="h-4 w-4 mr-2" />
                              {t("auth.editName")}
                            </DropdownMenuItem>

                            {/* Reset password (only for password-based accounts) */}
                            {user.loginMethod === "password" && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => setPasswordDialog({ open: true, user, password: "" })}
                                >
                                  <KeyRound className="h-4 w-4 mr-2" />
                                  {t("auth.resetPassword")}
                                </DropdownMenuItem>
                              </>
                            )}

                            {/* Revoke approved password account */}
                            {user.approvalStatus === "approved" && user.loginMethod === "password" && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  className="text-red-600"
                                  onClick={() => rejectMutation.mutate({ userId: user.id })}
                                >
                                  <XCircle className="h-4 w-4 mr-2" />
                                  {t("auth.revokeBtn")}
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Role Change Confirmation Dialog */}
      <Dialog open={roleDialog.open} onOpenChange={(open) => !open && setRoleDialog({ open: false, user: null })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("auth.changeRoleTitle")}</DialogTitle>
            <DialogDescription>
              {roleDialog.user?.newRole === "admin"
                ? `${t("auth.promoteConfirm")} ${roleDialog.user?.name || roleDialog.user?.username || ""}`
                : `${t("auth.demoteConfirm")} ${roleDialog.user?.name || roleDialog.user?.username || ""}`
              }
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
              <div className="flex-1">
                <p className="font-medium">{roleDialog.user?.name || "-"}</p>
                <p className="text-sm text-muted-foreground">{roleDialog.user?.username || roleDialog.user?.email || "-"}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{roleDialog.user?.role === "admin" ? t("auth.roleAdmin") : t("auth.roleUser")}</Badge>
                <span className="text-muted-foreground">→</span>
                <Badge className={roleDialog.user?.newRole === "admin" ? "bg-purple-100 text-purple-700 border-purple-200" : ""}>
                  {roleDialog.user?.newRole === "admin" ? t("auth.roleAdmin") : t("auth.roleUser")}
                </Badge>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRoleDialog({ open: false, user: null })}>
              {t("common.cancel")}
            </Button>
            <Button
              onClick={() => {
                if (roleDialog.user) {
                  updateRoleMutation.mutate({ userId: roleDialog.user.id, role: roleDialog.user.newRole });
                }
              }}
              disabled={updateRoleMutation.isPending}
            >
              {updateRoleMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t("common.confirm")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Name Dialog */}
      <Dialog open={nameDialog.open} onOpenChange={(open) => !open && setNameDialog({ open: false, user: null, name: "" })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("auth.editNameTitle")}</DialogTitle>
            <DialogDescription>{t("auth.editNameDesc")}</DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <Label>{t("auth.colName")}</Label>
              <Input
                value={nameDialog.name}
                onChange={(e) => setNameDialog((prev) => ({ ...prev, name: e.target.value }))}
                placeholder={t("auth.enterName")}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNameDialog({ open: false, user: null, name: "" })}>
              {t("common.cancel")}
            </Button>
            <Button
              onClick={() => {
                if (nameDialog.user && nameDialog.name.trim()) {
                  updateNameMutation.mutate({ userId: nameDialog.user.id, name: nameDialog.name.trim() });
                }
              }}
              disabled={updateNameMutation.isPending || !nameDialog.name.trim()}
            >
              {updateNameMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t("common.save")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset Password Dialog */}
      <Dialog open={passwordDialog.open} onOpenChange={(open) => !open && setPasswordDialog({ open: false, user: null, password: "" })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("auth.resetPasswordTitle")}</DialogTitle>
            <DialogDescription>
              {`${t("auth.resetPasswordDesc")} ${passwordDialog.user?.name || passwordDialog.user?.username || ""}`}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <Label>{t("auth.newPassword")}</Label>
              <Input
                type="password"
                value={passwordDialog.password}
                onChange={(e) => setPasswordDialog((prev) => ({ ...prev, password: e.target.value }))}
                placeholder={t("auth.enterNewPassword")}
                minLength={6}
              />
              <p className="text-xs text-muted-foreground">{t("auth.passwordMinLength")}</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPasswordDialog({ open: false, user: null, password: "" })}>
              {t("common.cancel")}
            </Button>
            <Button
              onClick={() => {
                if (passwordDialog.user && passwordDialog.password.length >= 6) {
                  resetPasswordMutation.mutate({ userId: passwordDialog.user.id, newPassword: passwordDialog.password });
                }
              }}
              disabled={resetPasswordMutation.isPending || passwordDialog.password.length < 6}
            >
              {resetPasswordMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {t("auth.resetPasswordBtn")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
