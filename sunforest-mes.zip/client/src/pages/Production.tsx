import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Scissors, Shirt, Wind, Package, Send } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

import { Warehouse, CheckCircle } from "lucide-react";

const stationIcons: Record<string, any> = {
  warehouse: Warehouse,
  cutting: Scissors,
  semi_inspection: CheckCircle,
  sewing: Shirt,
  final_inspection: CheckCircle,
  ironing: Wind,
  packing: Package,
};

export default function ProductionPage() {
  const { t } = useI18n();
  const [station, setStation] = useState<string>("sewing");
  const [workOrderId, setWorkOrderId] = useState<number>(0);
  const [workerId, setWorkerId] = useState<number>(0);
  const [qty, setQty] = useState<number>(0);
  const [defectQty, setDefectQty] = useState<number>(0);
  const utils = trpc.useUtils();

  const today = useMemo(() => new Date().toISOString().split("T")[0], []);

  const { data: workOrders = [] } = trpc.workOrder.list.useQuery({ status: "in_progress" });
  const { data: workers = [] } = trpc.worker.list.useQuery({ status: "active" });
  const { data: todayReports = [] } = trpc.production.list.useQuery({ startDate: today, endDate: today });

  const createMutation = trpc.production.create.useMutation({
    onSuccess: () => {
      utils.production.list.invalidate();
      setQty(0);
      setDefectQty(0);
      toast.success(t("common.success"));
    },
    onError: () => toast.error(t("common.error")),
  });

  const handleSubmit = () => {
    if (!workOrderId || !workerId || qty <= 0) {
      toast.error(locale === "vi" ? "Vui lòng điền đầy đủ thông tin" : "請填寫完整資訊");
      return;
    }
    const selectedWO = workOrders.find((wo: any) => wo.id === workOrderId);
    createMutation.mutate({
      workOrderId,
      workerId,
      lineId: selectedWO?.lineId || undefined,
      station: station as any,
      qty,
      defectQty,
      reportDate: today,
    });
  };

  const { locale } = useI18n();
  const stations = ["warehouse", "cutting", "semi_inspection", "sewing", "final_inspection", "ironing", "packing"];

  const quickQtyButtons = [10, 20, 50, 100];

  // Today's summary by station
  const stationSummary = useMemo(() => {
    const summary: Record<string, number> = {};
    todayReports.forEach((r: any) => {
      summary[r.station] = (summary[r.station] || 0) + (r.qty || 0);
    });
    return summary;
  }, [todayReports]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">{t("prod.title")}</h1>

      {/* Today's summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {stations.map(s => {
          const Icon = stationIcons[s];
          return (
            <Card key={s} className={`cursor-pointer transition-all ${station === s ? "ring-2 ring-primary shadow-md" : "hover:shadow-sm"}`} onClick={() => setStation(s)}>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={`p-3 rounded-xl ${station === s ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                  <Icon className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">{t(`station.${s}`)}</p>
                  <p className="text-2xl font-bold">{(stationSummary[s] || 0).toLocaleString()}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Report form - touch optimized */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="h-5 w-5" />
            {t("prod.submitReport")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-base">{t("wo.workOrderNo")} *</Label>
              <Select value={String(workOrderId || "")} onValueChange={v => setWorkOrderId(Number(v))}>
                <SelectTrigger className="h-12 text-base touch-target"><SelectValue placeholder={t("common.search")} /></SelectTrigger>
                <SelectContent>
                  {workOrders.map((wo: any) => (
                    <SelectItem key={wo.id} value={String(wo.id)} className="h-10">
                      {wo.workOrderNo} ({wo.targetQty})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-base">{t("prod.worker")} *</Label>
              <Select value={String(workerId || "")} onValueChange={v => setWorkerId(Number(v))}>
                <SelectTrigger className="h-12 text-base touch-target"><SelectValue placeholder={t("common.search")} /></SelectTrigger>
                <SelectContent>
                  {workers.map((w: any) => (
                    <SelectItem key={w.id} value={String(w.id)} className="h-10">
                      {w.employeeCode} - {w.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-base">{t("prod.reportQty")} *</Label>
              <Input type="number" value={qty || ""} onChange={e => setQty(Number(e.target.value))} className="h-14 text-2xl font-bold text-center touch-target" />
              <div className="flex gap-2 mt-2">
                {quickQtyButtons.map(q => (
                  <Button key={q} variant="outline" size="sm" className="flex-1 h-10 touch-target" onClick={() => setQty(prev => prev + q)}>
                    +{q}
                  </Button>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-base">{t("prod.defectQty")}</Label>
              <Input type="number" value={defectQty || ""} onChange={e => setDefectQty(Number(e.target.value))} className="h-14 text-2xl font-bold text-center touch-target" />
              <div className="flex gap-2 mt-2">
                {[1, 2, 5, 10].map(q => (
                  <Button key={q} variant="outline" size="sm" className="flex-1 h-10 touch-target" onClick={() => setDefectQty(prev => prev + q)}>
                    +{q}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          <Button onClick={handleSubmit} disabled={createMutation.isPending} size="lg" className="w-full h-14 text-lg touch-target">
            <Send className="h-5 w-5 mr-2" />
            {t("prod.submitReport")}
          </Button>
        </CardContent>
      </Card>

      {/* Today's reports */}
      <Card>
        <CardHeader>
          <CardTitle>{t("common.today")} - {t("prod.title")}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium">{t("prod.station")}</th>
                  <th className="text-left p-3 font-medium">{t("wo.workOrderNo")}</th>
                  <th className="text-left p-3 font-medium">{t("prod.worker")}</th>
                  <th className="text-right p-3 font-medium">{t("common.qty")}</th>
                  <th className="text-right p-3 font-medium">{t("prod.defectQty")}</th>
                  <th className="text-left p-3 font-medium">{t("common.date")}</th>
                </tr>
              </thead>
              <tbody>
                {todayReports.length === 0 ? (
                  <tr><td colSpan={6} className="p-6 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                ) : todayReports.map((r: any) => {
                  const worker = workers.find((w: any) => w.id === r.workerId);
                  return (
                    <tr key={r.id} className="border-b">
                      <td className="p-3"><Badge variant="secondary">{t(`prod.${r.station}`)}</Badge></td>
                      <td className="p-3 font-mono text-xs">{workOrders.find((wo: any) => wo.id === r.workOrderId)?.workOrderNo || r.workOrderId}</td>
                      <td className="p-3">{worker?.name || r.workerId}</td>
                      <td className="p-3 text-right font-medium">{r.qty}</td>
                      <td className="p-3 text-right text-destructive">{r.defectQty || 0}</td>
                      <td className="p-3 text-xs">{r.reportTime ? new Date(r.reportTime).toLocaleTimeString() : "-"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
