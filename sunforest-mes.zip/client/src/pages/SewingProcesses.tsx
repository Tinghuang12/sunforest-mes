import { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Edit2, Trash2 } from "lucide-react";
import { toast } from "sonner";

export default function SewingProcesses() {
  const { t, locale } = useI18n();
  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    nameVi: "",
    sortOrder: 0,
    status: "active" as const,
  });

  const { data: processes, isLoading, refetch } = trpc.sewingProcess.list.useQuery({ status: undefined });
  const createMutation = trpc.sewingProcess.create.useMutation({
    onSuccess: () => {
      toast.success(t("common.success"));
      setIsOpen(false);
      resetForm();
      refetch();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateMutation = trpc.sewingProcess.update.useMutation({
    onSuccess: () => {
      toast.success(t("common.success"));
      setIsOpen(false);
      resetForm();
      refetch();
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteMutation = trpc.sewingProcess.delete.useMutation({
    onSuccess: () => {
      toast.success(t("common.success"));
      refetch();
    },
    onError: (error) => toast.error(error.message),
  });

  const resetForm = () => {
    setFormData({
      code: "",
      name: "",
      nameVi: "",
      sortOrder: 0,
      status: "active",
    });
    setEditingId(null);
  };

  const handleEdit = (process: any) => {
    setEditingId(process.id);
    setFormData({
      code: process.code,
      name: process.name,
      nameVi: process.nameVi || "",
      sortOrder: process.sortOrder,
      status: process.status,
    });
    setIsOpen(true);
  };

  const handleSubmit = async () => {
    if (!formData.code || !formData.name) {
      toast.error(t("common.error"));
      return;
    }

    if (editingId) {
      updateMutation.mutate({
        id: editingId,
        ...formData,
      });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id: number) => {
    if (confirm(t("common.confirm"))) {
      deleteMutation.mutate({ id });
    }
  };

  // Helper: get display name based on locale
  const getDisplayName = (process: any) => {
    return locale === "vi" ? (process.nameVi || process.name) : process.name;
  };

  // Helper: get secondary name (the other language)
  const getSecondaryName = (process: any) => {
    return locale === "vi" ? process.name : (process.nameVi || "-");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">{t("sewing.title")}</h1>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2" onClick={() => resetForm()}>
              <Plus className="w-4 h-4" />
              {t("common.add")}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingId ? t("common.edit") : t("common.create")} {t("sewing.processes")}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">{t("sewing.code")}</label>
                <Input
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  placeholder="SP-001"
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("sewing.name")} ({locale === "vi" ? "中文" : "中文"}) *</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder={locale === "vi" ? "Tên tiếng Trung" : "中文名稱"}
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("sewing.name")} (Tiếng Việt)</label>
                <Input
                  value={formData.nameVi}
                  onChange={(e) => setFormData({ ...formData, nameVi: e.target.value })}
                  placeholder={locale === "vi" ? "Tên tiếng Việt" : "越南文名稱"}
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("sewing.sortOrder")}</label>
                <Input
                  value={formData.sortOrder}
                  onChange={(e) => setFormData({ ...formData, sortOrder: parseInt(e.target.value) || 0 })}
                  type="number"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("common.status")}</label>
                <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v as any })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">{t("common.active")}</SelectItem>
                    <SelectItem value="inactive">{t("common.inactive")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2 justify-end">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsOpen(false);
                    resetForm();
                  }}
                >
                  {t("common.cancel")}
                </Button>
                <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending}>
                  {t("common.save")}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Processes Table */}
      <Card>
        <CardHeader>
          <CardTitle>{t("sewing.processes")}</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">{t("common.loading")}</div>
          ) : processes && processes.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("sewing.code")}</TableHead>
                  <TableHead>{t("sewing.name")}</TableHead>
                  <TableHead>{locale === "vi" ? "中文" : "Tiếng Việt"}</TableHead>
                  <TableHead className="text-center">{t("sewing.sortOrder")}</TableHead>
                  <TableHead>{t("common.status")}</TableHead>
                  <TableHead className="text-right">{t("common.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {processes.map((process: any) => (
                  <TableRow key={process.id}>
                    <TableCell className="font-medium">{process.code}</TableCell>
                    <TableCell>{getDisplayName(process)}</TableCell>
                    <TableCell className="text-muted-foreground">{getSecondaryName(process)}</TableCell>
                    <TableCell className="text-center">{process.sortOrder}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        process.status === "active"
                          ? "bg-green-100 text-green-800"
                          : "bg-gray-100 text-gray-800"
                      }`}>
                        {process.status === "active" ? t("common.active") : t("common.inactive")}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex gap-2 justify-end">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(process)}
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(process.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-muted-foreground">{t("common.noData")}</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
