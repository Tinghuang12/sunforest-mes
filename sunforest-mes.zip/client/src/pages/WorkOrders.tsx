import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const statusColors: Record<string, string> = {
  pending: "bg-gray-100 text-gray-700",
  in_progress: "bg-amber-100 text-amber-700",
  completed: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

export default function WorkOrdersPage() {
  const { t, locale } = useI18n();
  const [statusFilter, setStatusFilter] = useState("all");
  const [showCreate, setShowCreate] = useState(false);
  const utils = trpc.useUtils();

  const { data: workOrders = [], isLoading } = trpc.workOrder.list.useQuery({
    status: statusFilter !== "all" ? statusFilter : undefined,
  });
  const { data: orders = [] } = trpc.order.list.useQuery();
  const { data: lines = [] } = trpc.line.list.useQuery();

  const createMutation = trpc.workOrder.create.useMutation({
    onSuccess: () => { utils.workOrder.list.invalidate(); setShowCreate(false); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const updateMutation = trpc.workOrder.update.useMutation({
    onSuccess: () => { utils.workOrder.list.invalidate(); toast.success(t("common.success")); },
  });

  const [form, setForm] = useState({ workOrderNo: "", orderId: 0, lineId: undefined as number | undefined, targetQty: 0, startDate: "", endDate: "", notes: "" });

  const orderMap = new Map(orders.map((o: any) => [o.id, o.orderNo]));
  const lineMap = new Map(lines.map((l: any) => [l.id, locale === 'vi' ? (l.nameVi || l.name) : l.name]));

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{t("wo.title")}</h1>
        <Button onClick={() => { setForm({ workOrderNo: "", orderId: 0, lineId: undefined, targetQty: 0, startDate: "", endDate: "", notes: "" }); setShowCreate(true); }} className="touch-target">
          <Plus className="h-4 w-4 mr-1" /> {t("wo.newWorkOrder")}
        </Button>
      </div>

      <Select value={statusFilter} onValueChange={setStatusFilter}>
        <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">{t("common.all")}</SelectItem>
          <SelectItem value="pending">{t("wo.pending")}</SelectItem>
          <SelectItem value="in_progress">{t("wo.in_progress")}</SelectItem>
          <SelectItem value="completed">{t("wo.completed")}</SelectItem>
          <SelectItem value="cancelled">{t("wo.cancelled")}</SelectItem>
        </SelectContent>
      </Select>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium">{t("wo.workOrderNo")}</th>
                  <th className="text-left p-3 font-medium">{t("order.orderNo")}</th>
                  <th className="text-left p-3 font-medium">{t("wo.line")}</th>
                  <th className="text-right p-3 font-medium">{t("wo.targetQty")}</th>
                  <th className="text-right p-3 font-medium">{t("wo.completedQty")}</th>
                  <th className="text-left p-3 font-medium w-32">{t("wo.progress")}</th>
                  <th className="text-left p-3 font-medium">{t("wo.startDate")}</th>
                  <th className="text-left p-3 font-medium">{t("wo.endDate")}</th>
                  <th className="text-left p-3 font-medium">{t("common.status")}</th>
                  <th className="text-left p-3 font-medium">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan={10} className="p-8 text-center text-muted-foreground">{t("common.loading")}</td></tr>
                ) : workOrders.length === 0 ? (
                  <tr><td colSpan={10} className="p-8 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                ) : workOrders.map((wo: any) => {
                  const progress = wo.targetQty > 0 ? Math.min(100, Math.round(((wo.completedQty || 0) / wo.targetQty) * 100)) : 0;
                  return (
                    <tr key={wo.id} className="border-b hover:bg-muted/30">
                      <td className="p-3 font-mono text-xs">{wo.workOrderNo}</td>
                      <td className="p-3 font-mono text-xs">{orderMap.get(wo.orderId) || wo.orderId}</td>
                      <td className="p-3">{lineMap.get(wo.lineId!) || "-"}</td>
                      <td className="p-3 text-right">{wo.targetQty?.toLocaleString()}</td>
                      <td className="p-3 text-right">{(wo.completedQty || 0).toLocaleString()}</td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <Progress value={progress} className="h-2 flex-1" />
                          <span className="text-xs text-muted-foreground w-8">{progress}%</span>
                        </div>
                      </td>
                      <td className="p-3 text-xs">{wo.startDate ? new Date(wo.startDate).toLocaleDateString() : "-"}</td>
                      <td className="p-3 text-xs">{wo.endDate ? new Date(wo.endDate).toLocaleDateString() : "-"}</td>
                      <td className="p-3"><Badge variant="secondary" className={statusColors[wo.status] || ""}>{t(`wo.${wo.status}`)}</Badge></td>
                      <td className="p-3">
                        <Select value={wo.status} onValueChange={(v) => updateMutation.mutate({ id: wo.id, status: v as any })}>
                          <SelectTrigger className="h-7 text-xs w-[90px]"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">{t("wo.pending")}</SelectItem>
                            <SelectItem value="in_progress">{t("wo.in_progress")}</SelectItem>
                            <SelectItem value="completed">{t("wo.completed")}</SelectItem>
                            <SelectItem value="cancelled">{t("wo.cancelled")}</SelectItem>
                          </SelectContent>
                        </Select>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{t("wo.newWorkOrder")}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div><Label>{t("wo.workOrderNo")} *</Label><Input value={form.workOrderNo} onChange={e => setForm(f => ({ ...f, workOrderNo: e.target.value }))} /></div>
            <div>
              <Label>{t("order.orderNo")} *</Label>
              <Select value={String(form.orderId || "")} onValueChange={v => setForm(f => ({ ...f, orderId: Number(v) }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{orders.map((o: any) => <SelectItem key={o.id} value={String(o.id)}>{o.orderNo}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t("wo.line")}</Label>
              <Select value={String(form.lineId || "")} onValueChange={v => setForm(f => ({ ...f, lineId: Number(v) }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{lines.map((l: any) => <SelectItem key={l.id} value={String(l.id)}>{locale === 'vi' ? (l.nameVi || l.name) : l.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>{t("wo.targetQty")}</Label><Input type="number" value={form.targetQty} onChange={e => setForm(f => ({ ...f, targetQty: Number(e.target.value) }))} /></div>
            <div><Label>{t("wo.startDate")}</Label><Input type="date" value={form.startDate} onChange={e => setForm(f => ({ ...f, startDate: e.target.value }))} /></div>
            <div><Label>{t("wo.endDate")}</Label><Input type="date" value={form.endDate} onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>{t("common.cancel")}</Button>
            <Button onClick={() => { if (!form.workOrderNo || !form.orderId) return; createMutation.mutate(form as any); }} disabled={createMutation.isPending}>{t("common.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
