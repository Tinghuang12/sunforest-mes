import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useState, useRef, useCallback } from "react";
import { Upload, Download, FileSpreadsheet, CheckCircle2, XCircle, AlertTriangle, Loader2, Trash2 } from "lucide-react";
import * as XLSX from "xlsx";

type ImportType = "workers" | "customers" | "materials" | "orders";

type ParsedRow = Record<string, any>;
type ValidationError = { row: number; field: string; message: string };

// Template column definitions for each import type
// Vietnamese is the primary language; Chinese name fields are optional
const templateColumns: Record<ImportType, { key: string; labelZh: string; labelVi: string; required: boolean; example: string }[]> = {
  workers: [
    { key: "employeeCode", labelZh: "員工編號", labelVi: "Mã nhân viên", required: true, example: "NV001" },
    { key: "nameVi", labelZh: "姓名(越南語)", labelVi: "Họ và tên", required: true, example: "Nguyễn Văn Minh" },
    { key: "name", labelZh: "姓名(中文)", labelVi: "Tên tiếng Trung", required: false, example: "阮文明" },
    { key: "phone", labelZh: "電話", labelVi: "Điện thoại", required: false, example: "0901234567" },
    { key: "workerRole", labelZh: "職位", labelVi: "Chức vụ", required: false, example: "Công nhân" },
    { key: "salaryType", labelZh: "薪資類型(hourly/monthly)", labelVi: "Loại lương (hourly/monthly)", required: false, example: "monthly" },
    { key: "monthlySalary", labelZh: "月薪", labelVi: "Lương tháng", required: false, example: "7000000" },
    { key: "hourlyRate", labelZh: "時薪", labelVi: "Lương giờ", required: false, example: "35000" },
    { key: "pieceRate", labelZh: "計件單價", labelVi: "Đơn giá khoán", required: false, example: "5000" },
    { key: "joinDate", labelZh: "入職日期(YYYY-MM-DD)", labelVi: "Ngày vào (YYYY-MM-DD)", required: false, example: "2024-01-15" },
  ],
  customers: [
    { key: "name", labelZh: "客戶名稱", labelVi: "Tên khách hàng", required: true, example: "ABC Fashion Co." },
    { key: "contactPerson", labelZh: "聯絡人", labelVi: "Người liên hệ", required: false, example: "John Smith" },
    { key: "phone", labelZh: "電話", labelVi: "Điện thoại", required: false, example: "+1-555-0123" },
    { key: "email", labelZh: "電子郵件", labelVi: "Email", required: false, example: "john@abc.com" },
    { key: "address", labelZh: "地址", labelVi: "Địa chỉ", required: false, example: "123 Fashion Ave, NY" },
  ],
  materials: [
    { key: "code", labelZh: "物料編號", labelVi: "Mã vật liệu", required: true, example: "FB-001" },
    { key: "nameVi", labelZh: "名稱(越南語)", labelVi: "Tên vật liệu", required: true, example: "Vải cotton" },
    { key: "name", labelZh: "名稱(中文)", labelVi: "Tên tiếng Trung", required: false, example: "棉布" },
    { key: "type", labelZh: "類型", labelVi: "Loại", required: false, example: "Vải" },
    { key: "unit", labelZh: "單位", labelVi: "Đơn vị", required: false, example: "m" },
    { key: "color", labelZh: "顏色", labelVi: "Màu sắc", required: false, example: "Trắng" },
    { key: "batchNo", labelZh: "批號", labelVi: "Số lô", required: false, example: "B2024-001" },
    { key: "currentStock", labelZh: "目前庫存", labelVi: "Tồn kho hiện tại", required: false, example: "1000" },
    { key: "safetyStock", labelZh: "安全庫存", labelVi: "Tồn kho an toàn", required: false, example: "200" },
    { key: "warehouseLocation", labelZh: "倉庫位置", labelVi: "Vị trí kho", required: false, example: "A-01-03" },
  ],
  orders: [
    { key: "orderNo", labelZh: "訂單編號", labelVi: "Mã đơn hàng", required: true, example: "PO-2024-001" },
    { key: "customerId", labelZh: "客戶ID", labelVi: "ID khách hàng", required: true, example: "1" },
    { key: "styleNo", labelZh: "款號", labelVi: "Mã kiểu", required: true, example: "ST-001" },
    { key: "styleName", labelZh: "款名", labelVi: "Tên kiểu", required: false, example: "Summer T-Shirt" },
    { key: "totalQty", labelZh: "總數量", labelVi: "Tổng số lượng", required: false, example: "5000" },
    { key: "deliveryDate", labelZh: "交期(YYYY-MM-DD)", labelVi: "Ngày giao (YYYY-MM-DD)", required: false, example: "2024-06-30" },
    { key: "notes", labelZh: "備註", labelVi: "Ghi chú", required: false, example: "" },
  ],
};

export default function ImportPage() {
  const { t, locale } = useI18n();
  const [importType, setImportType] = useState<ImportType>("workers");
  const [parsedData, setParsedData] = useState<ParsedRow[]>([]);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [isImporting, setIsImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ inserted: number; errors?: { row: number; message: string }[] } | null>(null);
  const [fileName, setFileName] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const importWorkers = trpc.import.workers.useMutation();
  const importCustomers = trpc.import.customers.useMutation();
  const importMaterials = trpc.import.materials.useMutation();
  const importOrders = trpc.import.orders.useMutation();

  const columns = templateColumns[importType];

  // Download template
  const handleDownloadTemplate = useCallback(() => {
    const cols = templateColumns[importType];
    const exampleRow: Record<string, string> = {};
    cols.forEach(col => {
      exampleRow[col.key] = col.example;
    });

    // Create workbook with header labels as first row and example as second
    const ws = XLSX.utils.json_to_sheet([exampleRow], {
      header: cols.map(c => c.key),
    });
    // Replace header with localized labels
    cols.forEach((col, i) => {
      const cellRef = XLSX.utils.encode_cell({ r: 0, c: i });
      const label = locale === "zh" ? col.labelZh : col.labelVi;
      ws[cellRef] = { v: label + (col.required ? " *" : ""), t: "s" };
    });
    // Set column widths
    ws["!cols"] = cols.map(col => ({ wch: Math.max(col.labelVi.length * 1.5, col.example.length, 14) }));

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Template");
    const typeLabels: Record<ImportType, string> = {
      workers: locale === "zh" ? "員工" : "NhanVien",
      customers: locale === "zh" ? "客戶" : "KhachHang",
      materials: locale === "zh" ? "物料" : "VatLieu",
      orders: locale === "zh" ? "訂單" : "DonHang",
    };
    XLSX.writeFile(wb, `${typeLabels[importType]}_Template.xlsx`);
    toast.success(t("import.templateDownloaded"));
  }, [importType, locale, t]);

  // Parse uploaded file
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setImportResult(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = evt.target?.result;
        let rows: ParsedRow[] = [];

        if (file.name.endsWith(".csv")) {
          const wb = XLSX.read(data, { type: "binary", codepage: 65001 });
          const ws = wb.Sheets[wb.SheetNames[0]];
          rows = XLSX.utils.sheet_to_json(ws, { defval: "" });
        } else {
          const wb = XLSX.read(data, { type: "array" });
          const ws = wb.Sheets[wb.SheetNames[0]];
          rows = XLSX.utils.sheet_to_json(ws, { defval: "" });
        }

        // Map localized headers back to field keys
        const cols = templateColumns[importType];
        const mappedRows = rows.map(row => {
          const mapped: ParsedRow = {};
          const rowKeys = Object.keys(row);
          cols.forEach(col => {
            // Try direct key match first
            if (row[col.key] !== undefined) {
              mapped[col.key] = row[col.key];
              return;
            }
            // Try localized label match (with or without *)
            const zhLabel = col.labelZh;
            const viLabel = col.labelVi;
            const zhLabelReq = col.labelZh + " *";
            const viLabelReq = col.labelVi + " *";
            for (const k of rowKeys) {
              const trimmed = k.trim();
              if (trimmed === zhLabel || trimmed === viLabel || trimmed === zhLabelReq || trimmed === viLabelReq) {
                mapped[col.key] = row[k];
                return;
              }
            }
          });
          return mapped;
        });

        // Validate - only check required fields, no enum validation for workerRole/type
        const errors: ValidationError[] = [];
        mappedRows.forEach((row, i) => {
          cols.forEach(col => {
            if (col.required && (!row[col.key] || String(row[col.key]).trim() === "")) {
              errors.push({
                row: i + 1,
                field: locale === "zh" ? col.labelZh : col.labelVi,
                message: locale === "zh" ? "必填欄位不可為空" : "Trường bắt buộc không được để trống",
              });
            }
          });
          // Type-specific validations (only for structured fields, not free-text)
          if (importType === "workers") {
            if (row.salaryType && !["hourly", "monthly"].includes(row.salaryType)) {
              errors.push({ row: i + 1, field: locale === "zh" ? "薪資類型" : "Loại lương", message: locale === "zh" ? "薪資類型必須是 hourly/monthly" : "Loại lương phải là hourly/monthly" });
            }
          }
          if (importType === "orders") {
            if (row.customerId && isNaN(Number(row.customerId))) {
              errors.push({ row: i + 1, field: locale === "zh" ? "客戶ID" : "ID khách hàng", message: locale === "zh" ? "客戶ID必須是數字" : "ID khách hàng phải là số" });
            }
          }
        });

        setParsedData(mappedRows);
        setValidationErrors(errors);

        if (errors.length > 0) {
          toast.warning(locale === "zh"
            ? `解析完成，發現 ${errors.length} 個驗證問題`
            : `Phân tích hoàn tất, phát hiện ${errors.length} lỗi xác thực`);
        } else {
          toast.success(locale === "zh"
            ? `成功解析 ${mappedRows.length} 筆資料`
            : `Phân tích thành công ${mappedRows.length} bản ghi`);
        }
      } catch (err) {
        toast.error(locale === "zh" ? "檔案解析失敗" : "Phân tích tệp thất bại");
        console.error(err);
      }
    };

    if (file.name.endsWith(".csv")) {
      reader.readAsBinaryString(file);
    } else {
      reader.readAsArrayBuffer(file);
    }
    // Reset file input
    if (fileInputRef.current) fileInputRef.current.value = "";
  }, [importType, locale]);

  // Execute import
  const handleImport = useCallback(async () => {
    if (parsedData.length === 0) return;
    if (validationErrors.length > 0) {
      toast.error(locale === "zh" ? "請先修正驗證錯誤" : "Vui lòng sửa lỗi xác thực trước");
      return;
    }

    setIsImporting(true);
    try {
      let result: any;
      switch (importType) {
        case "workers":
          result = await importWorkers.mutateAsync({
            rows: parsedData.map(r => ({
              employeeCode: String(r.employeeCode).trim(),
              name: r.name ? String(r.name).trim() : undefined,
              nameVi: r.nameVi ? String(r.nameVi).trim() : undefined,
              phone: r.phone ? String(r.phone).trim() : undefined,
              workerRole: r.workerRole ? String(r.workerRole).trim() : undefined,
              salaryType: r.salaryType || undefined,
              monthlySalary: r.monthlySalary ? String(r.monthlySalary) : undefined,
              hourlyRate: r.hourlyRate ? String(r.hourlyRate) : undefined,
              pieceRate: r.pieceRate ? String(r.pieceRate) : undefined,
              joinDate: r.joinDate ? String(r.joinDate) : undefined,
            })),
          });
          break;
        case "customers":
          result = await importCustomers.mutateAsync({
            rows: parsedData.map(r => ({
              name: String(r.name).trim(),
              contactPerson: r.contactPerson ? String(r.contactPerson).trim() : undefined,
              phone: r.phone ? String(r.phone).trim() : undefined,
              email: r.email ? String(r.email).trim() : undefined,
              address: r.address ? String(r.address).trim() : undefined,
            })),
          });
          break;
        case "materials":
          result = await importMaterials.mutateAsync({
            rows: parsedData.map(r => ({
              code: String(r.code).trim(),
              name: r.name ? String(r.name).trim() : undefined,
              nameVi: r.nameVi ? String(r.nameVi).trim() : undefined,
              type: r.type ? String(r.type).trim() : undefined,
              unit: r.unit ? String(r.unit).trim() : undefined,
              color: r.color ? String(r.color).trim() : undefined,
              batchNo: r.batchNo ? String(r.batchNo).trim() : undefined,
              currentStock: r.currentStock ? String(r.currentStock) : undefined,
              safetyStock: r.safetyStock ? String(r.safetyStock) : undefined,
              warehouseLocation: r.warehouseLocation ? String(r.warehouseLocation).trim() : undefined,
            })),
          });
          break;
        case "orders":
          result = await importOrders.mutateAsync({
            rows: parsedData.map(r => ({
              orderNo: String(r.orderNo).trim(),
              customerId: Number(r.customerId),
              styleNo: String(r.styleNo).trim(),
              styleName: r.styleName ? String(r.styleName).trim() : undefined,
              totalQty: r.totalQty ? Number(r.totalQty) : undefined,
              deliveryDate: r.deliveryDate ? String(r.deliveryDate) : undefined,
              notes: r.notes ? String(r.notes).trim() : undefined,
            })),
          });
          break;
      }

      setImportResult(result);
      if (result.errors && result.errors.length > 0) {
        toast.warning(locale === "zh"
          ? `匯入完成：成功 ${result.inserted} 筆，失敗 ${result.errors.length} 筆`
          : `Nhập hoàn tất: thành công ${result.inserted}, thất bại ${result.errors.length}`);
      } else {
        toast.success(locale === "zh"
          ? `成功匯入 ${result.inserted} 筆資料`
          : `Nhập thành công ${result.inserted} bản ghi`);
        setParsedData([]);
      }
    } catch (err: any) {
      toast.error(err.message || (locale === "zh" ? "匯入失敗" : "Nhập thất bại"));
    } finally {
      setIsImporting(false);
    }
  }, [parsedData, validationErrors, importType, locale, importWorkers, importCustomers, importMaterials, importOrders]);

  const handleClear = () => {
    setParsedData([]);
    setValidationErrors([]);
    setImportResult(null);
    setFileName("");
  };

  const typeOptions: { value: ImportType; labelZh: string; labelVi: string }[] = [
    { value: "workers", labelZh: "員工名冊", labelVi: "Danh sách nhân viên" },
    { value: "customers", labelZh: "客戶資料", labelVi: "Thông tin khách hàng" },
    { value: "materials", labelZh: "物料清單", labelVi: "Danh sách vật liệu" },
    { value: "orders", labelZh: "訂單資料", labelVi: "Thông tin đơn hàng" },
  ];

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold">{t("import.title")}</h1>
        <p className="text-muted-foreground mt-1">{t("import.subtitle")}</p>
      </div>

      {/* Step 1: Select Type & Download Template */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="flex items-center justify-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold">1</span>
            {t("import.step1")}
          </CardTitle>
          <CardDescription>{t("import.step1Desc")}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-end">
            <div className="w-full sm:w-64">
              <label className="text-sm font-medium mb-1 block">{t("import.dataType")}</label>
              <Select value={importType} onValueChange={(v) => { setImportType(v as ImportType); handleClear(); }}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {typeOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {locale === "zh" ? opt.labelZh : opt.labelVi}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button variant="outline" onClick={handleDownloadTemplate} className="gap-2">
              <Download className="w-4 h-4" />
              {t("import.downloadTemplate")}
            </Button>
          </div>

          {/* Column reference table */}
          <div className="border rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("import.fieldName")}</TableHead>
                  <TableHead>{t("import.required")}</TableHead>
                  <TableHead>{t("import.example")}</TableHead>
                  <TableHead>{locale === "zh" ? "說明" : "Ghi chú"}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {columns.map(col => {
                  // Add notes for free-text fields
                  let note = "";
                  if (importType === "workers" && col.key === "workerRole") {
                    note = locale === "zh" ? "自由輸入，任何語言" : "Nhập tự do, bất kỳ ngôn ngữ nào";
                  } else if (importType === "workers" && col.key === "name") {
                    note = locale === "zh" ? "選填，可留空" : "Tùy chọn, có thể để trống";
                  } else if (importType === "materials" && col.key === "type") {
                    note = locale === "zh" ? "自由輸入，如：Vải, Phụ kiện" : "Nhập tự do, ví dụ: Vải, Phụ kiện";
                  } else if (importType === "materials" && col.key === "name") {
                    note = locale === "zh" ? "選填，可留空" : "Tùy chọn, có thể để trống";
                  }
                  return (
                    <TableRow key={col.key}>
                      <TableCell className="font-medium">
                        {locale === "zh" ? col.labelZh : col.labelVi}
                      </TableCell>
                      <TableCell>
                        {col.required ? (
                          <Badge variant="destructive" className="text-xs">{t("import.requiredYes")}</Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs">{t("import.requiredNo")}</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">{col.example}</TableCell>
                      <TableCell className="text-muted-foreground text-xs italic">{note}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Step 2: Upload File */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="flex items-center justify-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold">2</span>
            {t("import.step2")}
          </CardTitle>
          <CardDescription>{t("import.step2Desc")}</CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className="border-2 border-dashed rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer"
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={handleFileUpload}
              className="hidden"
            />
            <Upload className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-sm font-medium">
              {fileName || (locale === "zh" ? "點擊或拖放檔案到此處" : "Nhấp hoặc kéo thả tệp vào đây")}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {locale === "zh" ? "支援 .xlsx, .xls, .csv 格式" : "Hỗ trợ định dạng .xlsx, .xls, .csv"}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Step 3: Preview & Import */}
      {parsedData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <span className="flex items-center justify-center w-7 h-7 rounded-full bg-primary text-primary-foreground text-sm font-bold">3</span>
              {t("import.step3")}
            </CardTitle>
            <CardDescription>
              {locale === "zh"
                ? `共 ${parsedData.length} 筆資料${validationErrors.length > 0 ? `，${validationErrors.length} 個驗證問題` : ""}`
                : `Tổng ${parsedData.length} bản ghi${validationErrors.length > 0 ? `, ${validationErrors.length} lỗi xác thực` : ""}`}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Validation errors */}
            {validationErrors.length > 0 && (
              <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 space-y-2">
                <div className="flex items-center gap-2 text-destructive font-medium">
                  <AlertTriangle className="w-4 h-4" />
                  {locale === "zh" ? "驗證錯誤" : "Lỗi xác thực"}
                </div>
                <div className="max-h-40 overflow-y-auto space-y-1">
                  {validationErrors.map((err, i) => (
                    <p key={i} className="text-sm text-destructive/80">
                      {locale === "zh" ? `第 ${err.row} 行` : `Hàng ${err.row}`} - {err.field}: {err.message}
                    </p>
                  ))}
                </div>
              </div>
            )}

            {/* Preview table */}
            <div className="border rounded-lg overflow-x-auto max-h-96">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    {columns.map(col => (
                      <TableHead key={col.key}>
                        {locale === "zh" ? col.labelZh : col.labelVi}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {parsedData.slice(0, 50).map((row, i) => {
                    const rowErrors = validationErrors.filter(e => e.row === i + 1);
                    return (
                      <TableRow key={i} className={rowErrors.length > 0 ? "bg-destructive/5" : ""}>
                        <TableCell className="text-muted-foreground">{i + 1}</TableCell>
                        {columns.map(col => (
                          <TableCell key={col.key} className="max-w-48 truncate">
                            {row[col.key] !== undefined && row[col.key] !== "" ? String(row[col.key]) : (
                              <span className="text-muted-foreground/50">-</span>
                            )}
                          </TableCell>
                        ))}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              {parsedData.length > 50 && (
                <div className="p-3 text-center text-sm text-muted-foreground border-t">
                  {locale === "zh"
                    ? `僅顯示前 50 筆，共 ${parsedData.length} 筆`
                    : `Chỉ hiển thị 50 đầu tiên, tổng ${parsedData.length}`}
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={handleClear} className="gap-2">
                <Trash2 className="w-4 h-4" />
                {t("import.clear")}
              </Button>
              <Button
                onClick={handleImport}
                disabled={isImporting || validationErrors.length > 0}
                className="gap-2 min-w-32"
              >
                {isImporting ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <FileSpreadsheet className="w-4 h-4" />
                )}
                {isImporting
                  ? (locale === "zh" ? "匯入中..." : "Đang nhập...")
                  : t("import.startImport")}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Import Result */}
      {importResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {importResult.errors && importResult.errors.length > 0 ? (
                <AlertTriangle className="w-5 h-5 text-yellow-500" />
              ) : (
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              )}
              {t("import.result")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              <span>
                {locale === "zh"
                  ? `成功匯入 ${importResult.inserted} 筆`
                  : `Nhập thành công ${importResult.inserted} bản ghi`}
              </span>
            </div>
            {importResult.errors && importResult.errors.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-destructive">
                  <XCircle className="w-4 h-4" />
                  <span>
                    {locale === "zh"
                      ? `失敗 ${importResult.errors.length} 筆`
                      : `Thất bại ${importResult.errors.length} bản ghi`}
                  </span>
                </div>
                <div className="bg-destructive/10 rounded-lg p-3 max-h-40 overflow-y-auto space-y-1">
                  {importResult.errors.map((err, i) => (
                    <p key={i} className="text-sm text-destructive/80">
                      {locale === "zh" ? `第 ${err.row} 行` : `Hàng ${err.row}`}: {err.message}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
