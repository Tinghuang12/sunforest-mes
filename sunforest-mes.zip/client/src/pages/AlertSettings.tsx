import { useState, useEffect } from "react";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Settings2, Package, Truck, AlertTriangle, ShieldAlert, Save,
} from "lucide-react";
import { toast } from "sonner";

type AlertSettingRow = {
  id: number;
  alertType: string;
  enabled: string;
  thresholdValue: string | null;
  thresholdValue2: string | null;
  description: string | null;
  createdAt: Date;
  updatedAt: Date;
};

const alertTypeConfig: Record<string, { icon: any; color: string; descKey: string; unit: string; hasThreshold2: boolean }> = {
  low_stock: {
    icon: Package,
    color: "text-purple-600 dark:text-purple-400",
    descKey: "alert.setting.lowStock.desc",
    unit: "",
    hasThreshold2: false,
  },
  delivery_approaching: {
    icon: Truck,
    color: "text-orange-600 dark:text-orange-400",
    descKey: "alert.setting.delivery.desc",
    unit: "alert.setting.days",
    hasThreshold2: true,
  },
  delivery_overdue: {
    icon: AlertTriangle,
    color: "text-red-600 dark:text-red-400",
    descKey: "alert.setting.deliveryOverdue.desc",
    unit: "alert.setting.days",
    hasThreshold2: false,
  },
  high_defect_rate: {
    icon: ShieldAlert,
    color: "text-pink-600 dark:text-pink-400",
    descKey: "alert.setting.defectRate.desc",
    unit: "alert.setting.percent",
    hasThreshold2: true,
  },
};

export default function AlertSettings() {
  const { t } = useI18n();
  const { data: settings, isLoading, refetch } = trpc.alert.getSettings.useQuery();
  const [editState, setEditState] = useState<Record<number, {
    enabled: boolean;
    thresholdValue: string;
    thresholdValue2: string;
  }>>({});
  const [saving, setSaving] = useState<number | null>(null);

  const updateMutation = trpc.alert.updateSetting.useMutation({
    onSuccess: () => {
      toast.success(t("common.success"));
      refetch();
      setSaving(null);
    },
    onError: (err) => {
      toast.error(err.message);
      setSaving(null);
    },
  });

  // Initialize edit state from server data
  useEffect(() => {
    if (settings && settings.length > 0) {
      const state: Record<number, { enabled: boolean; thresholdValue: string; thresholdValue2: string }> = {};
      for (const s of settings as AlertSettingRow[]) {
        state[s.id] = {
          enabled: s.enabled === "yes",
          thresholdValue: s.thresholdValue || "0",
          thresholdValue2: s.thresholdValue2 || "",
        };
      }
      setEditState(state);
    }
  }, [settings]);

  const handleSave = (setting: AlertSettingRow) => {
    const edit = editState[setting.id];
    if (!edit) return;
    setSaving(setting.id);
    updateMutation.mutate({
      id: setting.id,
      enabled: edit.enabled ? "yes" : "no",
      thresholdValue: edit.thresholdValue,
      thresholdValue2: edit.thresholdValue2 || undefined,
    });
  };

  const updateField = (id: number, field: string, value: any) => {
    setEditState((prev) => ({
      ...prev,
      [id]: { ...prev[id], [field]: value },
    }));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Settings2 className="h-7 w-7 text-primary" />
        <div>
          <h1 className="text-2xl font-bold">{t("alert.settings")}</h1>
          <p className="text-sm text-muted-foreground">{t("alert.setting.lowStock.desc")}</p>
        </div>
      </div>

      {/* Settings Cards */}
      <div className="grid gap-6">
        {(settings as AlertSettingRow[] || []).map((setting) => {
          const config = alertTypeConfig[setting.alertType];
          if (!config) return null;
          const edit = editState[setting.id];
          if (!edit) return null;
          const IconComponent = config.icon;

          return (
            <Card key={setting.id} className={`transition-all ${!edit.enabled ? "opacity-60" : ""}`}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg bg-muted ${config.color}`}>
                      <IconComponent className="h-5 w-5" />
                    </div>
                    <div>
                      <CardTitle className="text-base">
                        {t(`alert.type.${setting.alertType}`)}
                      </CardTitle>
                      <CardDescription className="text-sm">
                        {t(config.descKey)}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Label htmlFor={`switch-${setting.id}`} className="text-sm">
                      {edit.enabled ? t("alert.setting.enabled") : t("alert.setting.disabled")}
                    </Label>
                    <Switch
                      id={`switch-${setting.id}`}
                      checked={edit.enabled}
                      onCheckedChange={(checked) => updateField(setting.id, "enabled", checked)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-4 items-end">
                  {/* Threshold Value */}
                  {setting.alertType !== "delivery_overdue" && (
                    <div className="flex-1 min-w-[200px]">
                      <Label className="text-sm mb-1.5 block">
                        {t("alert.setting.threshold")}
                        {config.unit && ` (${t(config.unit)})`}
                      </Label>
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        value={edit.thresholdValue}
                        onChange={(e) => updateField(setting.id, "thresholdValue", e.target.value)}
                        disabled={!edit.enabled}
                        className="max-w-[200px]"
                      />
                    </div>
                  )}

                  {/* Threshold Value 2 (secondary) */}
                  {config.hasThreshold2 && (
                    <div className="flex-1 min-w-[200px]">
                      <Label className="text-sm mb-1.5 block">
                        {t("alert.setting.threshold2")}
                        {config.unit && ` (${t(config.unit)})`}
                      </Label>
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        value={edit.thresholdValue2}
                        onChange={(e) => updateField(setting.id, "thresholdValue2", e.target.value)}
                        disabled={!edit.enabled}
                        className="max-w-[200px]"
                      />
                    </div>
                  )}

                  {/* Save Button */}
                  <Button
                    onClick={() => handleSave(setting)}
                    disabled={saving === setting.id}
                    size="sm"
                  >
                    <Save className="h-4 w-4 mr-1" />
                    {saving === setting.id ? "..." : t("common.save")}
                  </Button>
                </div>

                {/* Explanation */}
                {setting.description && (
                  <p className="text-xs text-muted-foreground mt-3 italic">
                    {setting.description}
                  </p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Empty state if no settings */}
      {(!settings || settings.length === 0) && (
        <Card>
          <CardContent className="p-12 text-center">
            <Settings2 className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-lg font-medium text-muted-foreground">
              {t("alert.noAlerts")}
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              Alert settings will be automatically created when the system initializes.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
