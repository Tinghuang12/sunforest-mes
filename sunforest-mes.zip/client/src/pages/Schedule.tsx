import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState, useMemo } from "react";

const statusColors: Record<string, string> = {
  pending: "bg-gray-200 text-gray-700 border-gray-300",
  in_progress: "bg-amber-200 text-amber-800 border-amber-300",
  completed: "bg-green-200 text-green-800 border-green-300",
  cancelled: "bg-red-200 text-red-700 border-red-300",
};

export default function SchedulePage() {
  const { t, locale } = useI18n();
  const [currentDate, setCurrentDate] = useState(() => new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const startDate = new Date(year, month, 1 - firstDay.getDay());
  const endDate = new Date(year, month + 1, 6 - lastDay.getDay());

  const { data: workOrders = [] } = trpc.workOrder.list.useQuery();
  const { data: lines = [] } = trpc.line.list.useQuery();
  const { data: orders = [] } = trpc.order.list.useQuery();

  const lineMap = new Map(lines.map((l: any) => [l.id, locale === 'vi' ? (l.nameVi || l.name) : l.name]));
  const orderMap = new Map(orders.map((o: any) => [o.id, o.styleNo]));

  const calendarDays = useMemo(() => {
    const days: Date[] = [];
    const d = new Date(startDate);
    while (d <= endDate) {
      days.push(new Date(d));
      d.setDate(d.getDate() + 1);
    }
    return days;
  }, [year, month]);

  const getWOsForDate = (date: Date) => {
    const dateStr = date.toISOString().split("T")[0];
    return workOrders.filter((wo: any) => {
      const start = wo.startDate ? new Date(wo.startDate).toISOString().split("T")[0] : null;
      const end = wo.endDate ? new Date(wo.endDate).toISOString().split("T")[0] : null;
      if (!start) return false;
      if (end) return dateStr >= start && dateStr <= end;
      return dateStr === start;
    });
  };

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));
  const goToday = () => setCurrentDate(new Date());

  const monthNames = locale === "vi"
    ? ["Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6", "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"]
    : ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"];

  const dayNames = locale === "vi"
    ? ["CN", "T2", "T3", "T4", "T5", "T6", "T7"]
    : ["日", "一", "二", "三", "四", "五", "六"];

  const today = new Date().toISOString().split("T")[0];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("nav.schedule")}</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={prevMonth}><ChevronLeft className="h-4 w-4" /></Button>
          <Button variant="outline" size="sm" onClick={goToday}>{t("common.today")}</Button>
          <span className="font-semibold text-lg min-w-[140px] text-center">{monthNames[month]} {year}</span>
          <Button variant="outline" size="icon" onClick={nextMonth}><ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-2">
          <div className="grid grid-cols-7 gap-px bg-border rounded-lg overflow-hidden">
            {dayNames.map(d => (
              <div key={d} className="bg-muted/50 p-2 text-center text-xs font-medium text-muted-foreground">{d}</div>
            ))}
            {calendarDays.map((day, i) => {
              const dateStr = day.toISOString().split("T")[0];
              const isCurrentMonth = day.getMonth() === month;
              const isToday = dateStr === today;
              const wos = getWOsForDate(day);
              return (
                <div key={i} className={`bg-background min-h-[100px] p-1 ${!isCurrentMonth ? "opacity-40" : ""} ${isToday ? "ring-2 ring-primary ring-inset" : ""}`}>
                  <div className={`text-xs font-medium mb-1 px-1 ${isToday ? "text-primary" : ""}`}>{day.getDate()}</div>
                  <div className="space-y-0.5">
                    {wos.slice(0, 3).map((wo: any) => (
                      <div key={wo.id} className={`text-[10px] px-1 py-0.5 rounded border truncate ${statusColors[wo.status] || "bg-gray-100"}`}>
                        {lineMap.get(wo.lineId!) || ""} {orderMap.get(wo.orderId) || wo.workOrderNo}
                      </div>
                    ))}
                    {wos.length > 3 && <div className="text-[10px] text-muted-foreground px-1">+{wos.length - 3}</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
