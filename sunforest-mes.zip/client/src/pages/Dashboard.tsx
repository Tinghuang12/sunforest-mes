import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, ClipboardList, Clock, Factory, Truck, Package } from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

const COLORS = ["#0d9488", "#0891b2", "#6366f1", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#10b981"];

export default function Dashboard() {
  const { t } = useI18n();
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();

  const today = useMemo(() => new Date().toISOString().split("T")[0], []);
  const [weekStart] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return d.toISOString().split("T")[0];
  });

  const { data: dailyProd } = trpc.dashboard.dailyProduction.useQuery({ startDate: weekStart, endDate: today });
  const { data: defectStats } = trpc.dashboard.defectRate.useQuery({ startDate: weekStart, endDate: today });

  const [, navigate] = useLocation();

  const statCards = [
    { icon: Users, label: t("dashboard.totalWorkers"), value: stats?.totalWorkers ?? 0, color: "text-blue-600", href: "/workers" },
    { icon: ClipboardList, label: t("dashboard.activeOrders"), value: stats?.activeOrders ?? 0, color: "text-teal-600", href: "/orders" },
    { icon: Clock, label: t("dashboard.todayAttendance"), value: stats?.todayAttendance ?? 0, color: "text-green-600", href: "/attendance" },
    { icon: Factory, label: t("dashboard.todayProduction"), value: stats?.todayProduction ?? 0, color: "text-indigo-600", href: "/reports" },
    { icon: Package, label: t("dashboard.totalOrders"), value: stats?.totalOrders ?? 0, color: "text-amber-600", href: "/orders" },
    { icon: Truck, label: t("dashboard.pendingShipments"), value: stats?.pendingShipments ?? 0, color: "text-rose-600", href: "/shipments" },
  ];

  const stationMap: Record<string, string> = {
    cutting: t("prod.cutting"),
    sewing: t("prod.sewing"),
    ironing: t("prod.ironing"),
    packing: t("prod.packing"),
  };

  const chartData = useMemo(() => {
    if (!dailyProd) return [];
    const dateMap = new Map<string, Record<string, number>>();
    dailyProd.forEach((row: any) => {
      const dateStr = row.reportDate instanceof Date
        ? row.reportDate.toISOString().split("T")[0]
        : String(row.reportDate);
      if (!dateMap.has(dateStr)) dateMap.set(dateStr, {});
      dateMap.get(dateStr)![row.station] = Number(row.totalQty) || 0;
    });
    return Array.from(dateMap.entries()).map(([date, stations]) => ({
      date: date.slice(5),
      ...stations,
    }));
  }, [dailyProd]);

  const defectChartData = useMemo(() => {
    if (!defectStats) return [];
    return defectStats.map((row: any) => ({
      name: t(`qc.${row.defectType}`) || row.defectType,
      value: Number(row.totalQty) || 0,
    }));
  }, [defectStats, t]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">{t("dashboard.title")}</h1>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="stat-card animate-pulse"><div className="h-16 bg-muted rounded" /></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">{t("dashboard.title")}</h1>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {statCards.map((card, i) => (
          <Card
            key={i}
            className="border shadow-sm cursor-pointer transition-all hover:shadow-md hover:scale-[1.02] active:scale-[0.98]"
            onClick={() => navigate(card.href)}
          >
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg bg-muted ${card.color}`}>
                  <card.icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{card.value}</p>
                  <p className="text-xs text-muted-foreground">{card.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t("dashboard.productionTrend")}</CardTitle>
          </CardHeader>
          <CardContent>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="date" fontSize={12} />
                  <YAxis fontSize={12} />
                  <Tooltip />
                  <Bar dataKey="cutting" name={stationMap.cutting} fill={COLORS[0]} radius={[2, 2, 0, 0]} />
                  <Bar dataKey="sewing" name={stationMap.sewing} fill={COLORS[1]} radius={[2, 2, 0, 0]} />
                  <Bar dataKey="ironing" name={stationMap.ironing} fill={COLORS[2]} radius={[2, 2, 0, 0]} />
                  <Bar dataKey="packing" name={stationMap.packing} fill={COLORS[3]} radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">{t("common.noData")}</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">{t("dashboard.defectRate")}</CardTitle>
          </CardHeader>
          <CardContent>
            {defectChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie data={defectChartData} cx="50%" cy="50%" outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} fontSize={11}>
                    {defectChartData.map((_: any, i: number) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[280px] flex items-center justify-center text-muted-foreground text-sm">{t("common.noData")}</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
