import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Clock, LogIn, LogOut, Search } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

const statusColors: Record<string, string> = {
  present: "bg-green-100 text-green-700",
  absent: "bg-red-100 text-red-700",
  late: "bg-amber-100 text-amber-700",
  half_day: "bg-blue-100 text-blue-700",
  leave: "bg-purple-100 text-purple-700",
};

export default function AttendancePage() {
  const { t } = useI18n();
  const [search, setSearch] = useState("");
  const [dateFilter, setDateFilter] = useState(() => new Date().toISOString().split("T")[0]);
  const utils = trpc.useUtils();

  const { data: workers = [] } = trpc.worker.list.useQuery({ status: "active" });
  const { data: attendance = [], isLoading } = trpc.attendance.list.useQuery({
    startDate: dateFilter,
    endDate: dateFilter,
  });

  const checkInMutation = trpc.attendance.checkIn.useMutation({
    onSuccess: (data) => {
      utils.attendance.list.invalidate();
      if (data && 'message' in data && data.message === "already_checked_in") {
        toast.info(t("att.checkIn") + " - already");
      } else {
        toast.success(t("common.success"));
      }
    },
    onError: () => toast.error(t("common.error")),
  });

  const checkOutMutation = trpc.attendance.checkOut.useMutation({
    onSuccess: () => { utils.attendance.list.invalidate(); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const attendanceMap = useMemo(() => {
    const map = new Map<number, any>();
    attendance.forEach((a: any) => map.set(a.workerId, a));
    return map;
  }, [attendance]);

  const filteredWorkers = workers.filter((w: any) =>
    !search || w.name.toLowerCase().includes(search.toLowerCase()) || w.employeeCode.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{t("att.title")}</h1>
        <div className="flex items-center gap-2">
          <Input type="date" value={dateFilter} onChange={e => setDateFilter(e.target.value)} className="w-[160px]" />
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {(["present", "absent", "late", "half_day", "leave"] as const).map(status => {
          const count = attendance.filter((a: any) => a.status === status).length;
          return (
            <Card key={status}>
              <CardContent className="p-3 text-center">
                <p className="text-2xl font-bold">{count}</p>
                <Badge variant="secondary" className={statusColors[status]}>{t(`att.${status}`)}</Badge>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder={t("common.search")} value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium">{t("worker.code")}</th>
                  <th className="text-left p-3 font-medium">{t("worker.name")}</th>
                  <th className="text-left p-3 font-medium">{t("common.status")}</th>
                  <th className="text-left p-3 font-medium">{t("att.checkIn")}</th>
                  <th className="text-left p-3 font-medium">{t("att.checkOut")}</th>
                  <th className="text-left p-3 font-medium">{t("att.overtimeHours")}</th>
                  <th className="text-left p-3 font-medium">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">{t("common.loading")}</td></tr>
                ) : filteredWorkers.length === 0 ? (
                  <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                ) : filteredWorkers.map((w: any) => {
                  const att = attendanceMap.get(w.id);
                  return (
                    <tr key={w.id} className="border-b hover:bg-muted/30">
                      <td className="p-3 font-mono text-xs">{w.employeeCode}</td>
                      <td className="p-3">{w.name}</td>
                      <td className="p-3">
                        {att ? (
                          <Badge variant="secondary" className={statusColors[att.status] || ""}>{t(`att.${att.status}`)}</Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">-</span>
                        )}
                      </td>
                      <td className="p-3 text-xs">{att?.checkIn ? new Date(att.checkIn).toLocaleTimeString() : "-"}</td>
                      <td className="p-3 text-xs">{att?.checkOut ? new Date(att.checkOut).toLocaleTimeString() : "-"}</td>
                      <td className="p-3 text-xs">{att?.overtimeHours || "-"}</td>
                      <td className="p-3">
                        <div className="flex gap-1">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 touch-target"
                            onClick={() => checkInMutation.mutate({ workerId: w.id, date: dateFilter })}
                            disabled={!!att?.checkIn}
                          >
                            <LogIn className="h-3.5 w-3.5 mr-1" /> {t("att.checkIn")}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 touch-target"
                            onClick={() => checkOutMutation.mutate({ workerId: w.id, date: dateFilter })}
                            disabled={!att?.checkIn || !!att?.checkOut}
                          >
                            <LogOut className="h-3.5 w-3.5 mr-1" /> {t("att.checkOut")}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
