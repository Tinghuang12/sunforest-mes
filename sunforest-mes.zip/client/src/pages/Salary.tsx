import { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Download, Loader2 } from "lucide-react";
import * as XLSX from "xlsx";

export default function SalaryPage() {
  const { t } = useI18n();
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [workerId, setWorkerId] = useState<number | undefined>();

  // Fetch salary data
  const { data: salaries = [], isLoading } = trpc.salary.calculateMonthly.useQuery({
    year,
    month,
    workerId,
  });

  // Fetch workers for dropdown
  const { data: workers = [] } = trpc.worker.list.useQuery();

  const handleExportExcel = () => {
    if (!salaries.length) return;

    const data = salaries.map((salary) => ({
      [t("worker.code")]: salary.workerCode,
      [t("worker.name")]: salary.workerName,
      [t("worker.salaryType")]: salary.salaryType === "hourly" ? t("worker.hourly") : salary.salaryType === "monthly" ? t("worker.monthly") : "計件",
      [t("prod.qty")]: salary.totalQty,
      [t("worker.hourlyRate")]: salary.hourlyRate,
      [t("worker.monthlySalary")]: salary.monthlySalary,
      [t("worker.pieceRate")]: salary.pieceRate,
      "Gross Salary": salary.grossSalary.toFixed(2),
      [t("attendance.present")]: salary.workingDays,
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `Salary_${year}_${month}`);
    XLSX.writeFile(wb, `Salary_${year}_${String(month).padStart(2, "0")}.xlsx`);
  };

  const months = Array.from({ length: 12 }, (_, i) => i + 1);
  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">{t("worker.title")} - Salary</h1>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>查詢條件</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium">年份</label>
              <Select value={String(year)} onValueChange={(v) => setYear(parseInt(v))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((y) => (
                    <SelectItem key={y} value={String(y)}>
                      {y}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium">月份</label>
              <Select value={String(month)} onValueChange={(v) => setMonth(parseInt(v))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {months.map((m) => (
                    <SelectItem key={m} value={String(m)}>
                      {String(m).padStart(2, "0")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium">{t("worker.name")}</label>
              <Select value={workerId ? String(workerId) : "all"} onValueChange={(v) => setWorkerId(v === "all" ? undefined : parseInt(v))}>
                <SelectTrigger>
                  <SelectValue placeholder="全部員工" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部員工</SelectItem>
                  {workers.map((w) => (
                    <SelectItem key={w.id} value={String(w.id)}>
                      {w.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button onClick={handleExportExcel} disabled={!salaries.length} className="w-full">
                <Download className="w-4 h-4 mr-2" />
                匯出 Excel
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Salary Table */}
      <Card>
        <CardHeader>
          <CardTitle>
            {year} 年 {String(month).padStart(2, "0")} 月薪資統計
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin" />
            </div>
          ) : salaries.length === 0 ? (
            <div className="text-center py-8 text-gray-500">沒有薪資資料</div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("worker.code")}</TableHead>
                    <TableHead>{t("worker.name")}</TableHead>
                    <TableHead>{t("worker.salaryType")}</TableHead>
                    <TableHead className="text-right">{t("prod.qty")}</TableHead>
                    <TableHead className="text-right">{t("worker.hourlyRate")}</TableHead>
                    <TableHead className="text-right">{t("worker.monthlySalary")}</TableHead>
                    <TableHead className="text-right">{t("worker.pieceRate")}</TableHead>
                    <TableHead className="text-right">總薪資</TableHead>
                    <TableHead className="text-right">{t("attendance.present")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {salaries.map((salary) => (
                    <TableRow key={salary.workerId}>
                      <TableCell>{salary.workerCode}</TableCell>
                      <TableCell>{salary.workerName}</TableCell>
                      <TableCell>
                        {salary.salaryType === "hourly"
                          ? t("worker.hourly")
                          : salary.salaryType === "monthly"
                            ? t("worker.monthly")
                            : "計件"}
                      </TableCell>
                      <TableCell className="text-right">{salary.totalQty}</TableCell>
                      <TableCell className="text-right">${salary.hourlyRate.toFixed(2)}</TableCell>
                      <TableCell className="text-right">${salary.monthlySalary.toFixed(2)}</TableCell>
                      <TableCell className="text-right">${salary.pieceRate.toFixed(2)}</TableCell>
                      <TableCell className="text-right font-semibold">${salary.grossSalary.toFixed(2)}</TableCell>
                      <TableCell className="text-right">{salary.workingDays}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

              {/* Summary */}
              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">員工總數</p>
                    <p className="text-2xl font-bold">{salaries.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">總薪資</p>
                    <p className="text-2xl font-bold">
                      ${salaries.reduce((sum, s) => sum + s.grossSalary, 0).toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">平均薪資</p>
                    <p className="text-2xl font-bold">
                      ${(salaries.reduce((sum, s) => sum + s.grossSalary, 0) / salaries.length).toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">最高薪資</p>
                    <p className="text-2xl font-bold">
                      ${Math.max(...salaries.map((s) => s.grossSalary)).toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
