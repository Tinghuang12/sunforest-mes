import { useState, useMemo } from "react";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Bell, BellOff, CheckCircle2, AlertTriangle, AlertCircle, Info,
  RefreshCw, Eye, CheckCheck, Filter,
} from "lucide-react";
import { toast } from "sonner";

type AlertType = "low_stock" | "delivery_approaching" | "delivery_overdue" | "high_defect_rate";
type Severity = "info" | "warning" | "critical";

function SeverityIcon({ severity }: { severity: Severity }) {
  switch (severity) {
    case "critical":
      return <AlertCircle className="h-5 w-5 text-red-500" />;
    case "warning":
      return <AlertTriangle className="h-5 w-5 text-amber-500" />;
    default:
      return <Info className="h-5 w-5 text-blue-500" />;
  }
}

function SeverityBadge({ severity, t }: { severity: Severity; t: (k: string) => string }) {
  const colorMap: Record<Severity, string> = {
    critical: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
    warning: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
    info: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${colorMap[severity]}`}>
      {t(`alert.severity.${severity}`)}
    </span>
  );
}

function TypeBadge({ alertType, t }: { alertType: AlertType; t: (k: string) => string }) {
  const colorMap: Record<AlertType, string> = {
    low_stock: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
    delivery_approaching: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
    delivery_overdue: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
    high_defect_rate: "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-400",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${colorMap[alertType]}`}>
      {t(`alert.type.${alertType}`)}
    </span>
  );
}

export default function Alerts() {
  const { t } = useI18n();
  const [filterType, setFilterType] = useState<string>("all");
  const [filterRead, setFilterRead] = useState<string>("all");
  const [filterResolved, setFilterResolved] = useState<string>("all");

  const queryInput = useMemo(() => {
    const input: { isRead?: string; alertType?: string } = {};
    if (filterRead === "yes" || filterRead === "no") input.isRead = filterRead;
    if (filterType !== "all") input.alertType = filterType;
    return input;
  }, [filterType, filterRead]);

  const { data: alertsList, isLoading, refetch } = trpc.alert.list.useQuery(queryInput);
  const { data: unreadCount, refetch: refetchCount } = trpc.alert.unreadCount.useQuery();

  const markReadMutation = trpc.alert.markRead.useMutation({
    onSuccess: () => {
      refetch();
      refetchCount();
    },
  });

  const markAllReadMutation = trpc.alert.markAllRead.useMutation({
    onSuccess: () => {
      toast.success(t("alert.markAllRead"));
      refetch();
      refetchCount();
    },
  });

  const resolveMutation = trpc.alert.resolve.useMutation({
    onSuccess: () => {
      toast.success(t("alert.resolve"));
      refetch();
    },
  });

  const runChecksMutation = trpc.alert.runChecks.useMutation({
    onSuccess: () => {
      toast.success(t("alert.checkComplete"));
      refetch();
      refetchCount();
    },
    onError: (err) => toast.error(err.message),
  });

  // Filter by resolved status client-side
  const filteredAlerts = useMemo(() => {
    if (!alertsList) return [];
    if (filterResolved === "all") return alertsList;
    return alertsList.filter((a: any) =>
      filterResolved === "yes" ? a.isResolved === "yes" : a.isResolved === "no"
    );
  }, [alertsList, filterResolved]);

  // Summary counts
  const summary = useMemo(() => {
    if (!alertsList) return { total: 0, unread: 0, critical: 0, warning: 0 };
    return {
      total: alertsList.length,
      unread: alertsList.filter((a: any) => a.isRead === "no").length,
      critical: alertsList.filter((a: any) => a.severity === "critical").length,
      warning: alertsList.filter((a: any) => a.severity === "warning").length,
    };
  }, [alertsList]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Bell className="h-7 w-7 text-primary" />
          <div>
            <h1 className="text-2xl font-bold">{t("alert.title")}</h1>
            {unreadCount !== undefined && unreadCount > 0 && (
              <p className="text-sm text-muted-foreground">
                {unreadCount} {t("alert.newAlerts")}
              </p>
            )}
          </div>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => runChecksMutation.mutate()}
            disabled={runChecksMutation.isPending}
          >
            <RefreshCw className={`h-4 w-4 mr-1 ${runChecksMutation.isPending ? "animate-spin" : ""}`} />
            {runChecksMutation.isPending ? t("alert.running") : t("alert.runChecks")}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => markAllReadMutation.mutate()}
            disabled={markAllReadMutation.isPending || !unreadCount}
          >
            <CheckCheck className="h-4 w-4 mr-1" />
            {t("alert.markAllRead")}
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/30">
              <Bell className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("alert.all")}</p>
              <p className="text-2xl font-bold">{summary.total}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-100 dark:bg-amber-900/30">
              <BellOff className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("alert.unread")}</p>
              <p className="text-2xl font-bold">{summary.unread}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-red-100 dark:bg-red-900/30">
              <AlertCircle className="h-5 w-5 text-red-600 dark:text-red-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("alert.severity.critical")}</p>
              <p className="text-2xl font-bold">{summary.critical}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-100 dark:bg-amber-900/30">
              <AlertTriangle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("alert.severity.warning")}</p>
              <p className="text-2xl font-bold">{summary.warning}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("alert.all")}</SelectItem>
                <SelectItem value="low_stock">{t("alert.type.low_stock")}</SelectItem>
                <SelectItem value="delivery_approaching">{t("alert.type.delivery_approaching")}</SelectItem>
                <SelectItem value="delivery_overdue">{t("alert.type.delivery_overdue")}</SelectItem>
                <SelectItem value="high_defect_rate">{t("alert.type.high_defect_rate")}</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterRead} onValueChange={setFilterRead}>
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("alert.all")}</SelectItem>
                <SelectItem value="no">{t("alert.unread")}</SelectItem>
                <SelectItem value="yes">{t("alert.read")}</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterResolved} onValueChange={setFilterResolved}>
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("alert.all")}</SelectItem>
                <SelectItem value="no">{t("alert.unresolved")}</SelectItem>
                <SelectItem value="yes">{t("alert.resolved")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Alerts List */}
      <div className="space-y-3">
        {isLoading ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              <RefreshCw className="h-6 w-6 animate-spin mx-auto mb-2" />
              Loading...
            </CardContent>
          </Card>
        ) : filteredAlerts.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto mb-3" />
              <p className="text-lg font-medium text-muted-foreground">{t("alert.noAlerts")}</p>
            </CardContent>
          </Card>
        ) : (
          filteredAlerts.map((alert: any) => (
            <Card
              key={alert.id}
              className={`transition-all ${
                alert.isRead === "no"
                  ? "border-l-4 border-l-primary bg-primary/5"
                  : "opacity-80"
              } ${alert.isResolved === "yes" ? "opacity-60" : ""}`}
            >
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row gap-3">
                  {/* Icon */}
                  <div className="flex-shrink-0 pt-0.5">
                    <SeverityIcon severity={alert.severity} />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <h3 className="font-semibold text-sm">{alert.title}</h3>
                      <TypeBadge alertType={alert.alertType} t={t} />
                      <SeverityBadge severity={alert.severity} t={t} />
                      {alert.isResolved === "yes" && (
                        <Badge variant="outline" className="text-green-600 border-green-300">
                          <CheckCircle2 className="h-3 w-3 mr-1" />
                          {t("alert.resolved")}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{alert.message}</p>
                    <p className="text-xs text-muted-foreground">
                      {alert.createdAt ? new Date(alert.createdAt).toLocaleString() : ""}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex sm:flex-col gap-2 flex-shrink-0">
                    {alert.isRead === "no" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => markReadMutation.mutate({ id: alert.id })}
                        disabled={markReadMutation.isPending}
                        title={t("alert.markRead")}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        <span className="text-xs">{t("alert.markRead")}</span>
                      </Button>
                    )}
                    {alert.isResolved === "no" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => resolveMutation.mutate({ id: alert.id })}
                        disabled={resolveMutation.isPending}
                        title={t("alert.resolve")}
                      >
                        <CheckCircle2 className="h-4 w-4 mr-1" />
                        <span className="text-xs">{t("alert.resolve")}</span>
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
