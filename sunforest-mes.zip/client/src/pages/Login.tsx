import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { useI18n } from "@/lib/i18n";
import { Factory, Loader2, Eye, EyeOff, AlertCircle, Clock, XCircle } from "lucide-react";
import { toast } from "sonner";

export default function LoginPage() {
  const { t } = useI18n();
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loginStatus, setLoginStatus] = useState<"idle" | "pending" | "rejected">("idle");

  const loginMutation = trpc.account.login.useMutation({
    onSuccess: (data) => {
      if (data.success && data.status === "approved") {
        toast.success(t("auth.loginSuccess"));
        window.location.href = "/";
      } else if (data.status === "pending") {
        setLoginStatus("pending");
      } else if (data.status === "rejected") {
        setLoginStatus("rejected");
      }
    },
    onError: (error) => {
      toast.error(error.message || t("auth.loginFailed"));
    },
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) return;
    setLoginStatus("idle");
    loginMutation.mutate({ username: username.trim(), password });
  };

  // Pending approval state
  if (loginStatus === "pending") {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Card className="w-full max-w-md mx-4">
          <CardHeader className="text-center">
            <div className="mx-auto h-16 w-16 rounded-full bg-amber-100 flex items-center justify-center mb-4">
              <Clock className="h-8 w-8 text-amber-600" />
            </div>
            <CardTitle className="text-xl">{t("auth.pendingTitle")}</CardTitle>
            <CardDescription className="mt-2">{t("auth.pendingDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            <Button variant="outline" onClick={() => setLoginStatus("idle")} className="w-full">
              {t("auth.backToLogin")}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Rejected state
  if (loginStatus === "rejected") {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <Card className="w-full max-w-md mx-4">
          <CardHeader className="text-center">
            <div className="mx-auto h-16 w-16 rounded-full bg-red-100 flex items-center justify-center mb-4">
              <XCircle className="h-8 w-8 text-red-600" />
            </div>
            <CardTitle className="text-xl">{t("auth.rejectedTitle")}</CardTitle>
            <CardDescription className="mt-2">{t("auth.rejectedDesc")}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-3">
            <Button variant="outline" onClick={() => setLoginStatus("idle")} className="w-full">
              {t("auth.backToLogin")}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-background">
      <Card className="w-full max-w-md mx-4">
        <CardHeader className="text-center">
          <div className="mx-auto h-16 w-16 rounded-xl bg-primary/10 flex items-center justify-center mb-2">
            <Factory className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-2xl">{t("app.title")}</CardTitle>
          <CardDescription>{t("auth.loginDesc")}</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="flex flex-col gap-4">
            <div className="space-y-2">
              <Label htmlFor="username">{t("auth.username")}</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t("auth.usernamePlaceholder")}
                autoComplete="username"
                disabled={loginMutation.isPending}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">{t("auth.password")}</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t("auth.passwordPlaceholder")}
                  autoComplete="current-password"
                  disabled={loginMutation.isPending}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {loginMutation.isError && (
              <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 p-3 rounded-md">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{loginMutation.error?.message || t("auth.loginFailed")}</span>
              </div>
            )}

            <Button type="submit" className="w-full" disabled={loginMutation.isPending || !username.trim() || !password.trim()}>
              {loginMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              {t("auth.signInBtn")}
            </Button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">{t("auth.or")}</span>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <Button variant="outline" onClick={() => { window.location.href = getLoginUrl(); }} className="w-full">
              {t("auth.signInWithManus")}
            </Button>
            <div className="text-center text-sm text-muted-foreground">
              {t("auth.noAccount")}{" "}
              <button
                onClick={() => setLocation("/register")}
                className="text-primary hover:underline font-medium"
              >
                {t("auth.registerLink")}
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
