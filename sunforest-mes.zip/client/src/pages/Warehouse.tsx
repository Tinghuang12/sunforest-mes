import { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus } from "lucide-react";
import { toast } from "sonner";

export default function Warehouse() {
  const { t } = useI18n();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    transactionNo: "",
    type: "",
    materialName: "",
    materialId: "",
    qty: "",
    fromLocation: "",
    toLocation: "",
    notes: "",
    transactionDate: new Date().toISOString().split("T")[0],
  });

  const { data: transactions, isLoading: transLoading, refetch: refetchTransactions } = trpc.warehouse.transactions.useQuery(undefined);
  const { data: inventory } = trpc.warehouse.inventory.useQuery(undefined);
  const createMutation = trpc.warehouse.create.useMutation({
    onSuccess: () => {
      toast.success(t("common.success"));
      setIsOpen(false);
      setFormData({
        transactionNo: "",
        type: "",
        materialName: "",
        materialId: "",
        qty: "",
        fromLocation: "",
        toLocation: "",
        notes: "",
        transactionDate: new Date().toISOString().split("T")[0],
      });
      refetchTransactions();
    },
    onError: (error) => toast.error(error.message),
  });

  const handleSubmit = async () => {
    if (!formData.transactionNo || !formData.qty) {
      toast.error(t("common.error"));
      return;
    }
    // Map custom type to closest backend enum, or default to 'receive'
    const typeMap: Record<string, string> = {
      [t("warehouse.receive")]: "receive",
      [t("warehouse.issue")]: "issue",
      [t("warehouse.transfer")]: "transfer",
      [t("warehouse.adjust")]: "adjust",
    };
    const mappedType = typeMap[formData.type] || "receive";

    createMutation.mutate({
      transactionNo: formData.transactionNo,
      type: mappedType as any,
      materialId: parseInt(formData.materialId) || 0,
      qty: formData.qty,
      fromLocation: formData.fromLocation || undefined,
      toLocation: formData.toLocation || undefined,
      notes: formData.notes ? `${formData.materialName ? `[${formData.materialName}] ` : ""}${formData.type ? `(${formData.type}) ` : ""}${formData.notes}` : (formData.materialName || formData.type ? `${formData.materialName ? `[${formData.materialName}] ` : ""}${formData.type ? `(${formData.type})` : ""}` : undefined),
      transactionDate: formData.transactionDate,
    });
  };

  const getTypeLabel = (type: string) => {
    const typeMap: Record<string, string> = {
      receive: t("warehouse.receive"),
      issue: t("warehouse.issue"),
      transfer: t("warehouse.transfer"),
      adjust: t("warehouse.adjust"),
    };
    return typeMap[type] || type;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">{t("warehouse.title")}</h1>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              {t("common.add")}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{t("warehouse.title")}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">{t("warehouse.transactionNo")}</label>
                <Input
                  value={formData.transactionNo}
                  onChange={(e) => setFormData({ ...formData, transactionNo: e.target.value })}
                  placeholder="TRX-001"
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("warehouse.customType")}</label>
                <Input
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                  placeholder={`${t("warehouse.receive")} / ${t("warehouse.issue")} / ${t("warehouse.transfer")} / ${t("warehouse.adjust")}`}
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("warehouse.materialName")}</label>
                <Input
                  value={formData.materialName}
                  onChange={(e) => setFormData({ ...formData, materialName: e.target.value })}
                  placeholder={t("warehouse.materialName")}
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("material.code")}</label>
                <Input
                  value={formData.materialId}
                  onChange={(e) => setFormData({ ...formData, materialId: e.target.value })}
                  placeholder={t("material.code")}
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("common.qty")}</label>
                <Input
                  value={formData.qty}
                  onChange={(e) => setFormData({ ...formData, qty: e.target.value })}
                  placeholder="0"
                  type="number"
                  step="0.01"
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("warehouse.fromLocation")}</label>
                <Input
                  value={formData.fromLocation}
                  onChange={(e) => setFormData({ ...formData, fromLocation: e.target.value })}
                  placeholder={t("warehouse.fromLocation")}
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("warehouse.toLocation")}</label>
                <Input
                  value={formData.toLocation}
                  onChange={(e) => setFormData({ ...formData, toLocation: e.target.value })}
                  placeholder={t("warehouse.toLocation")}
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("warehouse.transactionDate")}</label>
                <Input
                  value={formData.transactionDate}
                  onChange={(e) => setFormData({ ...formData, transactionDate: e.target.value })}
                  type="date"
                />
              </div>

              <div>
                <label className="text-sm font-medium">{t("common.notes")}</label>
                <Input
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder={t("common.notes")}
                />
              </div>

              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setIsOpen(false)}>
                  {t("common.cancel")}
                </Button>
                <Button onClick={handleSubmit} disabled={createMutation.isPending}>
                  {t("common.save")}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Inventory Summary */}
      {inventory && inventory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>{t("warehouse.inventory")}</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("material.code")}</TableHead>
                  <TableHead className="text-right">{t("warehouse.receive")}</TableHead>
                  <TableHead className="text-right">{t("warehouse.issue")}</TableHead>
                  <TableHead className="text-right">{t("warehouse.transfer")}</TableHead>
                  <TableHead className="text-right">{t("common.total")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {inventory.map((item: any) => (
                  <TableRow key={item.materialId}>
                    <TableCell>Material {item.materialId}</TableCell>
                    <TableCell className="text-right">{item.totalReceived || 0}</TableCell>
                    <TableCell className="text-right">{item.totalIssued || 0}</TableCell>
                    <TableCell className="text-right">{item.totalTransferred || 0}</TableCell>
                    <TableCell className="text-right font-semibold">{item.netInventory || 0}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Transactions Table */}
      <Card>
        <CardHeader>
          <CardTitle>{t("warehouse.transactions")}</CardTitle>
        </CardHeader>
        <CardContent>
          {transLoading ? (
            <div className="text-center py-8">{t("common.loading")}</div>
          ) : transactions && transactions.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("warehouse.transactionNo")}</TableHead>
                  <TableHead>{t("warehouse.customType")}</TableHead>
                  <TableHead>{t("material.code")}</TableHead>
                  <TableHead className="text-right">{t("common.qty")}</TableHead>
                  <TableHead>{t("warehouse.fromLocation")}</TableHead>
                  <TableHead>{t("warehouse.toLocation")}</TableHead>
                  <TableHead>{t("warehouse.transactionDate")}</TableHead>
                  <TableHead>{t("common.notes")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((tx: any) => (
                  <TableRow key={tx.id}>
                    <TableCell className="font-medium">{tx.transactionNo}</TableCell>
                    <TableCell>{getTypeLabel(tx.type)}</TableCell>
                    <TableCell>Material {tx.materialId}</TableCell>
                    <TableCell className="text-right">{tx.qty}</TableCell>
                    <TableCell>{tx.fromLocation || "-"}</TableCell>
                    <TableCell>{tx.toLocation || "-"}</TableCell>
                    <TableCell>{new Date(tx.transactionDate).toLocaleDateString()}</TableCell>
                    <TableCell>{tx.notes || "-"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-muted-foreground">{t("common.noData")}</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
