import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const statusColors: Record<string, string> = {
  planned: "bg-gray-100 text-gray-700",
  packing: "bg-blue-100 text-blue-700",
  shipped: "bg-green-100 text-green-700",
  delivered: "bg-purple-100 text-purple-700",
};

export default function ShipmentsPage() {
  const { t } = useI18n();
  const [statusFilter, setStatusFilter] = useState("all");
  const [showCreate, setShowCreate] = useState(false);
  const utils = trpc.useUtils();

  const { data: shipments = [], isLoading } = trpc.shipment.list.useQuery({
    status: statusFilter !== "all" ? statusFilter : undefined,
  });

  const createMutation = trpc.shipment.create.useMutation({
    onSuccess: () => { utils.shipment.list.invalidate(); setShowCreate(false); toast.success(t("common.success")); },
    onError: () => toast.error(t("common.error")),
  });

  const updateMutation = trpc.shipment.update.useMutation({
    onSuccess: () => { utils.shipment.list.invalidate(); toast.success(t("common.success")); },
  });

  const [form, setForm] = useState({
    orderNo: "",
    customerName: "",
    productName: "",
    productNo: "",
    plannedDate: "",
    totalBoxes: 0,
    totalQty: 0,
    destination: "",
    notes: "",
    packingDetails: [{ boxNo: "", size: "", color: "", qty: 0, netWeight: "", grossWeight: "" }],
  });

  const addBox = () => setForm(f => ({ ...f, packingDetails: [...f.packingDetails, { boxNo: "", size: "", color: "", qty: 0, netWeight: "", grossWeight: "" }] }));
  const removeBox = (i: number) => setForm(f => ({ ...f, packingDetails: f.packingDetails.filter((_, idx) => idx !== i) }));

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">{t("ship.title")}</h1>
        <Button onClick={() => {
          setForm({ orderNo: "", customerName: "", productName: "", productNo: "", plannedDate: "", totalBoxes: 0, totalQty: 0, destination: "", notes: "", packingDetails: [{ boxNo: "", size: "", color: "", qty: 0, netWeight: "", grossWeight: "" }] });
          setShowCreate(true);
        }} className="touch-target">
          <Plus className="h-4 w-4 mr-1" /> {t("ship.newShipment")}
        </Button>
      </div>

      <Select value={statusFilter} onValueChange={setStatusFilter}>
        <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="all">{t("common.all")}</SelectItem>
          <SelectItem value="planned">{t("ship.planned")}</SelectItem>
          <SelectItem value="packing">{t("ship.packing")}</SelectItem>
          <SelectItem value="shipped">{t("ship.shipped")}</SelectItem>
          <SelectItem value="delivered">{t("ship.delivered")}</SelectItem>
        </SelectContent>
      </Select>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="text-left p-3 font-medium">{t("ship.orderNo")}</th>
                  <th className="text-left p-3 font-medium">{t("ship.customerName")}</th>
                  <th className="text-left p-3 font-medium">{t("ship.productName")}</th>
                  <th className="text-left p-3 font-medium">{t("ship.productNo")}</th>
                  <th className="text-left p-3 font-medium">{t("ship.plannedDate")}</th>
                  <th className="text-left p-3 font-medium">{t("ship.actualDate")}</th>
                  <th className="text-right p-3 font-medium">{t("ship.totalBoxes")}</th>
                  <th className="text-right p-3 font-medium">{t("ship.totalQty")}</th>
                  <th className="text-left p-3 font-medium">{t("ship.destination")}</th>
                  <th className="text-left p-3 font-medium">{t("common.status")}</th>
                  <th className="text-left p-3 font-medium">{t("common.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr><td colSpan={11} className="p-8 text-center text-muted-foreground">{t("common.loading")}</td></tr>
                ) : shipments.length === 0 ? (
                  <tr><td colSpan={11} className="p-8 text-center text-muted-foreground">{t("common.noData")}</td></tr>
                ) : shipments.map((s: any) => (
                  <tr key={s.id} className="border-b hover:bg-muted/30">
                    <td className="p-3 font-mono text-xs">{s.orderNo || "-"}</td>
                    <td className="p-3">{s.customerName || "-"}</td>
                    <td className="p-3">{s.productName || "-"}</td>
                    <td className="p-3 font-mono text-xs">{s.productNo || "-"}</td>
                    <td className="p-3 text-xs">{s.plannedDate ? new Date(s.plannedDate).toLocaleDateString() : "-"}</td>
                    <td className="p-3 text-xs">{s.actualDate ? new Date(s.actualDate).toLocaleDateString() : "-"}</td>
                    <td className="p-3 text-right">{s.totalBoxes || 0}</td>
                    <td className="p-3 text-right">{(s.totalQty || 0).toLocaleString()}</td>
                    <td className="p-3">{s.destination || "-"}</td>
                    <td className="p-3"><Badge variant="secondary" className={statusColors[s.status] || ""}>{t(`ship.${s.status}`)}</Badge></td>
                    <td className="p-3">
                      <Select value={s.status} onValueChange={(v) => updateMutation.mutate({ id: s.id, status: v as any })}>
                        <SelectTrigger className="h-7 text-xs w-[90px]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="planned">{t("ship.planned")}</SelectItem>
                          <SelectItem value="packing">{t("ship.packing")}</SelectItem>
                          <SelectItem value="shipped">{t("ship.shipped")}</SelectItem>
                          <SelectItem value="delivered">{t("ship.delivered")}</SelectItem>
                        </SelectContent>
                      </Select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{t("ship.newShipment")}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>{t("ship.orderNo")}</Label>
              <Input value={form.orderNo} onChange={e => setForm(f => ({ ...f, orderNo: e.target.value }))} placeholder={t("ship.orderNo")} />
            </div>
            <div>
              <Label>{t("ship.customerName")}</Label>
              <Input value={form.customerName} onChange={e => setForm(f => ({ ...f, customerName: e.target.value }))} placeholder={t("ship.customerName")} />
            </div>
            <div>
              <Label>{t("ship.productName")}</Label>
              <Input value={form.productName} onChange={e => setForm(f => ({ ...f, productName: e.target.value }))} placeholder={t("ship.productName")} />
            </div>
            <div>
              <Label>{t("ship.productNo")}</Label>
              <Input value={form.productNo} onChange={e => setForm(f => ({ ...f, productNo: e.target.value }))} placeholder={t("ship.productNo")} />
            </div>
            <div><Label>{t("ship.plannedDate")}</Label><Input type="date" value={form.plannedDate} onChange={e => setForm(f => ({ ...f, plannedDate: e.target.value }))} /></div>
            <div><Label>{t("ship.destination")}</Label><Input value={form.destination} onChange={e => setForm(f => ({ ...f, destination: e.target.value }))} placeholder={t("ship.destination")} /></div>
            <div><Label>{t("ship.totalBoxes")}</Label><Input type="number" value={form.totalBoxes || ""} onChange={e => setForm(f => ({ ...f, totalBoxes: Number(e.target.value) }))} /></div>
            <div><Label>{t("ship.totalQty")}</Label><Input type="number" value={form.totalQty || ""} onChange={e => setForm(f => ({ ...f, totalQty: Number(e.target.value) }))} /></div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>{t("ship.boxNo")}</Label>
              <Button variant="outline" size="sm" onClick={addBox}><Plus className="h-3 w-3 mr-1" />{t("common.add")}</Button>
            </div>
            {form.packingDetails.map((d, i) => (
              <div key={i} className="flex gap-2 items-center flex-wrap">
                <Input placeholder={t("ship.boxNo")} value={d.boxNo} onChange={e => setForm(f => ({ ...f, packingDetails: f.packingDetails.map((dd, idx) => idx === i ? { ...dd, boxNo: e.target.value } : dd) }))} className="w-20" />
                <Input placeholder="Size" value={d.size} onChange={e => setForm(f => ({ ...f, packingDetails: f.packingDetails.map((dd, idx) => idx === i ? { ...dd, size: e.target.value } : dd) }))} className="w-20" />
                <Input placeholder="Color" value={d.color} onChange={e => setForm(f => ({ ...f, packingDetails: f.packingDetails.map((dd, idx) => idx === i ? { ...dd, color: e.target.value } : dd) }))} className="w-20" />
                <Input type="number" placeholder="Qty" value={d.qty || ""} onChange={e => setForm(f => ({ ...f, packingDetails: f.packingDetails.map((dd, idx) => idx === i ? { ...dd, qty: Number(e.target.value) } : dd) }))} className="w-20" />
                <Input placeholder={t("ship.netWeight")} value={d.netWeight} onChange={e => setForm(f => ({ ...f, packingDetails: f.packingDetails.map((dd, idx) => idx === i ? { ...dd, netWeight: e.target.value } : dd) }))} className="w-20" />
                <Input placeholder={t("ship.grossWeight")} value={d.grossWeight} onChange={e => setForm(f => ({ ...f, packingDetails: f.packingDetails.map((dd, idx) => idx === i ? { ...dd, grossWeight: e.target.value } : dd) }))} className="w-20" />
                <Button variant="ghost" size="icon" onClick={() => removeBox(i)}><Trash2 className="h-4 w-4" /></Button>
              </div>
            ))}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>{t("common.cancel")}</Button>
            <Button onClick={() => {
              createMutation.mutate({
                ...form,
                orderNo: form.orderNo || undefined,
                customerName: form.customerName || undefined,
                productName: form.productName || undefined,
                productNo: form.productNo || undefined,
                packingDetails: form.packingDetails.filter(d => d.boxNo && d.qty > 0),
              });
            }} disabled={createMutation.isPending}>{t("common.save")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
