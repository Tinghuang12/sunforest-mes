# 員工模組存取權限設計

## 權限模組定義

將系統功能分為以下可授權模組：

| 模組 ID | 模組名稱 | 對應頁面路徑 |
|---------|---------|-------------|
| production | 生產管理 | /orders, /work-orders, /schedule, /production, /lines |
| warehouse | 倉庫管理 | /materials, /warehouse |
| quality | 品質管理 | /qc, /shipments |
| hr | 人事管理 | /workers, /attendance, /customers |
| finance | 財務薪資 | /salary |
| reports | 報表統計 | /reports |
| alerts | 預警通知 | /alerts, /alert-settings |
| sewing | 縫製工序 | /sewing-processes |
| import | 資料匯入 | /import |

## 角色預設權限

| 角色 | 預設權限 |
|------|---------|
| worker | production (僅報工) |
| leader | production, quality |
| manager (總經理) | 全部模組 |

## 實作方式

在 workers 表新增 `permissions` 欄位 (TEXT/JSON)，儲存該員工可存取的模組 ID 陣列。
- manager 角色自動擁有全部權限，不受 permissions 欄位限制
- worker/leader 根據 permissions 欄位控制可見菜單
- 前端側邊欄根據權限動態過濾菜單項
- 員工編輯表單新增權限勾選 UI
