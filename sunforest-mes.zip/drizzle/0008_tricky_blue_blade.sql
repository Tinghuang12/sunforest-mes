ALTER TABLE `shipments` DROP INDEX `shipments_shipmentNo_unique`;--> statement-breakpoint
ALTER TABLE `shipments` MODIFY COLUMN `shipmentNo` varchar(64);--> statement-breakpoint
ALTER TABLE `shipments` MODIFY COLUMN `orderId` int;--> statement-breakpoint
ALTER TABLE `qc_inspections` ADD `productName` varchar(256);--> statement-breakpoint
ALTER TABLE `qc_inspections` ADD `productNo` varchar(128);--> statement-breakpoint
ALTER TABLE `shipments` ADD `orderNo` varchar(64);--> statement-breakpoint
ALTER TABLE `shipments` ADD `customerName` varchar(256);--> statement-breakpoint
ALTER TABLE `shipments` ADD `productName` varchar(256);--> statement-breakpoint
ALTER TABLE `shipments` ADD `productNo` varchar(128);