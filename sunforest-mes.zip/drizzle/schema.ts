import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, date, bigint } from "drizzle-orm/mysql-core";

// ============================================================
// 1. Users (OAuth login users + self-registered employees)
// ============================================================
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  username: varchar("username", { length: 100 }),  // for password-based login
  passwordHash: text("passwordHash"),               // bcrypt hashed password
  phone: varchar("phone", { length: 32 }),          // optional phone number
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  approvalStatus: mysqlEnum("approvalStatus", ["pending", "approved", "rejected"]).default("approved").notNull(), // default approved for OAuth users
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ============================================================
// 2. Workers (factory floor workers + group leaders)
// ============================================================
export const workers = mysqlTable("workers", {
  id: int("id").autoincrement().primaryKey(),
  employeeCode: varchar("employeeCode", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  nameVi: varchar("nameVi", { length: 128 }),
  phone: varchar("phone", { length: 32 }),
  workerRole: mysqlEnum("workerRole", ["worker", "leader", "line_leader", "supervisor", "deputy_manager", "manager", "director", "general_manager"]).default("worker").notNull(),
  lineId: int("lineId"),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  // Salary type: hourly or monthly (monthly = 26 working days)
  salaryType: mysqlEnum("salaryType", ["hourly", "monthly"]).default("monthly").notNull(),
  monthlySalary: decimal("monthlySalary", { precision: 12, scale: 2 }).default("0"),
  hourlyRate: decimal("hourlyRate", { precision: 10, scale: 2 }).default("0"),
  pieceRate: decimal("pieceRate", { precision: 10, scale: 2 }).default("0"),
  joinDate: date("joinDate"),
  // Module-level access permissions (JSON array of module IDs)
  // Modules: production, warehouse, quality, hr, finance, reports, alerts, sewing, import
  // Roles: worker=員工, leader=組長, line_leader=線長, supervisor=主管,
  //        deputy_manager=副廠長, manager=廠長, director=總監, general_manager=總經理
  // general_manager/director/manager/deputy_manager automatically get all permissions
  permissions: text("permissions"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Worker = typeof workers.$inferSelect;
export type InsertWorker = typeof workers.$inferInsert;

// ============================================================
// 3. Production Lines (sewing lines / groups)
// Keep backward compatibility with existing enum values
// ============================================================
export const productionLines = mysqlTable("production_lines", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 64 }).notNull(),
  nameVi: varchar("nameVi", { length: 64 }),
  // Support both old and new production stages
  type: mysqlEnum("type", ["warehouse", "cutting", "semi_inspection", "sewing", "final_inspection", "ironing", "qc", "packing", "shipping"]).default("sewing").notNull(),
  leaderId: int("leaderId"),
  capacity: int("capacity").default(0),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProductionLine = typeof productionLines.$inferSelect;
export type InsertProductionLine = typeof productionLines.$inferInsert;

// ============================================================
// 4. Sewing Processes (customizable sub-processes for sewing station)
// ============================================================
export const sewingProcesses = mysqlTable("sewing_processes", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  nameVi: varchar("nameVi", { length: 128 }),
  sortOrder: int("sortOrder").default(0).notNull(),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SewingProcess = typeof sewingProcesses.$inferSelect;
export type InsertSewingProcess = typeof sewingProcesses.$inferInsert;

// ============================================================
// 5. Customers
// ============================================================
export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  contactPerson: varchar("contactPerson", { length: 128 }),
  phone: varchar("phone", { length: 32 }),
  email: varchar("email", { length: 320 }),
  address: text("address"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = typeof customers.$inferInsert;

// ============================================================
// 6. Orders (customer orders)
// ============================================================
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  orderNo: varchar("orderNo", { length: 64 }).notNull().unique(),
  customerId: int("customerId").notNull(),
  styleNo: varchar("styleNo", { length: 64 }).notNull(),
  styleName: varchar("styleName", { length: 128 }),
  totalQty: int("totalQty").notNull().default(0),
  deliveryDate: date("deliveryDate"),
  status: mysqlEnum("status", ["pending", "scheduled", "in_production", "completed", "shipped"]).default("pending").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

// ============================================================
// 7. Order Details (size/color breakdown)
// ============================================================
export const orderDetails = mysqlTable("order_details", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  size: varchar("size", { length: 16 }).notNull(),
  color: varchar("color", { length: 64 }).notNull(),
  qty: int("qty").notNull().default(0),
});

export type OrderDetail = typeof orderDetails.$inferSelect;
export type InsertOrderDetail = typeof orderDetails.$inferInsert;

// ============================================================
// 8. Work Orders (production work orders split from orders)
// ============================================================
export const workOrders = mysqlTable("work_orders", {
  id: int("id").autoincrement().primaryKey(),
  workOrderNo: varchar("workOrderNo", { length: 64 }).notNull().unique(),
  orderId: int("orderId").notNull(),
  lineId: int("lineId"),
  targetQty: int("targetQty").notNull().default(0),
  completedQty: int("completedQty").default(0),
  startDate: date("startDate"),
  endDate: date("endDate"),
  status: mysqlEnum("status", ["pending", "in_progress", "completed", "cancelled"]).default("pending").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WorkOrder = typeof workOrders.$inferSelect;
export type InsertWorkOrder = typeof workOrders.$inferInsert;

// ============================================================
// 9. Materials (fabrics + accessories)
// ============================================================
export const materials = mysqlTable("materials", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 64 }).notNull().unique(),
  name: varchar("name", { length: 128 }).notNull(),
  nameVi: varchar("nameVi", { length: 128 }),
  type: mysqlEnum("type", ["fabric", "accessory"]).default("fabric").notNull(),
  unit: varchar("unit", { length: 16 }).notNull().default("m"),
  color: varchar("color", { length: 64 }),
  batchNo: varchar("batchNo", { length: 64 }),
  currentStock: decimal("currentStock", { precision: 12, scale: 2 }).default("0"),
  safetyStock: decimal("safetyStock", { precision: 12, scale: 2 }).default("0"),
  // Warehouse location
  warehouseLocation: varchar("warehouseLocation", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Material = typeof materials.$inferSelect;
export type InsertMaterial = typeof materials.$inferInsert;

// ============================================================
// 10. Material Transactions (in/out/return records)
// ============================================================
export const materialTransactions = mysqlTable("material_transactions", {
  id: int("id").autoincrement().primaryKey(),
  materialId: int("materialId").notNull(),
  type: mysqlEnum("type", ["in", "out", "return"]).notNull(),
  qty: decimal("qty", { precision: 12, scale: 2 }).notNull(),
  orderId: int("orderId"),
  workOrderId: int("workOrderId"),
  operatorId: int("operatorId"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MaterialTransaction = typeof materialTransactions.$inferSelect;
export type InsertMaterialTransaction = typeof materialTransactions.$inferInsert;

// ============================================================
// 11. Warehouse Transactions (independent warehouse management)
// ============================================================
export const warehouseTransactions = mysqlTable("warehouse_transactions", {
  id: int("id").autoincrement().primaryKey(),
  transactionNo: varchar("transactionNo", { length: 64 }).notNull(),
  type: mysqlEnum("type", ["receive", "issue", "transfer", "adjust"]).notNull(),
  materialId: int("materialId").notNull(),
  qty: decimal("qty", { precision: 12, scale: 2 }).notNull(),
  fromLocation: varchar("fromLocation", { length: 64 }),
  toLocation: varchar("toLocation", { length: 64 }),
  orderId: int("orderId"),
  workOrderId: int("workOrderId"),
  operatorId: int("operatorId"),
  notes: text("notes"),
  transactionDate: date("transactionDate").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WarehouseTransaction = typeof warehouseTransactions.$inferSelect;
export type InsertWarehouseTransaction = typeof warehouseTransactions.$inferInsert;

// ============================================================
// 12. Production Reports (station reporting)
// Support both old and new station types
// ============================================================
export const productionReports = mysqlTable("production_reports", {
  id: int("id").autoincrement().primaryKey(),
  workOrderId: int("workOrderId").notNull(),
  workerId: int("workerId").notNull(),
  lineId: int("lineId"),
  station: mysqlEnum("station", ["warehouse", "cutting", "semi_inspection", "sewing", "final_inspection", "ironing", "packing"]).notNull(),
  // For sewing station: which sub-process
  sewingProcessId: int("sewingProcessId"),
  qty: int("qty").notNull().default(0),
  defectQty: int("defectQty").default(0),
  reportDate: date("reportDate").notNull(),
  reportTime: timestamp("reportTime").defaultNow().notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProductionReport = typeof productionReports.$inferSelect;
export type InsertProductionReport = typeof productionReports.$inferInsert;

// ============================================================
// 13. QC Inspections
// ============================================================
export const qcInspections = mysqlTable("qc_inspections", {
  id: int("id").autoincrement().primaryKey(),
  workOrderId: int("workOrderId").notNull(),
  inspectorId: int("inspectorId").notNull(),
  productName: varchar("productName", { length: 256 }),
  productNo: varchar("productNo", { length: 128 }),
  // Which inspection stage: semi_inspection or final_inspection
  inspectionStage: mysqlEnum("inspectionStage", ["semi_inspection", "final_inspection"]).default("final_inspection").notNull(),
  inspectedQty: int("inspectedQty").notNull().default(0),
  passQty: int("passQty").notNull().default(0),
  failQty: int("failQty").notNull().default(0),
  inspectionDate: date("inspectionDate").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type QcInspection = typeof qcInspections.$inferSelect;
export type InsertQcInspection = typeof qcInspections.$inferInsert;

// ============================================================
// 14. Defect Records (linked to QC inspections)
// ============================================================
export const defectRecords = mysqlTable("defect_records", {
  id: int("id").autoincrement().primaryKey(),
  inspectionId: int("inspectionId").notNull(),
  defectType: mysqlEnum("defectType", [
    "hole", "skip_stitch", "color_diff", "size_deviation",
    "stain", "broken_thread", "misalignment", "other"
  ]).notNull(),
  qty: int("qty").notNull().default(1),
  repaired: mysqlEnum("repaired", ["pending", "repaired", "scrapped"]).default("pending").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DefectRecord = typeof defectRecords.$inferSelect;
export type InsertDefectRecord = typeof defectRecords.$inferInsert;

// ============================================================
// 15. Attendance
// ============================================================
export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  workerId: int("workerId").notNull(),
  attendanceDate: date("attendanceDate").notNull(),
  checkIn: timestamp("checkIn"),
  checkOut: timestamp("checkOut"),
  status: mysqlEnum("status", ["present", "absent", "late", "half_day", "leave"]).default("present").notNull(),
  overtimeHours: decimal("overtimeHours", { precision: 4, scale: 1 }).default("0"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = typeof attendance.$inferInsert;

// ============================================================
// 16. Shipments
// ============================================================
export const shipments = mysqlTable("shipments", {
  id: int("id").autoincrement().primaryKey(),
  shipmentNo: varchar("shipmentNo", { length: 64 }),
  orderId: int("orderId"),
  orderNo: varchar("orderNo", { length: 64 }),
  customerName: varchar("customerName", { length: 256 }),
  productName: varchar("productName", { length: 256 }),
  productNo: varchar("productNo", { length: 128 }),
  plannedDate: date("plannedDate"),
  actualDate: date("actualDate"),
  totalBoxes: int("totalBoxes").default(0),
  totalQty: int("totalQty").default(0),
  status: mysqlEnum("status", ["planned", "packing", "shipped", "delivered"]).default("planned").notNull(),
  destination: text("destination"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Shipment = typeof shipments.$inferSelect;
export type InsertShipment = typeof shipments.$inferInsert;

// ============================================================
// 17. Packing Details (box-level details)
// ============================================================
export const packingDetails = mysqlTable("packing_details", {
  id: int("id").autoincrement().primaryKey(),
  shipmentId: int("shipmentId").notNull(),
  boxNo: varchar("boxNo", { length: 32 }).notNull(),
  size: varchar("size", { length: 16 }),
  color: varchar("color", { length: 64 }),
  qty: int("qty").notNull().default(0),
  netWeight: decimal("netWeight", { precision: 8, scale: 2 }),
  grossWeight: decimal("grossWeight", { precision: 8, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PackingDetail = typeof packingDetails.$inferSelect;
export type InsertPackingDetail = typeof packingDetails.$inferInsert;

// ============================================================
// 18. Alert Settings (configurable alert thresholds)
// ============================================================
export const alertSettings = mysqlTable("alert_settings", {
  id: int("id").autoincrement().primaryKey(),
  alertType: mysqlEnum("alertType", [
    "low_stock",           // 庫存低於安全水位
    "delivery_approaching", // 交期逼近
    "delivery_overdue",     // 交期逾期
    "high_defect_rate",     // 不良率超標
  ]).notNull(),
  enabled: mysqlEnum("enabled", ["yes", "no"]).default("yes").notNull(),
  // Threshold value (e.g., days before delivery, defect rate percentage)
  thresholdValue: decimal("thresholdValue", { precision: 10, scale: 2 }).default("0"),
  // Secondary threshold (e.g., critical days for delivery)
  thresholdValue2: decimal("thresholdValue2", { precision: 10, scale: 2 }),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AlertSetting = typeof alertSettings.$inferSelect;
export type InsertAlertSetting = typeof alertSettings.$inferInsert;

// ============================================================
// 19. Alerts (generated alert records)
// ============================================================
export const alerts = mysqlTable("alerts", {
  id: int("id").autoincrement().primaryKey(),
  alertType: mysqlEnum("alertType", [
    "low_stock",
    "delivery_approaching",
    "delivery_overdue",
    "high_defect_rate",
  ]).notNull(),
  severity: mysqlEnum("severity", ["info", "warning", "critical"]).default("warning").notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  message: text("message").notNull(),
  // Reference IDs for linking to specific records
  referenceId: int("referenceId"),
  referenceType: varchar("referenceType", { length: 64 }), // 'material', 'order', 'qc_inspection'
  isRead: mysqlEnum("isRead", ["yes", "no"]).default("no").notNull(),
  isResolved: mysqlEnum("isResolved", ["yes", "no"]).default("no").notNull(),
  notifiedAt: timestamp("notifiedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = typeof alerts.$inferInsert;
