CREATE TABLE `sewing_processes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(32) NOT NULL,
	`name` varchar(128) NOT NULL,
	`nameVi` varchar(128),
	`sortOrder` int NOT NULL DEFAULT 0,
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sewing_processes_id` PRIMARY KEY(`id`),
	CONSTRAINT `sewing_processes_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `warehouse_transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`transactionNo` varchar(64) NOT NULL,
	`type` enum('receive','issue','transfer','adjust') NOT NULL,
	`materialId` int NOT NULL,
	`qty` decimal(12,2) NOT NULL,
	`fromLocation` varchar(64),
	`toLocation` varchar(64),
	`orderId` int,
	`workOrderId` int,
	`operatorId` int,
	`notes` text,
	`transactionDate` date NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `warehouse_transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `production_lines` MODIFY COLUMN `type` enum('warehouse','cutting','semi_inspection','sewing','final_inspection','packing','shipping') NOT NULL DEFAULT 'sewing';--> statement-breakpoint
ALTER TABLE `production_reports` MODIFY COLUMN `station` enum('warehouse','cutting','semi_inspection','sewing','final_inspection') NOT NULL;--> statement-breakpoint
ALTER TABLE `materials` ADD `warehouseLocation` varchar(64);--> statement-breakpoint
ALTER TABLE `production_reports` ADD `sewingProcessId` int;--> statement-breakpoint
ALTER TABLE `qc_inspections` ADD `inspectionStage` enum('semi_inspection','final_inspection') DEFAULT 'final_inspection' NOT NULL;--> statement-breakpoint
ALTER TABLE `workers` ADD `salaryType` enum('hourly','monthly') DEFAULT 'monthly' NOT NULL;--> statement-breakpoint
ALTER TABLE `workers` ADD `monthlySalary` decimal(12,2) DEFAULT '0';