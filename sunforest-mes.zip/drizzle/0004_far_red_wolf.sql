CREATE TABLE `alert_settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`alertType` enum('low_stock','delivery_approaching','delivery_overdue','high_defect_rate') NOT NULL,
	`enabled` enum('yes','no') NOT NULL DEFAULT 'yes',
	`thresholdValue` decimal(10,2) DEFAULT '0',
	`thresholdValue2` decimal(10,2),
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `alert_settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `alerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`alertType` enum('low_stock','delivery_approaching','delivery_overdue','high_defect_rate') NOT NULL,
	`severity` enum('info','warning','critical') NOT NULL DEFAULT 'warning',
	`title` varchar(256) NOT NULL,
	`message` text NOT NULL,
	`referenceId` int,
	`referenceType` varchar(64),
	`isRead` enum('yes','no') NOT NULL DEFAULT 'no',
	`isResolved` enum('yes','no') NOT NULL DEFAULT 'no',
	`notifiedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `alerts_id` PRIMARY KEY(`id`)
);
