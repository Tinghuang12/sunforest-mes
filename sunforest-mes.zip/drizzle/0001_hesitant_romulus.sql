CREATE TABLE `attendance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workerId` int NOT NULL,
	`attendanceDate` date NOT NULL,
	`checkIn` timestamp,
	`checkOut` timestamp,
	`status` enum('present','absent','late','half_day','leave') NOT NULL DEFAULT 'present',
	`overtimeHours` decimal(4,1) DEFAULT '0',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attendance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(128) NOT NULL,
	`contactPerson` varchar(128),
	`phone` varchar(32),
	`email` varchar(320),
	`address` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `defect_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`inspectionId` int NOT NULL,
	`defectType` enum('hole','skip_stitch','color_diff','size_deviation','stain','broken_thread','misalignment','other') NOT NULL,
	`qty` int NOT NULL DEFAULT 1,
	`repaired` enum('pending','repaired','scrapped') NOT NULL DEFAULT 'pending',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `defect_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `material_transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`materialId` int NOT NULL,
	`type` enum('in','out','return') NOT NULL,
	`qty` decimal(12,2) NOT NULL,
	`orderId` int,
	`workOrderId` int,
	`operatorId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `material_transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `materials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(64) NOT NULL,
	`name` varchar(128) NOT NULL,
	`nameVi` varchar(128),
	`type` enum('fabric','accessory') NOT NULL DEFAULT 'fabric',
	`unit` varchar(16) NOT NULL DEFAULT 'm',
	`color` varchar(64),
	`batchNo` varchar(64),
	`currentStock` decimal(12,2) DEFAULT '0',
	`safetyStock` decimal(12,2) DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `materials_id` PRIMARY KEY(`id`),
	CONSTRAINT `materials_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `order_details` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`size` varchar(16) NOT NULL,
	`color` varchar(64) NOT NULL,
	`qty` int NOT NULL DEFAULT 0,
	CONSTRAINT `order_details_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderNo` varchar(64) NOT NULL,
	`customerId` int NOT NULL,
	`styleNo` varchar(64) NOT NULL,
	`styleName` varchar(128),
	`totalQty` int NOT NULL DEFAULT 0,
	`deliveryDate` date,
	`status` enum('pending','scheduled','in_production','completed','shipped') NOT NULL DEFAULT 'pending',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_orderNo_unique` UNIQUE(`orderNo`)
);
--> statement-breakpoint
CREATE TABLE `packing_details` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipmentId` int NOT NULL,
	`boxNo` varchar(32) NOT NULL,
	`size` varchar(16),
	`color` varchar(64),
	`qty` int NOT NULL DEFAULT 0,
	`netWeight` decimal(8,2),
	`grossWeight` decimal(8,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `packing_details_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `production_lines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(64) NOT NULL,
	`nameVi` varchar(64),
	`type` enum('cutting','sewing','ironing','qc','packing','shipping') NOT NULL DEFAULT 'sewing',
	`leaderId` int,
	`capacity` int DEFAULT 0,
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `production_lines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `production_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workOrderId` int NOT NULL,
	`workerId` int NOT NULL,
	`lineId` int,
	`station` enum('cutting','sewing','ironing','packing') NOT NULL,
	`qty` int NOT NULL DEFAULT 0,
	`defectQty` int DEFAULT 0,
	`reportDate` date NOT NULL,
	`reportTime` timestamp NOT NULL DEFAULT (now()),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `production_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `qc_inspections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workOrderId` int NOT NULL,
	`inspectorId` int NOT NULL,
	`inspectedQty` int NOT NULL DEFAULT 0,
	`passQty` int NOT NULL DEFAULT 0,
	`failQty` int NOT NULL DEFAULT 0,
	`inspectionDate` date NOT NULL,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `qc_inspections_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `shipments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`shipmentNo` varchar(64) NOT NULL,
	`orderId` int NOT NULL,
	`plannedDate` date,
	`actualDate` date,
	`totalBoxes` int DEFAULT 0,
	`totalQty` int DEFAULT 0,
	`status` enum('planned','packing','shipped','delivered') NOT NULL DEFAULT 'planned',
	`destination` text,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `shipments_id` PRIMARY KEY(`id`),
	CONSTRAINT `shipments_shipmentNo_unique` UNIQUE(`shipmentNo`)
);
--> statement-breakpoint
CREATE TABLE `work_orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`workOrderNo` varchar(64) NOT NULL,
	`orderId` int NOT NULL,
	`lineId` int,
	`targetQty` int NOT NULL DEFAULT 0,
	`completedQty` int DEFAULT 0,
	`startDate` date,
	`endDate` date,
	`status` enum('pending','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `work_orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `work_orders_workOrderNo_unique` UNIQUE(`workOrderNo`)
);
--> statement-breakpoint
CREATE TABLE `workers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`employeeCode` varchar(32) NOT NULL,
	`name` varchar(128) NOT NULL,
	`nameVi` varchar(128),
	`phone` varchar(32),
	`workerRole` enum('worker','leader','manager') NOT NULL DEFAULT 'worker',
	`lineId` int,
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`hourlyRate` decimal(10,2) DEFAULT '0',
	`pieceRate` decimal(10,2) DEFAULT '0',
	`joinDate` date,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `workers_id` PRIMARY KEY(`id`),
	CONSTRAINT `workers_employeeCode_unique` UNIQUE(`employeeCode`)
);
